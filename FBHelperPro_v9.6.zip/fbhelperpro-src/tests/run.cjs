/**
 * FBHelperPro v7.0 — Automated test suite (item 20)
 * Run: node tests/run.cjs
 *
 * Covers: URL validation/normalization, yt-dlp error classification,
 * FB error classification, upload file validation, DB dedup/recovery,
 * scrape sorting, security guards. Live FB/yt-dlp tests alag checklist mein.
 */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');

const yt = require('../server/yt.cjs');
const fb = require('../server/fb.cjs');
const sec = require('../server/security.cjs');

let pass = 0, fail = 0;
function test(name, fn) {
  try { fn(); pass++; console.log(`  ✅ ${name}`); }
  catch (e) { fail++; console.log(`  ❌ ${name}\n     ${e.message}`); }
}

console.log('\n━━━ URL validation & normalization (items 7, 10) ━━━');
test('khali URL reject', () => {
  assert.strictEqual(yt.validateUrl('').ok, false);
  assert.strictEqual(yt.validateUrl('   ').ok, false);
});
test('ghalat format reject', () => {
  assert.strictEqual(yt.validateUrl('not-a-url').ok, false);
  assert.strictEqual(yt.validateUrl('ftp://x.com/v').ok, false);
});
test('sahi URL accept', () => {
  const r = yt.validateUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
  assert.strictEqual(r.ok, true);
});
test('youtube watch == shorts == youtu.be (item 10)', () => {
  const a = yt.normalizeVideoId('https://www.youtube.com/watch?v=ABC123xyz');
  const b = yt.normalizeVideoId('https://www.youtube.com/shorts/ABC123xyz');
  const c = yt.normalizeVideoId('https://youtu.be/ABC123xyz');
  assert.strictEqual(a.platform, 'youtube');
  assert.strictEqual(a.video_id, b.video_id);
  assert.strictEqual(b.video_id, c.video_id);
  assert.strictEqual(c.video_id, 'ABC123xyz');
});
test('tiktok video id', () => {
  const r = yt.normalizeVideoId('https://www.tiktok.com/@user/video/7481234567890');
  assert.strictEqual(r.platform, 'tiktok');
  assert.strictEqual(r.video_id, '7481234567890');
});
test('instagram reel id', () => {
  const r = yt.normalizeVideoId('https://www.instagram.com/reel/DKxYz123/');
  assert.strictEqual(r.platform, 'instagram');
  assert.strictEqual(r.video_id, 'DKxYz123');
});

console.log('\n━━━ yt-dlp error classification (items 7, 17) ━━━');
const cases = [
  ['ERROR: Private video', 'private'],
  ['This video is private', 'private'],
  ['Video unavailable. This video has been removed', 'deleted'],
  ['Sign in to confirm your age', 'age'],
  ['Login required. Use --cookies', 'login'],
  ['not available in your country', 'geo'],
  ['Unsupported URL', 'unsupported'],
  ['Connection timed out', 'network'],
  ['No space left on device', 'disk'],
];
for (const [stderr, kind] of cases) {
  test(`"${stderr.slice(0, 30)}..." → ${kind}`, () => {
    assert.strictEqual(yt.classifyYtError(stderr, 1).kind, kind);
  });
}

console.log('\n━━━ FB error classification (item 16) ━━━');
test('190/463 → token_expired', () => {
  const c = fb.classifyFbError({ code: 190, error_subcode: 463, message: 'Session expired' });
  assert.strictEqual(c.kind, 'token_expired');
  assert.ok(c.message.includes('EXPIRED'));
});
test('190/467 → token_invalid', () => {
  const c = fb.classifyFbError({ code: 190, error_subcode: 467, message: 'Invalid token' });
  assert.strictEqual(c.kind, 'token_invalid');
});
test('200 → permission', () => {
  const c = fb.classifyFbError({ code: 200, message: 'Requires permission' });
  assert.strictEqual(c.kind, 'permission');
});
test('rate limit → rate_limit', () => {
  const c = fb.classifyFbError({ code: 4, message: 'Too many calls' });
  assert.strictEqual(c.kind, 'rate_limit');
});

console.log('\n━━━ upload file validation (item 4) ━━━');
test('missing file', () => {
  assert.strictEqual(fb.validateUploadFile('/no/such/file.mp4').ok, false);
});
test('khali file reject', () => {
  const p = path.join(os.tmpdir(), 'fbh_test_empty.mp4');
  fs.writeFileSync(p, '');
  assert.strictEqual(fb.validateUploadFile(p).ok, false);
  fs.unlinkSync(p);
});
test('sahi file accept', () => {
  const p = path.join(os.tmpdir(), 'fbh_test_ok.mp4');
  fs.writeFileSync(p, Buffer.alloc(1024));
  const r = fb.validateUploadFile(p);
  assert.strictEqual(r.ok, true);
  assert.strictEqual(r.size, 1024);
  fs.unlinkSync(p);
});

console.log('\n━━━ DB: dedup + recovery (items 9, 14, 19) ━━━');
// test ke liye alag DB — env se control nahi, is liye seedha db module ke functions
const db = require('../server/db.cjs');
test('UNIQUE(platform, video_id) dedup', () => {
  const id1 = 'test_' + Date.now();
  const r1 = db.createJob({ id: id1, kind: 'download', platform: 'youtube', video_id: 'DUP999', source_url: 'https://youtube.com/watch?v=DUP999' });
  assert.strictEqual(r1.ok, true);
  const r2 = db.createJob({ id: id1 + '_b', kind: 'download', platform: 'youtube', video_id: 'DUP999', source_url: 'https://youtu.be/DUP999' });
  assert.strictEqual(r2.ok, false);
  assert.strictEqual(r2.duplicate, true);
  assert.strictEqual(r2.job.video_id, 'DUP999');
  db.deleteJob(id1);
});
test('crash recovery: downloading → queued', () => {
  const id1 = 'test_rec_' + Date.now();
  db.createJob({ id: id1, kind: 'download', platform: 'tiktok', video_id: 'REC1', source_url: 'https://tiktok.com/@u/video/1' });
  db.updateJob(id1, { download_status: 'downloading' });
  const rec = db.recoverInterruptedJobs();
  assert.ok(rec.downloadsRecovered >= 1);
  assert.strictEqual(db.getJob(id1).download_status, 'queued');
  db.deleteJob(id1);
});
test('findByVideo khali par null', () => {
  assert.strictEqual(db.findByVideo('', ''), null);
});

console.log('\n━━━ scrape sorting (item 18) ━━━');
test('newest: upload_date se (blind reverse nahi)', () => {
  const entries = [
    { id: 'a', _ts: 100, view_count: 5 },
    { id: 'b', _ts: 300, view_count: 1 },
    { id: 'c', _ts: 200, view_count: 9 },
  ];
  const s = yt.sortEntries(entries, 'newest');
  assert.deepStrictEqual(s.map((e) => e.id), ['b', 'c', 'a']);
});
test('oldest: upload_date se', () => {
  const entries = [
    { id: 'a', _ts: 100, view_count: 5 },
    { id: 'b', _ts: 300, view_count: 1 },
  ];
  const s = yt.sortEntries(entries, 'oldest');
  assert.deepStrictEqual(s.map((e) => e.id), ['a', 'b']);
});
test('popular: view_count se', () => {
  const entries = [
    { id: 'a', _ts: 300, view_count: 5 },
    { id: 'b', _ts: 100, view_count: 99 },
  ];
  const s = yt.sortEntries(entries, 'popular');
  assert.deepStrictEqual(s.map((e) => e.id), ['b', 'a']);
});
test('uploadDateMs YYYYMMDD', () => {
  assert.strictEqual(yt.uploadDateMs({ upload_date: '20240115' }), Date.UTC(2024, 0, 15));
  assert.strictEqual(yt.uploadDateMs({}), 0);
});

console.log('\n━━━ scrape line parsing (tab separator regression) ━━━');
test('asal tab par split hota hai', () => {
  const line = 'abc123\tMy Title\thttps://x.com/v/abc123\t500\t20240115';
  let parts = line.split('\t');
  if (parts.length < 3 && line.includes('\\t')) parts = line.split('\\t');
  assert.strictEqual(parts.length, 5);
  assert.strictEqual(parts[0], 'abc123');
  assert.strictEqual(parts[3], '500');
});
test('lafzi backslash-t fallback (purani yt-dlp)', () => {
  const line = 'abc123\\tMy Title\\thttps://x.com/v/abc123\\t500\\t20240115';
  let parts = line.split('\t');
  if (parts.length < 3 && line.includes('\\t')) parts = line.split('\\t');
  assert.strictEqual(parts.length, 5);
  assert.strictEqual(parts[0], 'abc123');
});

console.log('\n━━━ security guards (item 15) ━━━');
test('path traversal blocked', () => {
  const r = sec.resolveDownloadPath('/app/downloads', '../../etc/passwd');
  assert.strictEqual(r.ok, false);
});
test('andar ka path OK', () => {
  const r = sec.resolveDownloadPath('/app/downloads', 'creator/video.mp4');
  assert.strictEqual(r.ok, true);
  assert.ok(r.path.startsWith('/app/downloads'));
});
test('local token lamba random', () => {
  assert.ok(sec.LOCAL_TOKEN.length >= 32);
});
test('safeFolderName', () => {
  assert.strictEqual(sec.safeFolderName('a/b:c*d'), 'abcd');
});

console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n  ${pass} passed, ${fail} failed\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
process.exit(fail ? 1 : 0);
