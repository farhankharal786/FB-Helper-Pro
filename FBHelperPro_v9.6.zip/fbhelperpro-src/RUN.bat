@echo off
title FBHelperPro - Launcher
cd /d "%~dp0"

echo ============================================
echo   FBHelperPro - Real Backend Edition
echo ============================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo [X] Node.js nahi mila! Pehle install karo: https://nodejs.org
  pause
  exit /b 1
)

where yt-dlp >nul 2>&1
if errorlevel 1 echo [!] WARNING: yt-dlp nahi mila - downloading kaam NAHI karegi.

where ffmpeg >nul 2>&1
if errorlevel 1 echo [!] WARNING: ffmpeg nahi mila.

if not exist node_modules (
  echo [*] Pehli baar setup ho raha hai, packages install...
  call npm install --legacy-peer-deps
  if errorlevel 1 (
    echo [X] npm install fail ho gaya.
    pause
    exit /b 1
  )
)

REM --- Purana atka hua backend ho to pehle band karo (port conflict na ho) ---
REM IPv4 + IPv6 dono match karo (":8573"), aur sirf node.exe ko maro —
REM kisi aur ka tool is port par ho to use haath mat lagao.
echo [*] Purana backend check ho raha hai...
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":8573" ^| findstr "LISTENING"') do (
  for /f "tokens=1" %%I in ('tasklist /FI "PID eq %%P" /FO TABLE /NH 2^>nul') do (
    if /i "%%I"=="node.exe" (
      echo [*] Port 8573 par purana FBHelperPro backend ^(PID %%P^) mila - band kiya ja raha hai...
      taskkill /F /PID %%P >nul 2>&1
    ) else (
      echo [!] Port 8573 par %%I ^(PID %%P^) chal raha hai - ye FBHelperPro nahi lagta, nahi chheda.
    )
  )
)
timeout /t 2 >nul

echo [*] Backend start ho raha hai (port 8573)...
start "FBHelperPro Backend :8573" cmd /k "npm run server"

REM --- Backend waqai start hua? 15 second tak port check karo ---
echo [*] Backend ke start hone ka intezar...
set BACKEND_OK=0
for /L %%I in (1,1,15) do (
  powershell -NoProfile -Command "try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', 8573); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>&1
  if not errorlevel 1 (
    set BACKEND_OK=1
    goto backend_up
  )
  timeout /t 1 >nul
)
:backend_up
if "%BACKEND_OK%"=="0" (
  echo.
  echo [X] BACKEND START NAHI HUA! "FBHelperPro Backend :8573" wali window mein error dekho.
  echo [X] Aam wajuhat: Node.js purana hai, ya port block hai.
  echo.
  pause
  exit /b 1
)
echo [OK] Backend chal raha hai.

echo [*] UI start ho rahi hai (port 3000)...
start "FBHelperPro UI :3000" cmd /k "npm run dev"

echo [*] Browser khul raha hai...
timeout /t 5 >nul
start "" http://localhost:3000

echo.
echo ============================================
echo   Backend : http://localhost:8573  [OK]
echo   UI      : http://localhost:3000
echo   Band karne ke liye STOP.bat chalao
echo ============================================
pause
