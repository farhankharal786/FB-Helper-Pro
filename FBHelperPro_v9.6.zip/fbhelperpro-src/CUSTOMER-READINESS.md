# FBHelperPro — Customer Readiness Checklist

## Masla (seedha)
Extension mein jo Facebook App ID hardcoded hai, wo **tumhari** app ki hai — aur wo app abhi **Development mode** mein hai. Jab tak app **Live** nahi hoti, har customer ko SYNC dabane par **"App Not Setup"** error aayega. Customer iska kuch nahi kar sakta — ye kaam sirf tumhara hai, aur sirf ek baar.

## Step 0 — Tumhara apna sync (abhi pending)
1. developers.facebook.com → My Apps → tumhari app → **Facebook Login → Settings**
2. **Valid OAuth Redirect URIs** mein ye add karo:
   `https://www.facebook.com/connect/login_success.html`
3. Save → extension se dobara SYNC dabao

## Step 1 — Business verification
- App Dashboard → **Settings → Business verification**
- Meta registered business ka saboot mangta hai: business license / tax ID / utility bill waghera
- Aam tor par kuch din lagte hain
- **Note:** agar registered business nahi hai to yehi sab se bara step hai — iske baghair advanced permissions approve nahi hongi

## Step 2 — App Review (permissions)
- App Dashboard → **App Review → Requests** → `pages_show_list` aur `pages_read_engagement` ke liye apply karo
- Har permission ke liye chahiye:
  - **Screencast**: poora flow record karo — extension mein SYNC dabana → Facebook ka login/permission page → Continue → pages ki list app mein aana. Reviewer tumhare screencast ke steps khud repeat karega, to jo dikhao ge wahi kaam karna chahiye
  - **Data handling questions** ke jawab
  - App settings mein **Privacy Policy URL, Terms of Service URL, Data Deletion URL** hone chahiye

## Step 3 — App ko Live karo
- Approval ke baad App Dashboard se mode **Development → Live** par switch karo
- Uske baad kisi bhi customer ko "App Not Setup" nahi aayega

## Interim — Abhi ke customers ke liye (Live ka wait kiye baghair)
- Customers ko app ke **Roles → Testers** mein add karo (unke Facebook profile ka link/ID chahiye hota hai)
- Tester Development-mode app bhi use kar sakta hai — review ka wait nahi karna parega

## Customer ko kya karna hai (bas itna — kuch aur nahi)
1. Extension install kare
2. ⚡ 1-CLICK SYNC dabaye
3. Apne Facebook se login karke Continue dabaye

**Customer ko koi app nahi banana, koi developer account nahi chahiye.** App banana, review karwana, Live karna — sab sirf tumhara kaam hai, ek baar.

## Timeline (andaza)
Business verification + App Review: aam tor par **1–3 hafte**. Tab tak testers wala tareeqa use karo.

---
Tayyar: 2026-10-08 · FBHelperPro v6.11_Customer / Extension v2.6_Customer ke liye
