/**
 * FBHelperPro — Real Backend Server v9.6 (production overhaul)
 * ------------------------------------------------------------
 * - SQLite job database (crash recovery + permanent dedup)
 * - Job queue: state machine, concurrency, SSE real-time events
 * - Hardened download engine (validation, exit codes, file verify)
 * - Hardened upload engine (validation → upload → verify post ID, resumable)
 * - Production OAuth (state CSRF, callback, token lifecycle)
 * - Real pages/BM sync with per-page validity
 * - API security: local token auth, path guard, rate limiting
 *
 * Run:  npm run server      (port 8573)
 */
const express = require('express');
const { execFile } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const db = require('./server/db.cjs');
const fb = require('./server/fb.cjs');
const yt = require('./server/yt.cjs');
const { JobQueue } = require('./server/queue.cjs');
const sec = require('./server/security.cjs');
const oauth = require('./server/oauth.cjs');

const PORT = process.env.FBH_PORT || 8573;
const ROOT = __dirname;
const DEFAULT_DOWNLOADS = path.join(ROOT, 'downloads');

// Downloads folder — user Settings mein apne PC ka koi bhi folder choose kar sakta hai
function getDownloadsDir() {
  const custom = (db.kvGet('downloads_dir', '') || '').trim();
  const dir = custom || DEFAULT_DOWNLOADS;
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}
function setDownloadsDir(p) {
  const dir = String(p || '').trim();
  if (!dir) return { ok: false, error: 'Path khaali hai.' };
  if (!path.isAbsolute(dir)) return { ok: false, error: 'Poora (absolute) path do, masalan D:\\Videos\\FBHelper' };
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
  } catch {
    return { ok: false, error: 'Is folder mein likhne ki ijazat nahi ya path ghalat hai.' };
  }
  db.kvSet('downloads_dir', dir);
  return { ok: true, path: dir };
}
try { fs.mkdirSync(getDownloadsDir(), { recursive: true }); } catch {}

const app = express();
app.set('trust proxy', 'loopback');
app.use(express.json({ limit: '2mb' }));

// ---- crash-proof: koi bhi job error backend ko maar NA sake ----
// (Desktop tool hai — crash = sab kuch band. Error ko cheekh kar log karo, chalte raho.)
process.on('uncaughtException', (e) => {
  console.error('\n⚠️⚠️ BACKEND ERROR (pakra gaya, backend zinda hai):', e && e.stack || e);
});
process.on('unhandledRejection', (reason) => {
  console.error('\n⚠️⚠️ BACKEND ERROR (promise reject, pakra gaya):', reason && reason.stack || reason);
});

// aakhri 30 errors (diag ke liye)
const recentErrors = [];
function logRecentError(where, e) {
  try {
    recentErrors.push({ t: new Date().toISOString(), where, msg: String((e && e.message) || e).slice(0, 300) });
    if (recentErrors.length > 30) recentErrors.shift();
  } catch {}
}
process.on('uncaughtException', (e) => logRecentError('uncaughtException', e));
process.on('unhandledRejection', (r) => logRecentError('unhandledRejection', r));
const BOOT_TIME = Date.now();

// ---- security: rate limit + local token auth (item 15) ----
app.use(sec.rateLimit({ windowMs: 60000, max: 600 }));
app.use(sec.authMiddleware);

// UI ko token bootstrap (same-origin localhost) — api.ts isko header mein bhejta hai
app.get('/api/auth/bootstrap', (req, res) => {
  res.json({ ok: true, token: sec.LOCAL_TOKEN });
});

// Halka health check — token nahi chahiye, tool detection nahi (UI indicator ke liye)
app.get('/api/health', (req, res) => {
  res.json({ ok: true, t: Date.now() });
});
// Diagnostic — masla dhoondne ke liye (uptime, memory, active jobs, aakhri errors)
app.get('/api/diag', (req, res) => {
  let active = [];
  try {
    for (const [id, a] of queue.active) active.push({ id, kind: a.kind });
  } catch {}
  res.json({
    ok: true,
    uptimeSec: Math.round((Date.now() - BOOT_TIME) / 1000),
    node: process.version,
    dbKind: db.dbKind,
    memoryMB: Math.round(process.memoryUsage().rss / 1024 / 1024),
    activeJobs: active,
    recentErrors,
    tools: { ytDlp: !!TOOLS.ytDlp, ytDlpVer: TOOLS.ytDlpVer || '', ffmpeg: !!TOOLS.ffmpeg },
  });
});

// ---------------- tool detection ----------------
function which(bin) {
  return new Promise((resolve) => {
    execFile(process.platform === 'win32' ? 'where' : 'which', [bin], (err, out) => {
      resolve(!err && !!String(out).trim());
    });
  });
}
function binVersion(bin, args) {
  return new Promise((resolve) => {
    execFile(bin, args, { timeout: 15000 }, (err, out) => {
      resolve(err ? '' : String(out).split('\n')[0].trim().slice(0, 60));
    });
  });
}
let TOOLS = { ytDlp: false, ytDlpVer: '', ffmpeg: false, aria2c: false, ytDlpPath: 'yt-dlp', ffmpegPath: 'ffmpeg', aria2cPath: 'aria2c' };
let CHILD_ENV = null;
function localToolPath(name) {
  const exe = process.platform === 'win32' ? `${name}.exe` : name;
  const p = path.join(ROOT, 'tools', exe);
  return fs.existsSync(p) ? p : null;
}
async function detectTools() {
  const localYd = localToolPath('yt-dlp');
  const localFf = localToolPath('ffmpeg');
  const localAr = localToolPath('aria2c');
  const [yd, ff, ar] = await Promise.all([
    localYd || which('yt-dlp'),
    localFf || which('ffmpeg'),
    localAr || which('aria2c'),
  ]);
  TOOLS = {
    ytDlp: yd, ytDlpVer: yd ? await binVersion(localYd || 'yt-dlp', ['--version']) : '',
    ffmpeg: ff, aria2c: ar,
    ytDlpPath: localYd || 'yt-dlp',
    ffmpegPath: localFf || 'ffmpeg',
    aria2cPath: localAr || 'aria2c',
  };
  if (localYd || localFf || localAr) {
    CHILD_ENV = { ...process.env, PATH: path.join(ROOT, 'tools') + path.delimiter + (process.env.PATH || '') };
  } else {
    CHILD_ENV = null;
  }
  // modules ke liye global
  global.__FBH_TOOLS = TOOLS;
  global.__FBH_CHILD_ENV = CHILD_ENV;
  return TOOLS;
}

app.get('/api/status', async (req, res) => {
  await detectTools();
  res.json({ ok: true, port: PORT, downloadsDir: getDownloadsDir(), tools: TOOLS });
});

// ---------------- SSE (keys + jobs) ----------------
const sseClients = new Set();
function broadcastSse(eventType, payload) {
  const msg = `event: ${eventType}\ndata: ${JSON.stringify(payload)}\n\n`;
  for (const c of sseClients) {
    try { c.write(msg); } catch { sseClients.delete(c); }
  }
}
function sseHandler(req, res) {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  sseClients.add(res);
  res.write(`event: connected\ndata: ${JSON.stringify({ status: 'connected', timestamp: new Date().toISOString() })}\n\n`);
  const hb = setInterval(() => {
    try { res.write(`event: ping\ndata: ${JSON.stringify({ t: Date.now() })}\n\n`); }
    catch { clearInterval(hb); sseClients.delete(res); }
  }, 20000);
  req.on('close', () => { clearInterval(hb); sseClients.delete(res); });
}
app.get('/api/jobs/events', sseHandler);

// ---------------- job queue ----------------
const queue = new JobQueue({
  getDownloadsDir: () => getDownloadsDir(),
  getTools: () => TOOLS,
  getChildEnv: () => CHILD_ENV || process.env,
  emit: (type, payload) => broadcastSse(type, payload),
  maxDownloads: parseInt(process.env.FBH_MAX_DL || '2', 10),
  maxUploads: parseInt(process.env.FBH_MAX_UP || '1', 10),
});

// POST /api/download {url, subfolder, quality, maxDownloads} — queue-based (item 13)
app.post('/api/download', async (req, res) => {
  const { url, subfolder, quality, maxDownloads } = req.body || {};
  const r = await queue.addDownload({ url, subfolder, quality, maxDownloads });
  if (!r.ok) return res.status(r.duplicate ? 409 : 400).json({ ok: false, error: r.error, duplicate: !!r.duplicate, jobId: r.jobId });
  res.json({ ok: true, jobId: r.jobId });
});

// POST /api/upload {pageId, pageToken, pageName, filepath, caption} — queue-based
app.post('/api/upload', async (req, res) => {
  const { pageId, pageToken, pageName, filepath, caption } = req.body || {};
  // path traversal guard (item 15)
  const _dd1 = getDownloadsDir();
  const rp = sec.resolveDownloadPath(_dd1, path.relative(_dd1, String(filepath || '')));
  if (!rp.ok) return res.status(400).json({ ok: false, error: rp.message });
  const r = await queue.addUpload({ pageId, pageToken, pageName, filepath: rp.path, caption });
  if (!r.ok) return res.status(400).json({ ok: false, error: r.error });
  queue.rememberUploadToken(r.jobId, pageToken);
  res.json({ ok: true, jobId: r.jobId });
});

// ---- jobs API (items 11, 13) ----
app.get('/api/jobs', (req, res) => {
  const limit = Math.min(200, parseInt(req.query.limit, 10) || 100);
  const offset = parseInt(req.query.offset, 10) || 0;
  const jobs = db.listJobs(limit, offset).map((j) => queue.publicJob(j));
  res.json({ ok: true, jobs, total: db.countJobs(), paused: queue.paused });
});
app.get('/api/job/:id', (req, res) => {
  const j = db.getJob(req.params.id);
  if (!j) return res.status(404).json({ ok: false, error: 'job nahi mila' });
  res.json({ ok: true, job: queue.publicJob(j) });
});
app.post('/api/job/:id/stop', (req, res) => {
  const r = queue.cancel(req.params.id);
  if (!r.ok) return res.status(404).json({ ok: false, error: r.error });
  res.json({ ok: true });
});
app.post('/api/jobs/:id/cancel', (req, res) => {
  const r = queue.cancel(req.params.id);
  if (!r.ok) return res.status(404).json({ ok: false, error: r.error });
  res.json({ ok: true, job: r.job });
});
app.post('/api/jobs/:id/retry', (req, res) => {
  const r = queue.retry(req.params.id);
  if (!r.ok) return res.status(400).json({ ok: false, error: r.error });
  res.json({ ok: true, job: r.job });
});
app.post('/api/jobs/:id/delete', (req, res) => {
  const ok = db.deleteJob(req.params.id);
  if (!ok) return res.status(404).json({ ok: false, error: 'job nahi mila' });
  res.json({ ok: true });
});
app.post('/api/jobs/queue/pause', (req, res) => {
  queue.setPaused(true);
  res.json({ ok: true, paused: true });
});
app.post('/api/jobs/queue/resume', (req, res) => {
  queue.setPaused(false);
  res.json({ ok: true, paused: false });
});

// GET /api/db/info — local database ki maloomat (user ke itminan ke liye)
app.get('/api/db/info', (req, res) => {
  let size = 0;
  try { size = fs.statSync(db.DB_PATH).size; } catch {}
  const counts = { total: 0, downloaded: 0, uploaded: 0, failed: 0 };
  try {
    counts.total = db.countJobs();
    for (const r of db.listJobs(10000, 0)) {
      if (r.download_status === 'downloaded') counts.downloaded += 1;
      if (r.upload_status === 'uploaded') counts.uploaded += 1;
      if (r.download_status === 'failed' || r.upload_status === 'failed') counts.failed += 1;
    }
  } catch {}
  res.json({
    ok: true,
    local: true,
    path: db.DB_PATH,
    sizeBytes: size,
    counts,
    note: 'Ye database SIRF is PC par hai (local file). Koi server, cloud ya bahari connection nahi.',
  });
});
// GET/POST /api/ui-state — creators + accounts mustaqil save (app dobara khule to sab wapas)
const UI_STATE_PATH = path.join(ROOT, 'data', 'ui_state.json');
function readUiState() {
  try {
    if (fs.existsSync(UI_STATE_PATH)) {
      const j = JSON.parse(fs.readFileSync(UI_STATE_PATH, 'utf-8'));
      return {
        creators: Array.isArray(j.creators) ? j.creators : [],
        accounts: Array.isArray(j.accounts) ? j.accounts : [],
      };
    }
  } catch {}
  return { creators: [], accounts: [] };
}
app.get('/api/ui-state', (req, res) => {
  res.json({ ok: true, ...readUiState() });
});
app.post('/api/ui-state', (req, res) => {
  const b = req.body || {};
  if (!Array.isArray(b.creators) || !Array.isArray(b.accounts)) {
    return res.status(400).json({ ok: false, error: 'Invalid state payload' });
  }
  // safety limits (koi pagalpan na ho)
  if (b.creators.length > 500 || b.accounts.length > 200) {
    return res.status(400).json({ ok: false, error: 'State bohat bari hai.' });
  }
  try {
    fs.mkdirSync(path.dirname(UI_STATE_PATH), { recursive: true });
    const tmp = UI_STATE_PATH + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify({ creators: b.creators, accounts: b.accounts, savedAt: new Date().toISOString() }), 'utf-8');
    fs.renameSync(tmp, UI_STATE_PATH);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: 'State save fail' });
  }
});

// GET/POST /api/settings/downloads-dir — user apne PC ka folder choose kare
// (yahan har creator ka apne naam ka folder banega)
app.get('/api/settings/downloads-dir', (req, res) => {
  // aam folders ki suggestions (user jaldi choose kar sake)
  const suggestions = [];
  try {
    const os = require('os');
    const home = os.homedir();
    const cands = [
      { label: '🖥️ Desktop', p: path.join(home, 'Desktop') },
      { label: '📄 Documents', p: path.join(home, 'Documents') },
      { label: '⬇️ Downloads', p: path.join(home, 'Downloads') },
      { label: '🎬 Videos', p: path.join(home, 'Videos') },
    ];
    for (const c of cands) {
      try { if (fs.existsSync(c.p)) suggestions.push(c); } catch {}
    }
    // Windows drives
    if (process.platform === 'win32') {
      for (const d of ['D:\\', 'E:\\', 'F:\\']) {
        try { if (fs.existsSync(d)) suggestions.push({ label: `💾 ${d}`, p: d }); } catch {}
      }
    }
  } catch {}
  res.json({ ok: true, path: getDownloadsDir(), isDefault: !db.kvGet('downloads_dir', ''), suggestions });
});
app.post('/api/settings/downloads-dir', (req, res) => {
  const r = setDownloadsDir((req.body || {}).path);
  if (!r.ok) return res.status(400).json({ ok: false, error: r.error });
  res.json({ ok: true, path: r.path });
});

app.post('/api/scrape', (req, res) => {
  const { url, sort } = req.body || {};
  const vu = yt.validateUrl(url);
  if (!vu.ok) return res.status(400).json({ ok: false, error: vu.error || vu.message });
  if (!TOOLS.ytDlp) return res.status(500).json({ ok: false, error: 'yt-dlp installed nahi hai' });

  // NOTE: yt-dlp --print mein '\t' ko lafzi text samajhta hai (tab nahi!) —
  // is liye format mein ASAL tab character bhejo taake split('\t') kaam kare.
  const args = ['--flat-playlist', '--no-warnings', '--no-colors',
    '--socket-timeout', '20',
    '--print', '%(id)s\t%(title)s\t%(webpage_url)s\t%(view_count)s\t%(upload_date)s',
    vu.url];
  execFile(TOOLS.ytDlpPath, args, { timeout: 120000, maxBuffer: 32 * 1024 * 1024, env: CHILD_ENV || process.env }, (err, stdout, stderr) => {
    const entries = [];
    for (const line of String(stdout || '').split('\n')) {
      // pehle asal tab par, na mile to lafzi '\t' par (purani yt-dlp compatibility)
      let parts = line.split('\t');
      if (parts.length < 3 && line.includes('\\t')) parts = line.split('\\t');
      if (parts.length < 3 || !parts[0].trim()) continue;
      const meta = { id: parts[0].trim(), title: (parts[1] || '').trim() || parts[0].trim(),
        webpage_url: (parts[2] || '').trim() || vu.url, view_count: parseInt(parts[3], 10) || 0,
        upload_date: (parts[4] || '').trim() };
      entries.push({
        id: meta.id, title: meta.title, url: meta.webpage_url, views: meta.view_count,
        view_count: meta.view_count, upload_date: meta.upload_date,
        _ts: yt.uploadDateMs(meta),
      });
      if (entries.length >= 500) break;
    }
    if (!entries.length) {
      const c = yt.classifyYtError(String(stderr || ''), err && err.code);
      return res.status(500).json({ ok: false, error: `koi link scrape nahi hui: ${c.message}`, kind: c.kind });
    }
    const sorted = yt.sortEntries(entries, sort).map(({ _ts, ...rest }) => rest);
    res.json({ ok: true, count: sorted.length, entries: sorted });
  });
});

// POST /api/delete {path} ya {all: true} — sirf downloads/ ke andar (item 15)
app.post('/api/delete', (req, res) => {
  const { path: p, all } = req.body || {};
  const VIDEO_EXTS = new Set(['.mp4', '.mov', '.mkv', '.avi', '.webm']);
  const PHOTO_EXTS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.bmp']);
  const isMedia = (f) => {
    const e = path.extname(f).toLowerCase();
    return VIDEO_EXTS.has(e) || PHOTO_EXTS.has(e);
  };
  let n = 0;
  const rm = (fp) => { try { if (fs.statSync(fp).isFile()) { fs.unlinkSync(fp); n++; } } catch {} };
  if (all) {
    const walk = (dir) => {
      let items = [];
      try { items = fs.readdirSync(dir); } catch { return; }
      for (const f of items) {
        const fp = path.join(dir, f);
        try {
          if (fs.statSync(fp).isDirectory()) walk(fp);
          else if (isMedia(f)) rm(fp);
        } catch {}
      }
    };
    walk(getDownloadsDir());
  } else if (p) {
    const _dd2 = getDownloadsDir();
    const rp = sec.resolveDownloadPath(_dd2, path.relative(_dd2, String(p)));
    if (!rp.ok) return res.status(400).json({ ok: false, error: rp.message });
    if (isMedia(rp.path)) rm(rp.path);
  }
  res.json({ ok: true, deleted: n });
});

// GET /api/files?subfolder= → newest first
app.get('/api/files', (req, res) => {
  const VIDEO_EXTS = new Set(['.mp4', '.mov', '.mkv', '.avi', '.webm']);
  const PHOTO_EXTS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.bmp']);
  const dir = path.join(getDownloadsDir(), sec.safeFolderName(req.query.subfolder || ''));
  const out = [];
  try {
    for (const f of fs.readdirSync(dir)) {
      const ext = path.extname(f).toLowerCase();
      if (!VIDEO_EXTS.has(ext) && !PHOTO_EXTS.has(ext)) continue;
      const fp = path.join(dir, f);
      try {
        const st = fs.statSync(fp);
        out.push({ name: f, path: fp, size: st.size, mtime: st.mtimeMs });
      } catch {}
    }
  } catch {}
  out.sort((a, b) => b.mtime - a.mtime);
  res.json({ ok: true, files: out });
});

// ---------------- Facebook: real sync (items 1, 2, 3) ----------------
// POST /api/fb/sync-pages {token} — har page ki validity ke saath
app.post('/api/fb/sync-pages', async (req, res) => {
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ ok: false, error: 'token missing' });
  const r = await fb.syncPages(String(token).trim());
  if (!r.ok) return res.status(400).json({ ok: false, error: r.message, kind: r.kind, stage: r.stage });
  res.json({ ok: true, user: r.user, pages: r.pages });
});
// POST /api/fb/sync-businesses {token}
app.post('/api/fb/sync-businesses', async (req, res) => {
  const { token } = req.body || {};
  if (!token) return res.status(400).json({ ok: false, error: 'token missing' });
  const r = await fb.syncBusinesses(String(token).trim());
  if (!r.ok) return res.status(400).json({ ok: false, error: r.message, kind: r.kind, stage: r.stage });
  res.json({ ok: true, user: r.user, businesses: r.businesses, permissionMissing: r.permissionMissing, note: r.note });
});
// POST /api/fb/validate-token {token}
app.post('/api/fb/validate-token', async (req, res) => {
  const { token } = req.body || {};
  const r = await fb.validateUserToken(String(token || '').trim());
  if (!r.ok) return res.json({ ok: true, valid: false, kind: r.kind, message: r.message });
  res.json({ ok: true, valid: true, id: r.id, name: r.name });
});

// POST /api/fb/validate-page-token {pageId, token} — browser se direct
// graph.facebook.com na pahunch sake to backend se verify (network-proof)
app.post('/api/fb/validate-page-token', async (req, res) => {
  const { pageId, token } = req.body || {};
  const r = await fb.validatePageToken(String(pageId || '').trim(), String(token || '').trim());
  if (!r.ok) return res.json({ ok: true, valid: false, kind: r.kind, message: r.message });
  res.json({ ok: true, valid: true, id: r.id, name: r.name });
});

// POST /api/fb/page-token {pageId, token(user)} — page ka asal access_token lao
app.post('/api/fb/page-token', async (req, res) => {
  const { pageId, token } = req.body || {};
  const pid = String(pageId || '').trim();
  const ut = String(token || '').trim();
  if (!pid || !ut) return res.json({ ok: true, found: false });
  const r = await fb.graphFetch('/' + pid, ut, { params: { fields: 'access_token' } });
  if (!r.ok || !r.data || !r.data.access_token) {
    return res.json({ ok: true, found: false });
  }
  res.json({ ok: true, found: true, token: r.data.access_token });
});

// POST /api/fb/fetch-pages {token} — user ID + pages (asal page tokens ke saath)
// Browser se direct graph.facebook.com na pahunch sake to backend se.
app.post('/api/fb/fetch-pages', async (req, res) => {
  const { token } = req.body || {};
  const r = await fb.syncPages(String(token || '').trim());
  if (!r.ok) return res.json({ ok: true, valid: false, kind: r.kind, message: r.message, stage: r.stage });
  res.json({ ok: true, valid: true, user: r.user, pages: r.pages });
});

// ---------------- OAuth (item 1) ----------------
app.get('/api/oauth/config', (req, res) => {
  const c = oauth.getAppConfig();
  res.json({ ok: true, configured: oauth.isConfigured(), appId: c.appId || '', hasSecret: !!c.appSecret });
});
app.post('/api/oauth/config', (req, res) => {
  const { appId, appSecret } = req.body || {};
  if (!appId || !String(appId).trim()) return res.status(400).json({ ok: false, error: 'App ID lazmi hai.' });
  oauth.setAppConfig(appId, appSecret);
  res.json({ ok: true, configured: oauth.isConfigured() });
});
// Step 2: authorize URL (state CSRF ke saath)
app.get('/api/oauth/start', (req, res) => {
  const r = oauth.startOAuth(PORT);
  if (!r.ok) return res.status(400).json({ ok: false, error: r.error });
  res.json({ ok: true, url: r.url });
});
// Step 4-5: Facebook yahan redirect karta hai
app.get('/oauth/callback', async (req, res) => {
  const { code, state, error, error_description } = req.query || {};
  const fail = (msg) => res.send(oauthPage(false, msg));
  if (error) return fail(`Facebook ne ijazat nahi di: ${error_description || error}`);
  const r = await oauth.handleCallback(code, state, PORT);
  if (!r.ok) return fail(r.error);
  // kamyabi: token + pages ko extension_sync format mein save karo taake UI foran use kare
  try {
    const payload = {
      ok: true, synced: true, app: 'fbhelperpro',
      user: r.user, user_token: r.token,
      pages: (r.pages || []).map((p) => ({
        page_id: p.page_id, name: p.name, category: p.category || 'Page', token: p.token,
      })),
      businesses: [], synced_at: new Date().toISOString(), via: 'oauth',
    };
    fs.mkdirSync(path.dirname(EXT_SYNC_PATH), { recursive: true });
    fs.writeFileSync(EXT_SYNC_PATH, JSON.stringify(payload, null, 2), 'utf-8');
  } catch {}
  res.send(oauthPage(true, `${r.user.name} — ${(r.pages || []).length} pages connected!`));
});
function oauthPage(ok, msg) {
  return `<!DOCTYPE html><html><head><meta charset="utf-8"><title>FB Helper Pro</title>
<style>body{font-family:sans-serif;background:#0f172a;color:#e2e8f0;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
.box{text-align:center;background:#1e293b;padding:40px;border-radius:16px;border:1px solid #334155;max-width:420px}
h2{margin:0 0 8px;color:${ok ? '#34d399' : '#f87171'}}p{color:#94a3b8;font-size:13px}</style></head>
<body><div class="box"><h2>${ok ? '✅ Ijazat mil gayi!' : '❌ Masla hua'}</h2><p>${String(msg).slice(0, 200)}</p><p>Ye tab band karke tool mein wapas jao.</p></div></body></html>`;
}
// OAuth last-sync metadata (tokens ke baghair — extension ke liye safe)
app.get('/api/oauth/last-sync', (req, res) => {
  try {
    const j = JSON.parse(fs.readFileSync(EXT_SYNC_PATH, 'utf-8'));
    if (j && j.synced) {
      return res.json({
        ok: true,
        synced: true,
        via: j.via || '',
        synced_at: j.synced_at || '',
        token_synced_at: j.token_synced_at || j.synced_at || '',
        page_count: Array.isArray(j.pages) ? j.pages.length : 0,
        user_name: (j.user && j.user.name) || '',
        page_names: (j.pages || []).map((x) => String((x && x.name) || (x && x.page_id) || '')),
      });
    }
  } catch {}
  res.json({ ok: true, synced: false });
});

// Token status: expiry/revoke detection
app.post('/api/oauth/status', async (req, res) => {
  const { token } = req.body || {};
  const r = await oauth.tokenStatus(String(token || '').trim());
  res.json({ ok: true, ...r });
});

// ================= SIGNED LICENSE SYSTEM (no key database) =================
// Keys khud mukammal hain: HWID lock + expiry key ke andar hoti hai,
// HMAC-SHA256 signature ke saath. Tool local verify karta hai —
// koi keys_database.json nahi, koi sync nahi. Nayi keys SIRF owner
// keygen se banti hain (isi secret se signed).
const FBH_LICENSE_SECRET = 'FBH1-SIGN-IKYrY6MdAgt6dI0uUu-QRnF2YAWMSIYr';
const LICENSE_PATH = path.join(ROOT, 'data', 'license.json');
const PLAN_NAMES_LIC = ['7 Days', '15 Days', '30 Days', '90 Days', '1 Year', 'Lifetime'];
const B32A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32dec(str) {
  const clean = String(str).toUpperCase().replace(/[^A-Z2-7]/g, '');
  const out = [];
  let bits = 0, val = 0;
  for (const ch of clean) {
    val = (val << 5) | B32A.indexOf(ch); bits += 5;
    if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; }
  }
  return Buffer.from(out);
}
function parseSignedLicenseKey(key) {
  const norm = String(key || '').trim().toUpperCase();
  if (!norm.startsWith('FBH1-')) return { ok: false, error: 'Invalid key format' };
  let raw;
  try { raw = b32dec(norm.slice(5)); } catch (e) { return { ok: false, error: 'Invalid key format' }; }
  if (raw.length !== 30) return { ok: false, error: 'Invalid key format' };
  const payload = raw.subarray(0, 18), sig = raw.subarray(18, 30);
  if (payload[0] !== 0x01) return { ok: false, error: 'Unsupported key version' };
  const expect = crypto.createHmac('sha256', FBH_LICENSE_SECRET).update(payload).digest().subarray(0, 12);
  let diff = 0;
  for (let i = 0; i < 12; i++) diff |= sig[i] ^ expect[i];
  if (diff !== 0) return { ok: false, error: 'Invalid license signature' };
  const plan = payload[1];
  if (plan > 5) return { ok: false, error: 'Invalid plan in key' };
  return {
    ok: true, plan, planName: PLAN_NAMES_LIC[plan],
    expiry: payload.readUInt32BE(2),
    hwidHash: payload.subarray(6, 14),
    isLifetime: plan === 5,
  };
}
function verifySignedLicenseKey(key, hwid) {
  const parsed = parseSignedLicenseKey(key);
  if (!parsed.ok) return parsed;
  const hwHash = crypto.createHash('sha256').update(String(hwid || '').trim(), 'utf8').digest().subarray(0, 8);
  let diff = 0;
  for (let i = 0; i < 8; i++) diff |= parsed.hwidHash[i] ^ hwHash[i];
  if (diff !== 0) return { ok: false, error: 'License is locked to another machine (HWID mismatch).' };
  if (!parsed.isLifetime && parsed.expiry * 1000 <= Date.now())
    return { ok: false, error: 'License expired on ' + new Date(parsed.expiry * 1000).toLocaleDateString() + '.' };
  parsed.ok = true;
  return parsed;
}
function readLicenseFile() {
  try {
    if (fs.existsSync(LICENSE_PATH)) return JSON.parse(fs.readFileSync(LICENSE_PATH, 'utf-8'));
  } catch (e) {}
  return null;
}
function writeLicenseFile(data) {
  try {
    fs.mkdirSync(path.dirname(LICENSE_PATH), { recursive: true });
    fs.writeFileSync(LICENSE_PATH, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (e) { return false; }
}
function licenseSession(key, hwid, parsed, activatedAt) {
  return {
    key: String(key).trim().toUpperCase(),
    plan: PLAN_NAMES_LIC[parsed.plan],
    planName: parsed.isLifetime ? 'Lifetime VIP Enterprise' : PLAN_NAMES_LIC[parsed.plan] + ' Pro License',
    clientName: '',
    activatedAt: activatedAt || new Date().toISOString(),
    expiresAt: parsed.isLifetime ? null : new Date(parsed.expiry * 1000).toISOString(),
    hwid: hwid || '',
    isLifetime: parsed.isLifetime,
  };
}
app.post('/api/license/activate', (req, res) => {
  const b = req.body || {};
  if (!b.key || typeof b.key !== 'string') return res.status(400).json({ success: false, error: 'Key is required' });
  const v = verifySignedLicenseKey(b.key, b.hwid || '');
  if (!v.ok) return res.status(403).json({ success: false, error: v.error });
  const lic = { key: String(b.key).trim().toUpperCase(), hwid: String(b.hwid || '').trim(), activatedAt: new Date().toISOString() };
  writeLicenseFile(lic);
  res.json({ success: true, session: licenseSession(b.key, lic.hwid, v, lic.activatedAt) });
});
app.post('/api/license/verify', (req, res) => {
  const b = req.body || {};
  const lic = readLicenseFile();
  const useKey = (b.key && String(b.key).trim()) || (lic && lic.key) || '';
  const useHwid = (b.hwid && String(b.hwid).trim()) || (lic && lic.hwid) || '';
  if (!useKey) return res.json({ isValid: false, error: 'No license found' });
  const v = verifySignedLicenseKey(useKey, useHwid);
  if (!v.ok) return res.json({ isValid: false, error: v.error });
  res.json({ isValid: true, session: licenseSession(useKey, useHwid, v, lic && lic.activatedAt) });
});
app.post('/api/license/deactivate', (req, res) => {
  try { if (fs.existsSync(LICENSE_PATH)) fs.unlinkSync(LICENSE_PATH); } catch (e) {}
  res.json({ success: true });
});
// ================= /SIGNED LICENSE SYSTEM =================

// ================= BROWSER EXTENSION 1-CLICK SYNC =================
const EXT_SYNC_PATH = path.join(ROOT, 'data', 'extension_sync.json');

app.post('/api/extension-sync', (req, res) => {
  const b = req.body || {};
  if (!b.user || !Array.isArray(b.pages)) {
    return res.status(400).json({ ok: false, error: 'Invalid sync payload' });
  }
  // PURANA sync parho — naya khaali token purane SAHI token ko NA mitaye.
  // (OAuth/import se aaya asal page token, scraping re-sync par khaali aata hai.)
  let oldPages = [];
  let oldVia = '';
  let oldTokenAt = '';
  let oldUserToken = '';
  try {
    const old = JSON.parse(fs.readFileSync(EXT_SYNC_PATH, 'utf-8'));
    if (old && old.synced) {
      oldPages = Array.isArray(old.pages) ? old.pages : [];
      oldVia = old.via || '';
      oldTokenAt = old.token_synced_at || '';
      oldUserToken = old.user_token || '';
    }
  } catch {}
  const oldById = new Map(oldPages.map((x) => [String(x.page_id), x]));
  let keptTokens = 0;
  const pages = b.pages
    .filter((p) => p && p.page_id)
    .map((p) => {
      const pid = String(p.page_id);
      const old = oldById.get(pid);
      let token = String(p.token || '');
      let valid = p.page_token_valid !== false;
      if (!token && old && old.token) {
        token = String(old.token); // purana sahi token rakho
        valid = old.page_token_valid !== false;
        keptTokens += 1;
      }
      return {
        page_id: pid,
        name: String(p.name || (old && old.name) || pid),
        category: String(p.category || (old && old.category) || 'Page'),
        token,
        // false = extension Tier 2/3 se sirf ID mili, page token nahi (naqli user token kabhi nahi)
        page_token_valid: valid,
      };
    });
  const businesses = Array.isArray(b.businesses)
    ? b.businesses.filter((x) => x && x.bm_id).map((x) => ({ bm_id: String(x.bm_id), name: String(x.name || x.bm_id) }))
    : [];
  const newVia = String(b.via || '');
  const nowIso = new Date().toISOString();
  const payload = {
    ok: true,
    synced: true,
    app: 'fbhelperpro',
    user: { id: String(b.user.id || ''), name: String(b.user.name || '') },
    user_token: String(b.user_token || '') || oldUserToken,
    pages,
    businesses,
    synced_at: nowIso,
    via: newVia || oldVia || '',
    // tokens kab ke hain (extension freshness check ke liye)
    token_synced_at: (newVia === 'oauth' || (pages.some((x) => x.token) && !oldTokenAt)) ? nowIso : (oldTokenAt || nowIso),
  };
  if (keptTokens > 0) console.log(`[extension-sync] ${keptTokens} purane page token(s) mehfooz rakhe (naye sync mein khaali thay)`);
  try {
    fs.mkdirSync(path.dirname(EXT_SYNC_PATH), { recursive: true });
    fs.writeFileSync(EXT_SYNC_PATH, JSON.stringify(payload, null, 2), 'utf-8');
  } catch (e) {
    return res.status(500).json({ ok: false, error: 'Sync save failed' });
  }
  console.log(`[extension-sync] ${payload.user.name}: ${pages.length} pages, ${businesses.length} BMs`);
  res.json({ ok: true, saved: pages.length, savedBm: businesses.length, user: payload.user.name });
});

app.get('/api/extension-sync', (req, res) => {
  try {
    if (fs.existsSync(EXT_SYNC_PATH)) {
      return res.json(JSON.parse(fs.readFileSync(EXT_SYNC_PATH, 'utf-8')));
    }
  } catch {}
  res.json({ ok: false, synced: false, error: 'No sync data yet — pehle extension se 1-CLICK SYNC dabao.' });
});
// ================= /EXTENSION SYNC =================

// Owner keygen page — SIRF tab serve hota hai jab keygen.html file maujood ho.
app.get('/keygen.html', (req, res) => {
  const p = path.join(ROOT, 'keygen.html');
  if (fs.existsSync(p)) res.sendFile(p);
  else res.status(404).send('not found');
});

// production: built UI serve karo (token bootstrap inject ke saath)
const DIST = path.join(ROOT, 'dist');
app.use('/downloads', (req, res, next) => express.static(getDownloadsDir())(req, res, next));
if (fs.existsSync(DIST)) {
  app.use(express.static(DIST));
  app.get('*', (req, res) => {
    if (req.path.startsWith('/api/')) return res.status(404).json({ ok: false });
    try {
      let html = fs.readFileSync(path.join(DIST, 'index.html'), 'utf-8');
      // local auth token UI mein inject (api.ts isko x-fbh-token header mein bhejta hai)
      html = html.replace('</head>', `<script>window.__FBH_LOCAL_TOKEN=${JSON.stringify(sec.LOCAL_TOKEN)};</script></head>`);
      res.send(html);
    } catch {
      res.sendFile(path.join(DIST, 'index.html'));
    }
  });
}

// ---- boot ----
detectTools().then(() => {
  // crash recovery (item 14)
  const rec = db.recoverInterruptedJobs();
  if (rec.downloadsRecovered || rec.uploadsRecovered) {
    console.log(`[recovery] ${rec.downloadsRecovered} downloads, ${rec.uploadsRecovered} uploads dobara queue`);
  }
  queue.start();

  const printBanner = (hostLabel) => {
    console.log(`FBHelperPro backend v9.6 running: http://${hostLabel}:${PORT}`);
    console.log(`yt-dlp: ${TOOLS.ytDlp ? TOOLS.ytDlpVer || 'OK' : 'MISSING'} | ffmpeg: ${TOOLS.ffmpeg ? 'OK' : 'MISSING'} | aria2c: ${TOOLS.aria2c ? 'OK' : 'MISSING'}`);
    console.log(`jobs DB: ${db.DB_PATH} (${db.dbKind})`);
    console.log(`Node: ${process.version}`);
  };
  const srv = app.listen(PORT, '127.0.0.1', () => printBanner('127.0.0.1'));
  srv.on('error', (e) => {
    if (e.code === 'EADDRINUSE') {
      console.error(`\n❌ Port ${PORT} pehle se use mein hai! Purana backend band karo phir dobara chalao.`);
      console.error(`   (Task Manager mein purani "node server.cjs" window band karo)\n`);
    } else {
      console.error('❌ Server start fail:', e.message);
    }
    process.exit(1);
  });
  try {
    const s6 = app.listen(PORT, '::1', () => console.log(`FBHelperPro backend (IPv6 loopback): http://[::1]:${PORT}`));
    s6.on('error', (e) => console.log(`(IPv6 loopback unavailable: ${e.code})`));
  } catch (e) {
    console.log(`(IPv6 loopback unavailable: ${e.message})`);
  }
});
