FB Helper Pro — Tools Folder
============================

Is folder mein ye 3 files rakho (PATH set karne ki zaroorat NAHI):

  1. yt-dlp.exe       → https://github.com/yt-dlp/yt-dlp/releases (yt-dlp.exe)
  2. ffmpeg.exe       → https://www.gyan.dev/ffmpeg/builds/ (ffmpeg-release-essentials.zip se ffmpeg.exe)
  3. aria2c.exe       → https://github.com/aria2/aria2/releases (aria2-*-win-64bit.zip se aria2c.exe)

Server khud is folder ko pehle check karta hai.
Agar ye files yahan na hon to server system PATH mein dhoondta hai.

Check: app kholne ke baad terminal mein likha aayega
  yt-dlp: 2026.xx.xx | ffmpeg: OK | aria2c: OK
