<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# FBHelperPro — Real Backend Edition

UI bilkul waisa ka waisa hai. Naqli (setTimeout) download/upload ki jagah **asal system** lag gaya hai:

- **Real downloading**: `server.cjs` (Express, port 8573) `yt-dlp` chalata hai — aria2c 16-connection speed (agar installed ho), per-creator folders (`downloads/<creator>/`), progress polling
- **Dono upload methods** (AutoFarm wale): video → `/{page-id}/videos`, photo → `/{page-id}/photos` (Facebook Graph API v21.0)
- Dashboard **START FARMING** = asal download; Page Mapping **Upload / Upload All** = asal Facebook upload + Posts count

## Chalane ka tareeqa

1. `yt-dlp` aur `ffmpeg` install karo (PATH mein hon):
   - Windows: `winget install yt-dlp yt-dlp` / ffmpeg: https://www.gyan.dev/ffmpeg/builds/
2. `npm install --legacy-peer-deps`
3. `npm run server` — backend (http://localhost:8573)
4. Alag terminal: `npm run dev` — UI (http://localhost:3000)
   - Ya production: `npm run build` phir `npm run server` (dist khud serve hogi)

> `/api/status` par check karo ke yt-dlp/ffmpeg detect ho rahe hain.

## 🔑 License Key System

App khulne par **license key** mangegi (HWID-locked):
- Key **FBHelperPro_Keygen_OwnerTool.zip** (alag owner package) mein `keygen.html` se banao — backend chalte hue browser mein kholo
- Database: `data/keys_database.json` (server par, backup ke saath)
- Plans: 7/15/30/90 Days, 1 Year, Lifetime • maxDevices + HWID lock + revoke support
- Offline fallback: internet na ho to cached license chalti rehti hai

## 🧩 Chrome Extension — 1-Click Sync

`extension/` folder mein ready extension hai (Manifest V3):

1. Chrome mein `chrome://extensions` kholo → **Developer mode** ON → **Load unpacked** → `extension/` folder select karo
2. **facebook.com** par login karo (ek tab mein khula ho)
3. Extension icon dabao → **⚡ 1-CLICK SYNC**
4. FB Helper Pro app mein **Page Connect & Mapping** tab → **⚡ Sync from Extension** dabao — pages + BMs import ho jayenge

- Extension sirf `http://127.0.0.1:8573` se baat karta hai — koi data bahar nahi jata
- Tokens sirf memory mein rehte hain, disk par save nahi hote
- **👁 Show Token** button se token copy karke manually bhi paste kar sakte ho

## 🛠 yt-dlp / ffmpeg / aria2c kahan rakhein?

**Koi PATH setting nahi chahiye.** Bas app wale folder mein `tools/` folder mein ye 3 files daal do:

```
FBHelperPro/
├── server.cjs
├── tools/
│   ├── yt-dlp.exe      ← https://github.com/yt-dlp/yt-dlp/releases
│   ├── ffmpeg.exe      ← https://www.gyan.dev/ffmpeg/builds/ (essentials zip se)
│   └── aria2c.exe      ← https://github.com/aria2/aria2/releases
├── data/
└── ...
```

Server khud `tools/` ko pehle check karta hai. Agar wahan na hon to system PATH mein dhoondta hai.
App start hone par terminal mein likha aayega: `yt-dlp: 2026.xx.xx | ffmpeg: OK | aria2c: OK`

---

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/6aa6988c-d2e9-4eb6-94ff-c38d33e9076a

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`
