/**
 * FBHelperPro — Facebook Graph API helpers
 *
 * - Token validation (user + page), expired/revoked detection (error 190 subcodes)
 * - Real pages sync (/me/accounts) with per-page validity check
 * - Real Business Manager sync (/me/businesses) — permission na ho to saaf report
 * - Robust upload: validation → upload → post ID → verify
 * - Resumable (chunked) video upload: start → transfer → finish
 * - Bytes-based progress, asal Graph API errors surface
 */
const fs = require('fs');

const GRAPH = 'https://graph.facebook.com/v21.0';
const LARGE_FILE_THRESHOLD = 100 * 1024 * 1024; // 100MB se bara = resumable

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

/** Graph API call — hamesha {ok, data} ya {ok:false, fbError} */
async function graphFetch(path, token, opts = {}) {
  const url = new URL(GRAPH + path);
  url.searchParams.set('access_token', token);
  for (const [k, v] of Object.entries(opts.params || {})) url.searchParams.set(k, v);
  let res;
  try {
    res = await fetch(url.toString(), {
      method: opts.method || 'GET',
      body: opts.body,
      headers: opts.headers,
      signal: opts.signal,
    });
  } catch (e) {
    return { ok: false, networkError: String(e.message || e).slice(0, 160) };
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok || data.error) {
    return { ok: false, fbError: data.error || { message: `HTTP ${res.status}`, code: res.status } };
  }
  return { ok: true, data };
}

/**
 * FB error ko insani (Urdu/English) message mein badlo — item 16
 * 190/463 = expired, 190/467 = invalid, 190/458 = app restricted, 200-299 = permission
 */
function classifyFbError(fbError) {
  const code = fbError && fbError.code;
  const sub = fbError && fbError.error_subcode;
  const msg = (fbError && fbError.message) || 'Unknown Facebook error';
  if (code === 190) {
    if (sub === 463) return { kind: 'token_expired', message: `Token EXPIRED hai: ${msg} — dobara login karo.` };
    if (sub === 467) return { kind: 'token_invalid', message: `Token INVALID hai: ${msg} — naya token lo.` };
    if (sub === 458) return { kind: 'token_app_restricted', message: `App restricted: ${msg}` };
    return { kind: 'token_error', message: `Token masla (190): ${msg} — dobara login karo.` };
  }
  if (code === 200 || code === 10 || (code >= 200 && code < 300)) {
    return { kind: 'permission', message: `Permission nahi hai: ${msg}` };
  }
  if (code === 100) return { kind: 'param', message: `Ghalat request: ${msg}` };
  if (/invalid request/i.test(msg)) {
    return {
      kind: 'token_type',
      message: `Facebook ne request reject ki ("Invalid request") — aksar wajah: page token ki jagah USER token, ya token mein pages_manage_posts permission nahi. Page dobara connect karo.`,
    };
  }
  if (code === 4 || code === 17 || code === 32) {
    return { kind: 'rate_limit', message: `Facebook rate limit: ${msg} — thoda ruko phir retry karo.` };
  }
  return { kind: 'unknown', message: msg.slice(0, 220) };
}

/** User token validate karo — item 1 */
async function validateUserToken(token) {
  if (!token || typeof token !== 'string' || token.length < 20) {
    return { ok: false, kind: 'token_invalid', message: 'Token khaali ya bohat chhota hai.' };
  }
  const r = await graphFetch('/me', token, { params: { fields: 'id,name' } });
  if (!r.ok) {
    if (r.networkError) return { ok: false, kind: 'network', message: `Network: ${r.networkError}` };
    const c = classifyFbError(r.fbError);
    return { ok: false, ...c, fbError: r.fbError };
  }
  return { ok: true, id: r.data.id, name: r.data.name };
}

/** Page token validate karo — /{page-id} page token se */
async function validatePageToken(pageId, pageToken) {
  const r = await graphFetch(`/${pageId}`, pageToken, { params: { fields: 'id,name' } });
  if (!r.ok) {
    if (r.networkError) return { ok: false, kind: 'network', message: `Network: ${r.networkError}` };
    const c = classifyFbError(r.fbError);
    return { ok: false, ...c, fbError: r.fbError };
  }
  // TOKEN TYPE CHECK: /me se dekho ye token asal mein kis ka hai.
  // Page token hona chahiye — agar /me user ID de to ye USER token hai,
  // jo upload par "Invalid request" se fail hota hai.
  try {
    const me = await graphFetch('/me', pageToken, { params: { fields: 'id' } });
    if (me.ok && me.data && me.data.id && String(me.data.id) !== String(r.data.id)) {
      return {
        ok: false,
        kind: 'token_type',
        message: `Ye USER token hai, PAGE token nahi — "${r.data.name || pageId}" ke liye page dobara connect karo taake asal page token aaye.`,
      };
    }
  } catch (e) { /* /me na chale to purana behavior */ }
  return { ok: true, id: r.data.id, name: r.data.name };
}

/** Real pages sync — item 2: har page ki validity check ke saath */
async function syncPages(userToken) {
  const me = await validateUserToken(userToken);
  if (!me.ok) return { ok: false, ...me, stage: 'token' };
  const r = await graphFetch('/me/accounts', userToken, {
    params: { fields: 'id,name,category,access_token,picture{url},tasks', limit: '100' },
  });
  if (!r.ok) {
    if (r.networkError) return { ok: false, kind: 'network', message: r.networkError, stage: 'pages' };
    const c = classifyFbError(r.fbError);
    return { ok: false, ...c, stage: 'pages', fbError: r.fbError };
  }
  const raw = Array.isArray(r.data.data) ? r.data.data : [];
  const pages = [];
  for (const p of raw) {
    if (!p.id || !p.access_token) continue;
    // Har page ka token alag se verify karo (item 2: invalid ko "Connected" mat dikhao)
    const v = await validatePageToken(p.id, p.access_token);
    pages.push({
      page_id: String(p.id),
      name: p.name || String(p.id),
      category: p.category || 'Page',
      token: p.access_token,
      picture: (p.picture && p.picture.data && p.picture.data.url) || '',
      tasks: Array.isArray(p.tasks) ? p.tasks : [],
      token_valid: v.ok,
      token_error: v.ok ? '' : (v.message || 'invalid'),
    });
  }
  return { ok: true, user: { id: me.id, name: me.name }, pages };
}

/** Real Business Manager sync — item 3 */
async function syncBusinesses(userToken) {
  const me = await validateUserToken(userToken);
  if (!me.ok) return { ok: false, ...me, stage: 'token' };
  const r = await graphFetch('/me/businesses', userToken, { params: { fields: 'id,name', limit: '50' } });
  if (!r.ok) {
    if (r.networkError) return { ok: false, kind: 'network', message: r.networkError, stage: 'businesses' };
    const c = classifyFbError(r.fbError);
    // business_management permission na ho to saaf batao, fake BM mat banao
    if (c.kind === 'permission') {
      return { ok: true, user: { id: me.id, name: me.name }, businesses: [], permissionMissing: true,
        note: 'business_management permission nahi hai — BM sync ke liye dobara OAuth karo ya token mein permission do.' };
    }
    return { ok: false, ...c, stage: 'businesses', fbError: r.fbError };
  }
  const list = Array.isArray(r.data.data) ? r.data.data : [];
  const businesses = [];
  for (const b of list) {
    // Har BM ke owned pages (agar API de to)
    let ownedPages = [];
    try {
      const pr = await graphFetch(`/${b.id}/owned_pages`, userToken, { params: { fields: 'id,name', limit: '100' } });
      if (pr.ok && Array.isArray(pr.data.data)) {
        ownedPages = pr.data.data.map((p) => ({ page_id: String(p.id), name: p.name || String(p.id) }));
      }
    } catch {}
    businesses.push({ bm_id: String(b.id), name: b.name || String(b.id), owned_pages: ownedPages });
  }
  return { ok: true, user: { id: me.id, name: me.name }, businesses, permissionMissing: false };
}

// ---------------- upload engine ----------------

/** File validation — item 4 step 1 */
function validateUploadFile(filePath) {
  if (!filePath || typeof filePath !== 'string') return { ok: false, message: 'File path missing hai.' };
  let st;
  try { st = fs.statSync(filePath); }
  catch { return { ok: false, message: `File nahi mili: ${filePath}` }; }
  if (!st.isFile()) return { ok: false, message: 'Ye file nahi hai.' };
  if (st.size <= 0) return { ok: false, message: 'File khaali hai (0 bytes).' };
  // Facebook video limit ~10GB; photo ~10MB (API)
  return { ok: true, size: st.size };
}

/**
 * Resumable video upload (start → transfer → finish) — item 5
 * onProgress(bytesSent, totalBytes)
 * Returns {ok, videoId} ya {ok:false, ...}
 */
async function uploadVideoResumable(pageId, pageToken, filePath, caption, onProgress, signal) {
  const fv = validateUploadFile(filePath);
  if (!fv.ok) return { ok: false, kind: 'file', message: fv.message };
  const fileSize = fv.size;
  const fileName = filePath.split(/[/\\]/).pop();

  // PHASE 1: start — upload session banao
  const startParams = { upload_phase: 'start', file_size: String(fileSize) };
  let r = await graphFetch(`/${pageId}/videos`, pageToken, { method: 'POST', params: startParams, signal });
  if (!r.ok) {
    if (r.networkError) return { ok: false, kind: 'network', message: r.networkError };
    const c = classifyFbError(r.fbError);
    return { ok: false, ...c, fbError: r.fbError, phase: 'start' };
  }
  const sessionId = r.data.upload_session_id;
  const videoId = r.data.video_id;
  if (!sessionId) return { ok: false, kind: 'unknown', message: 'Upload session nahi bani (Facebook ne session ID nahi di).' };

  // PHASE 2: transfer — chunks bhejo
  const CHUNK = 8 * 1024 * 1024; // 8MB chunks
  const fd = fs.openSync(filePath, 'r');
  let offset = 0;
  try {
    const buf = Buffer.alloc(CHUNK);
    while (offset < fileSize) {
      if (signal && signal.aborted) throw new Error('cancelled');
      const want = Math.min(CHUNK, fileSize - offset);
      const read = fs.readSync(fd, buf, 0, want, offset);
      if (read <= 0) break;
      const chunk = buf.subarray(0, read);
      // chunk ko multipart ke bajaye raw body mein bhejo
      const tUrl = new URL(`${GRAPH}/${pageId}/videos`);
      tUrl.searchParams.set('access_token', pageToken);
      tUrl.searchParams.set('upload_phase', 'transfer');
      tUrl.searchParams.set('upload_session_id', sessionId);
      tUrl.searchParams.set('start_offset', String(offset));
      // Chunk ko 3 dafa retry karo — flaky network par aik chunk fail hone se
      // POORA upload dobara nahi hoga, sirf wahi chunk dobara jayega.
      let tr = null, tj = null, lastErr = '';
      for (let attempt = 1; attempt <= 3; attempt++) {
        if (signal && signal.aborted) throw new Error('cancelled');
        try {
          tr = await fetch(tUrl.toString(), { method: 'POST', body: chunk,
            headers: { 'Content-Type': 'application/octet-stream' }, signal });
        } catch (e) {
          lastErr = String(e.message || e).slice(0, 100);
          tr = null;
        }
        if (tr) {
          tj = await tr.json().catch(() => ({}));
          if (tr.ok && !tj.error) break; // chunk kamyab
          lastErr = (tj && tj.error && tj.error.message) || `HTTP ${tr.status}`;
          break; // Facebook ne jawab diya (error ke saath) — retry ka faida nahi
        }
        if (attempt < 3) await sleep(1500 * attempt); // network fail par 1.5s, 3s ruko
      }
      if (!tr) {
        return { ok: false, kind: 'network', message: `Chunk upload network fail (offset ${offset}, 3 tries): ${lastErr}`, phase: 'transfer' };
      }
      if (!tr.ok || (tj && tj.error)) {
        const c = classifyFbError((tj && tj.error) || { message: `HTTP ${tr.status}` });
        return { ok: false, ...c, fbError: tj && tj.error, phase: 'transfer' };
      }
      offset += read;
      if (onProgress) { try { onProgress(offset, fileSize); } catch {} }
    }
  } finally {
    try { fs.closeSync(fd); } catch {}
  }

  // PHASE 3: finish
  r = await graphFetch(`/${pageId}/videos`, pageToken, {
    method: 'POST',
    params: { upload_phase: 'finish', upload_session_id: sessionId,
      title: (caption || fileName).slice(0, 100), description: caption || '' },
    signal,
  });
  if (!r.ok) {
    if (r.networkError) return { ok: false, kind: 'network', message: r.networkError };
    const c = classifyFbError(r.fbError);
    return { ok: false, ...c, fbError: r.fbError, phase: 'finish' };
  }
  // finish response mein video id hota hai; warna start wali
  const finalId = r.data.video_id || videoId || '';
  if (!finalId) return { ok: false, kind: 'unknown', message: 'Upload finish hua lekin Facebook ne video ID nahi di.', phase: 'finish' };
  return { ok: true, videoId: String(finalId) };
}

/** Chhoti video / photo ka simple upload (multipart) */
async function uploadSimple(pageId, pageToken, filePath, caption, isPhoto, onProgress, signal) {
  const fv = validateUploadFile(filePath);
  if (!fv.ok) return { ok: false, kind: 'file', message: fv.message };
  const fileName = filePath.split(/[/\\]/).pop();
  const endpoint = isPhoto ? `/${pageId}/photos` : `/${pageId}/videos`;
  const data = await fs.promises.readFile(filePath).catch(() => null);
  if (!data) return { ok: false, kind: 'file', message: 'File parhi nahi ja saki.' };
  const form = new FormData();
  form.append('access_token', String(pageToken));
  form.append('source', new Blob([data]), fileName);
  if (isPhoto) { if (caption) form.append('caption', String(caption)); }
  else if (caption) { form.append('title', String(caption).slice(0, 100)); form.append('description', String(caption)); }
  if (onProgress) { try { onProgress(data.length, data.length); } catch {} }
  const r = await graphFetch(endpoint, pageToken, { method: 'POST', body: form, signal });
  if (!r.ok) {
    if (r.networkError) return { ok: false, kind: 'network', message: r.networkError };
    const c = classifyFbError(r.fbError);
    return { ok: false, ...c, fbError: r.fbError };
  }
  const id = r.data.id || '';
  if (!id) return { ok: false, kind: 'unknown', message: 'Facebook ne post ID nahi di.' };
  return { ok: true, videoId: String(id) };
}

/** Upload verify — post/video ID se asal mein check karo (item 4, 12) */
async function verifyUpload(objectId, token) {
  const r = await graphFetch(`/${objectId}`, token, { params: { fields: 'id' } });
  if (!r.ok) {
    if (r.networkError) return { ok: false, kind: 'network', message: r.networkError };
    const c = classifyFbError(r.fbError);
    return { ok: false, ...c, fbError: r.fbError };
  }
  return { ok: true, id: r.data.id };
}

module.exports = {
  GRAPH, LARGE_FILE_THRESHOLD,
  graphFetch, classifyFbError,
  validateUserToken, validatePageToken,
  syncPages, syncBusinesses,
  validateUploadFile, uploadVideoResumable, uploadSimple, verifyUpload,
};
