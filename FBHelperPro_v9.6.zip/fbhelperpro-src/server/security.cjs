/**
 * FBHelperPro — API security (item 15)
 *
 * - Local auth token: pehle boot par random token → data/.local_token (sirf owner parh sakta hai).
 *   UI ko token index.html mein inject karke milta hai; API x-fbh-token header mangti hai.
 * - /api/extension-sync exempt hai (extension ke paas token nahi hota; localhost-only + payload validated).
 * - Path traversal guard: har file path DOWNLOADS ke andar resolve hona chahiye.
 * - Rate limiting: simple in-memory per-IP.
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const TOKEN_PATH = path.join(DATA_DIR, '.local_token');

function getLocalToken() {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(TOKEN_PATH)) {
      const t = fs.readFileSync(TOKEN_PATH, 'utf-8').trim();
      if (t.length >= 32) return t;
    }
    const t = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(TOKEN_PATH, t, { mode: 0o600 });
    return t;
  } catch {
    return 'fbh-local-fallback-token';
  }
}
const LOCAL_TOKEN = getLocalToken();

// Extension + status jaisi cheezon ke liye exempt paths
// NOTE: /api/extension-sync yahan NAHI — sirf POST exempt hai (neeche
// authMiddleware mein), taake GET se page tokens koi local process na parh sake.
const EXEMPT_PREFIXES = [
  '/api/auth/bootstrap',   // UI ko token dilata hai (same-origin localhost)
  '/api/health',           // halka health check (UI indicator + RUN.bat)
  '/api/diag',             // diagnostic (uptime/memory/errors — token nahi)
  '/oauth/callback',
  '/keygen.html',
  '/api/oauth/config',      // sirf {configured, appId, hasSecret} — secret value nahi
  '/api/oauth/start',       // sirf Facebook authorize URL — public info
  '/api/oauth/last-sync',   // sirf metadata (names/count) — tokens NAHI
];

function authMiddleware(req, res, next) {
  const p = req.path || '';
  // Chrome extension ke paas token nahi hota — sirf POST /api/extension-sync exempt
  // (sync data bhejne ke liye). GET par auth lazmi hai (page tokens leak na hon).
  if (p === '/api/extension-sync' && req.method === 'POST') return next();
  if (EXEMPT_PREFIXES.some((x) => p === x || p.startsWith(x + '/') || p.startsWith(x + '?'))) return next();
  // Static files (UI) bina token ke khul sakti hain — token HTML mein inject hota hai
  if (!p.startsWith('/api/')) return next();
  const got = req.headers['x-fbh-token'] || req.query.token;
  if (got && got === LOCAL_TOKEN) return next();
  return res.status(401).json({ ok: false, error: 'Unauthorized — x-fbh-token missing/invalid.' });
}

// ---- rate limiting (in-memory, per IP) ----
const buckets = new Map(); // ip -> {count, resetAt}
function rateLimit({ windowMs = 60000, max = 300 } = {}) {
  return (req, res, next) => {
    const p = req.path || '';
    if (!p.startsWith('/api/')) return next();
    if (p === '/api/health') return next(); // health check kabhi rate-limit nahi
    const ip = req.ip || req.socket.remoteAddress || 'local';
    const nowT = Date.now();
    let b = buckets.get(ip);
    if (!b || nowT > b.resetAt) { b = { count: 0, resetAt: nowT + windowMs }; buckets.set(ip, b); }
    b.count++;
    if (b.count > max) {
      return res.status(429).json({ ok: false, error: 'Rate limit — thoda ruko phir try karo.' });
    }
    next();
  };
}

// ---- path traversal guard ----
function resolveDownloadPath(downloadsDir, userPath) {
  const resolved = path.resolve(downloadsDir, '.' + path.sep + String(userPath || ''));
  const base = path.resolve(downloadsDir) + path.sep;
  if (resolved !== path.resolve(downloadsDir) && !resolved.startsWith(base)) {
    return { ok: false, message: 'Path downloads folder se bahar nahi ja sakta.' };
  }
  return { ok: true, path: resolved };
}

function safeFolderName(name) {
  const clean = String(name || 'creator').replace(/[<>:"/\\|?*\x00-\x1f]/g, '').trim().replace(/\s+/g, '_');
  return (clean || 'creator').slice(0, 40);
}

module.exports = {
  LOCAL_TOKEN, authMiddleware, rateLimit,
  resolveDownloadPath, safeFolderName, EXEMPT_PREFIXES,
};
