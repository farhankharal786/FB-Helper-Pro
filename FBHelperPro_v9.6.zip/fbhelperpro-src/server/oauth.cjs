/**
 * FBHelperPro — Production-grade Facebook OAuth (item 1)
 *
 * Flow:
 *   1. Owner Settings mein App ID + App Secret dalta hai (sirf is PC par, DB kv mein)
 *   2. GET /api/oauth/start → state (CSRF) banao → authorize URL do
 *   3. User Facebook par Continue dabata hai → GET /oauth/callback?code=...&state=...
 *   4. state validate → code exchange (server-side, secret kabhi browser mein nahi)
 *   5. Long-lived token exchange (60 din) → /me validate → pages fetch
 *   6. Token meta DB mein (expiry track); asal token memory + extension_sync flow mein
 *
 * Expiry detection: har validate par FB error 190 → kind batata hai (expired vs invalid)
 * Refresh: long-lived token dubara extend; expire ho to re-login ka rasta.
 */
const crypto = require('crypto');
const db = require('./db.cjs');
const fb = require('./fb.cjs');

const GRAPH_VERSION = 'v21.0';
const SCOPES = [
  'public_profile',
  'pages_show_list',
  'pages_read_engagement',
  'pages_manage_posts',
  'publish_video',
  'pages_manage_engagement',
  'read_insights',
].join(',');

function getAppConfig() {
  // Default App ID (public — secret nahi); user Settings mein apna Secret khud dalta hai
  const DEFAULT_APP_ID = '2484122532075561';
  const savedId = db.kvGet('oauth_app_id', '');
  return {
    appId: savedId || DEFAULT_APP_ID,
    appSecret: db.kvGet('oauth_app_secret', ''),
  };
}
function setAppConfig(appId, appSecret) {
  db.kvSet('oauth_app_id', String(appId || '').trim());
  db.kvSet('oauth_app_secret', String(appSecret || '').trim());
}
function isConfigured() {
  const c = getAppConfig();
  return !!(c.appId && c.appSecret);
}

/** Step 2: authorize URL + CSRF state */
function startOAuth(port) {
  const { appId } = getAppConfig();
  if (!appId) return { ok: false, error: 'Pehle Settings mein Facebook App ID + App Secret dalo.' };
  const state = crypto.randomBytes(24).toString('hex');
  // state 10 min valid
  db.kvSet('oauth_state', JSON.stringify({ state, exp: Date.now() + 10 * 60 * 1000 }));
  const redirectUri = `http://localhost:${port}/oauth/callback`;
  const url = 'https://www.facebook.com/' + GRAPH_VERSION + '/dialog/oauth' +
    `?client_id=${encodeURIComponent(appId)}` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}` +
    `&response_type=code&scope=${encodeURIComponent(SCOPES)}` +
    `&state=${encodeURIComponent(state)}`;
  return { ok: true, url, state };
}

/** Step 4-5: callback — code exchange + long-lived + validate */
async function handleCallback(code, state, port) {
  const { appId, appSecret } = getAppConfig();
  if (!appId || !appSecret) return { ok: false, error: 'OAuth configure nahi hai (App ID/Secret missing).' };
  // state CSRF validation
  let saved = null;
  try { saved = JSON.parse(db.kvGet('oauth_state', 'null')); } catch {}
  db.kvSet('oauth_state', '');
  if (!saved || saved.state !== state) {
    return { ok: false, error: 'CSRF state match nahi hui — dobara Connect dabao.' };
  }
  if (Date.now() > saved.exp) return { ok: false, error: 'OAuth session expire ho gayi — dobara try karo.' };
  if (!code) return { ok: false, error: 'Facebook ne code nahi diya.' };

  const redirectUri = `http://localhost:${port}/oauth/callback`;
  // code → short-lived token (server-side; secret kabhi browser mein nahi jata)
  const exUrl = `https://graph.facebook.com/${GRAPH_VERSION}/oauth/access_token` +
    `?client_id=${encodeURIComponent(appId)}` +
    `&client_secret=${encodeURIComponent(appSecret)}` +
    `&redirect_uri=${encodeURIComponent(redirectUri)}` +
    `&code=${encodeURIComponent(code)}`;
  let r;
  try { r = await fetch(exUrl); }
  catch (e) { return { ok: false, error: `Token exchange network fail: ${String(e.message).slice(0, 100)}` }; }
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) {
    const c = fb.classifyFbError(j.error || { message: `HTTP ${r.status}` });
    return { ok: false, error: `Code exchange fail: ${c.message}` };
  }
  let token = j.access_token || '';
  if (!token) return { ok: false, error: 'Facebook ne access token nahi diya.' };

  // short-lived → long-lived (60 din)
  try {
    const llUrl = `https://graph.facebook.com/${GRAPH_VERSION}/oauth/access_token` +
      `?grant_type=fb_exchange_token&client_id=${encodeURIComponent(appId)}` +
      `&client_secret=${encodeURIComponent(appSecret)}` +
      `&fb_exchange_token=${encodeURIComponent(token)}`;
    const llr = await fetch(llUrl);
    const llj = await llr.json().catch(() => ({}));
    if (llr.ok && llj.access_token) {
      token = llj.access_token;
      const expiresIn = llj.expires_in || 0;
      db.kvSet('oauth_token_expires_at', String(expiresIn ? Date.now() + expiresIn * 1000 : ''));
    }
  } catch {}

  // validate + pages (user/page token mix nahi — user token se /me, page tokens alag)
  const v = await fb.validateUserToken(token);
  if (!v.ok) return { ok: false, error: `Token validate nahi hua: ${v.message}` };
  const pages = await fb.syncPages(token);
  if (!pages.ok) return { ok: false, error: `Pages sync fail: ${pages.message}` };

  // token meta save (asal token extension_sync.json flow mein jata hai taake UI use kare)
  db.kvSet('oauth_last_user', JSON.stringify({ id: v.id, name: v.name, at: new Date().toISOString() }));
  return { ok: true, user: { id: v.id, name: v.name }, token, pages: pages.pages };
}

/** Token status — expiry/revoke detection (item 1) */
async function tokenStatus(token) {
  if (!token) return { ok: false, kind: 'missing', message: 'Koi token nahi hai.' };
  const v = await fb.validateUserToken(token);
  if (v.ok) {
    const expAt = db.kvGet('oauth_token_expires_at', '');
    return { ok: true, valid: true, id: v.id, name: v.name,
      expiresAt: expAt ? new Date(parseInt(expAt, 10)).toISOString() : null };
  }
  // v.kind: token_expired | token_invalid | network ...
  return { ok: true, valid: false, kind: v.kind, message: v.message,
    needsRelogin: v.kind === 'token_expired' || v.kind === 'token_invalid' };
}

module.exports = {
  SCOPES, GRAPH_VERSION,
  getAppConfig, setAppConfig, isConfigured,
  startOAuth, handleCallback, tokenStatus,
};
