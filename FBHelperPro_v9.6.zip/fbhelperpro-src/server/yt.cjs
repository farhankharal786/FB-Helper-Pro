/**
 * FBHelperPro — yt-dlp helpers
 *
 * - URL validation
 * - Platform/video_id normalization (item 10): youtube watch?v=ABC == shorts/ABC == youtu.be/ABC
 * - Metadata probe (--dump-json): upload_date, view_count, id — asal sorting ke liye (item 18)
 * - Error classification (item 7, 17): private/deleted, login-required, geo/age block, unsupported, network
 */
const { execFile, spawn } = require('child_process');

function getTools() {
  // server.cjs set karta hai; fallback
  return global.__FBH_TOOLS || { ytDlpPath: 'yt-dlp' };
}
function childEnv() {
  return (global.__FBH_CHILD_ENV !== undefined ? global.__FBH_CHILD_ENV : null) || process.env;
}

/** URL shape validation — item 7 */
function validateUrl(url) {
  const u = String(url || '').trim();
  if (!u) return { ok: false, message: 'URL khaali hai.' };
  if (u.length > 2048) return { ok: false, message: 'URL bohat lambi hai.' };
  let parsed;
  try { parsed = new URL(u); }
  catch { return { ok: false, message: 'URL ka format ghalat hai.' }; }
  if (!['http:', 'https:'].includes(parsed.protocol)) {
    return { ok: false, message: 'Sirf http/https URLs allowed hain.' };
  }
  return { ok: true, url: u, host: parsed.hostname.toLowerCase() };
}

/**
 * Normalized platform + video_id — item 10
 * youtube.com/watch?v=ABC, /shorts/ABC, youtu.be/ABC → {platform:'youtube', video_id:'ABC'}
 */
function normalizeVideoId(url) {
  try {
    const u = new URL(String(url).trim());
    const host = u.hostname.toLowerCase().replace(/^www\.|^m\.|^vm\./, '');
    const path = u.pathname;
    // YouTube
    if (host.includes('youtube.com') || host === 'youtu.be') {
      let id = '';
      if (host === 'youtu.be') id = path.split('/')[1] || '';
      else if (path === '/watch') id = u.searchParams.get('v') || '';
      else {
        const m = path.match(/^\/(shorts|embed|live|v)\/([^/?#]+)/);
        if (m) id = m[2];
      }
      id = id.split(/[?#]/)[0];
      if (id) return { platform: 'youtube', video_id: id };
    }
    // TikTok
    if (host.includes('tiktok.com')) {
      const m = path.match(/\/video\/(\d+)/);
      if (m) return { platform: 'tiktok', video_id: m[1] };
      // /@user/video/123 — upar wala cover karta hai
      return { platform: 'tiktok', video_id: '' }; // profile URL — probe se id aayega
    }
    // Facebook
    if (host.includes('facebook.com') || host.includes('fb.watch')) {
      const m = path.match(/\/(\d{6,})/) || u.search.match(/v=(\d+)/);
      const id = m ? m[1] : '';
      return { platform: 'facebook', video_id: id };
    }
    // Instagram
    if (host.includes('instagram.com')) {
      const m = path.match(/\/(reel|reels|p|tv)\/([^/?#]+)/);
      if (m) return { platform: 'instagram', video_id: m[2] };
    }
    // Twitter/X
    if (host === 'twitter.com' || host === 'x.com') {
      const m = path.match(/\/status\/(\d+)/);
      if (m) return { platform: 'twitter', video_id: m[1] };
    }
    return { platform: host.split('.')[0] || 'unknown', video_id: '' };
  } catch {
    return { platform: 'unknown', video_id: '' };
  }
}

/**
 * yt-dlp stderr/exit se wajah nikalo — item 7, 17
 * Returns {kind, message} — kind: private|deleted|login|geo|age|unsupported|network|unknown
 */
function classifyYtError(stderr, code) {
  const t = String(stderr || '');
  const low = t.toLowerCase();
  const has = (...xs) => xs.some((x) => low.includes(x));
  if (has('private video', 'this video is private')) return { kind: 'private', message: 'Video PRIVATE hai — download nahi ho sakta.' };
  if (has('video unavailable', 'has been removed', 'has been deleted', 'not found', '404'))
    return { kind: 'deleted', message: 'Video delete ya unavailable hai.' };
  if (has('confirm your age', 'age-restricted', 'age restricted')) return { kind: 'age', message: 'AGE-RESTRICTED hai — login/cookies chahiye.' };
  if (has('not available in your country', 'blocked in your country') || /\bgeo\b/.test(low))
    return { kind: 'geo', message: 'GEO-BLOCKED hai — is country mein available nahi.' };
  if (has('sign in to confirm', 'login required', 'log in', 'cookies', 'use --cookies'))
    return { kind: 'login', message: 'LOGIN chahiye — cookies.txt lagao ya public video try karo.' };
  if (has('unsupported url', 'no video formats found', 'unable to extract'))
    return { kind: 'unsupported', message: 'Ye URL support nahi hoti ya koi video format nahi mila.' };
  if (has('timed out', 'connection', 'network', 'temporary failure', 'econnreset'))
    return { kind: 'network', message: 'NETWORK masla — internet check karke retry karo.' };
  if (has('disk', 'no space', 'enospc')) return { kind: 'disk', message: 'DISK SPACE khatm hai.' };
  if (code === 2) return { kind: 'network', message: `yt-dlp network/command error (exit 2). ${t.slice(-120)}` };
  return { kind: 'unknown', message: `yt-dlp fail (exit ${code}): ${t.slice(-180) || 'koi detail nahi'}` };
}

/**
 * Metadata probe — item 18 ke liye asal upload_date/view_count/id
 * Returns {ok, meta:{id,title,upload_date,timestamp,view_count,webpage_url,extractor} } ya classified error
 */
function probeMetadata(url, timeoutMs = 60000) {
  const { ytDlpPath } = getTools();
  return new Promise((resolve) => {
    const args = ['--dump-json', '--no-download', '--no-warnings', '--no-colors',
      '--socket-timeout', '20', String(url)];
    let out = '', err = '';
    const child = execFile(ytDlpPath, args, { timeout: timeoutMs, maxBuffer: 8 * 1024 * 1024, env: childEnv() },
      (error, stdout, stderr) => {
        out = String(stdout || ''); err = String(stderr || '');
        if (error) {
          const c = classifyYtError(err, error.code);
          return resolve({ ok: false, ...c, stderr: err.slice(-300) });
        }
        try {
          const j = JSON.parse(out.split('\n').filter(Boolean)[0]);
          resolve({ ok: true, meta: {
            id: String(j.id || ''), title: String(j.title || j.id || ''),
            upload_date: String(j.upload_date || ''), // YYYYMMDD
            timestamp: j.timestamp || 0,
            view_count: j.view_count || 0,
            webpage_url: String(j.webpage_url || url),
            extractor: String(j.extractor || ''),
          }});
        } catch {
          resolve({ ok: false, kind: 'unknown', message: 'Metadata parhi nahi ja saki.' });
        }
      });
    void child;
  });
}

/** YYYYMMDD → ms; khaali ho to 0 */
function uploadDateMs(meta) {
  if (meta.timestamp) return meta.timestamp * 1000;
  const d = String(meta.upload_date || '');
  const m = d.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (m) return Date.UTC(+m[1], +m[2] - 1, +m[3]);
  return 0;
}

/** Asal sorting — item 18 (blind reverse nahi) */
function sortEntries(entries, sort) {
  const arr = [...entries];
  const mode = String(sort || 'newest').toLowerCase();
  if (mode === 'oldest') {
    arr.sort((a, b) => (a._ts || 0) - (b._ts || 0));
  } else if (mode === 'popular') {
    arr.sort((a, b) => (b.view_count || 0) - (a.view_count || 0));
  } else {
    arr.sort((a, b) => (b._ts || 0) - (a._ts || 0)); // newest
  }
  return arr;
}

module.exports = {
  validateUrl, normalizeVideoId, classifyYtError,
  probeMetadata, uploadDateMs, sortEntries,
  getTools, childEnv,
};
