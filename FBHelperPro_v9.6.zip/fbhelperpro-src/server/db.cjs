/**
 * FBHelperPro — Job database
 *
 * Pehle node:sqlite (Node 22.5+) try karta hai — na mile to JSON file fallback.
 * Dono ka API aik jaisa hai, baqi code ko farq nahi parta.
 */
const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'fbhelperpro.db');
const JSON_PATH = path.join(DATA_DIR, 'fbhelperpro.jobs.json');
fs.mkdirSync(DATA_DIR, { recursive: true });

const now = () => new Date().toISOString();

let backend = null;
try {
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(DB_PATH);
  try { db.exec('PRAGMA journal_mode = WAL;'); } catch {}
  try { db.exec('PRAGMA synchronous = NORMAL;'); } catch {}

  db.exec(`
CREATE TABLE IF NOT EXISTS jobs (
  id            TEXT PRIMARY KEY,
  kind          TEXT NOT NULL,
  platform      TEXT NOT NULL DEFAULT '',
  video_id      TEXT NOT NULL DEFAULT '',
  source_url    TEXT NOT NULL DEFAULT '',
  title         TEXT NOT NULL DEFAULT '',
  file_path     TEXT NOT NULL DEFAULT '',
  file_size     INTEGER NOT NULL DEFAULT 0,
  page_id       TEXT NOT NULL DEFAULT '',
  page_name     TEXT NOT NULL DEFAULT '',
  caption       TEXT NOT NULL DEFAULT '',
  quality       TEXT NOT NULL DEFAULT '',
  subfolder     TEXT NOT NULL DEFAULT '',
  max_downloads INTEGER NOT NULL DEFAULT 0,
  download_status TEXT NOT NULL DEFAULT 'queued',
  upload_status   TEXT NOT NULL DEFAULT 'pending',
  facebook_post_id TEXT NOT NULL DEFAULT '',
  progress      REAL NOT NULL DEFAULT 0,
  speed         TEXT NOT NULL DEFAULT '',
  eta           TEXT NOT NULL DEFAULT '',
  error         TEXT NOT NULL DEFAULT '',
  attempts      INTEGER NOT NULL DEFAULT 0,
  created_at    TEXT NOT NULL,
  updated_at    TEXT NOT NULL,
  UNIQUE(platform, video_id)
);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(download_status, upload_status);
CREATE INDEX IF NOT EXISTS idx_jobs_updated ON jobs(updated_at);
CREATE TABLE IF NOT EXISTS kv (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL DEFAULT '',
  updated_at TEXT NOT NULL
);
`);
  try {
    const cols = db.prepare('PRAGMA table_info(jobs)').all().map((c) => c.name);
    if (!cols.includes('subfolder')) db.exec("ALTER TABLE jobs ADD COLUMN subfolder TEXT NOT NULL DEFAULT '';");
    if (!cols.includes('max_downloads')) db.exec('ALTER TABLE jobs ADD COLUMN max_downloads INTEGER NOT NULL DEFAULT 0;');
  } catch {}

  const stmtInsertJob = db.prepare(`
    INSERT INTO jobs (id, kind, platform, video_id, source_url, title, file_path, file_size,
      page_id, page_name, caption, quality, subfolder, max_downloads,
      download_status, upload_status, facebook_post_id, progress, speed, eta, error, attempts, created_at, updated_at)
    VALUES (@id, @kind, @platform, @video_id, @source_url, @title, @file_path, @file_size,
      @page_id, @page_name, @caption, @quality, @subfolder, @max_downloads,
      @download_status, @upload_status, @facebook_post_id, @progress, @speed, @eta, @error, @attempts, @created_at, @updated_at)`);
  const stmtGetJob = db.prepare('SELECT * FROM jobs WHERE id = ?');
  const stmtFindByVideo = db.prepare('SELECT * FROM jobs WHERE platform = ? AND video_id = ? LIMIT 1');
  const stmtUpdateJob = db.prepare(`
    UPDATE jobs SET download_status = COALESCE(@download_status, download_status),
      upload_status = COALESCE(@upload_status, upload_status),
      file_path = COALESCE(@file_path, file_path), file_size = COALESCE(@file_size, file_size),
      facebook_post_id = COALESCE(@facebook_post_id, facebook_post_id),
      progress = COALESCE(@progress, progress), speed = COALESCE(@speed, speed),
      eta = COALESCE(@eta, eta), error = COALESCE(@error, error),
      attempts = COALESCE(@attempts, attempts), title = COALESCE(@title, title),
      page_id = COALESCE(@page_id, page_id), page_name = COALESCE(@page_name, page_name),
      caption = COALESCE(@caption, caption),
      subfolder = COALESCE(@subfolder, subfolder), max_downloads = COALESCE(@max_downloads, max_downloads),
      updated_at = @updated_at WHERE id = @id`);
  const stmtListJobs = db.prepare('SELECT * FROM jobs ORDER BY updated_at DESC LIMIT ? OFFSET ?');
  const stmtCountJobs = db.prepare('SELECT COUNT(*) AS n FROM jobs');
  const stmtDeleteJob = db.prepare('DELETE FROM jobs WHERE id = ?');
  const stmtKvGet = db.prepare('SELECT v FROM kv WHERE k = ?');
  const stmtKvSet = db.prepare(`INSERT INTO kv (k, v, updated_at) VALUES (?, ?, ?)
    ON CONFLICT(k) DO UPDATE SET v = excluded.v, updated_at = excluded.updated_at`);

  backend = {
    kind: 'sqlite', db,
    createJob(row) {
      const ts = now();
      const kind = row.kind || 'download';
      const full = {
        id: row.id, kind,
        platform: row.platform || '',
        // UNIQUE(platform, video_id): khaali video_id wali do jobs SQLite ko
        // "duplicate" lagti hain (do '' barabar hain). Dedup sirf ASAL video_id
        // par hota hai — khaali wali har job ko unique id do taake uploads
        // (aur bina video_id wale downloads) kabhi "duplicate" na kahen.
        video_id: row.video_id || `${kind === 'upload' ? 'upload' : 'dl'}:${row.id}`,
        source_url: row.source_url || '', title: row.title || '',
        file_path: row.file_path || '', file_size: row.file_size || 0,
        page_id: row.page_id || '', page_name: row.page_name || '',
        caption: row.caption || '', quality: row.quality || '',
        subfolder: row.subfolder || '', max_downloads: row.max_downloads || 0,
        download_status: row.download_status || 'queued',
        upload_status: row.upload_status || (row.kind === 'upload' ? 'queued' : 'pending'),
        facebook_post_id: row.facebook_post_id || '',
        progress: 0, speed: '', eta: '', error: '',
        attempts: 0, created_at: ts, updated_at: ts,
      };
      try {
        stmtInsertJob.run(full);
        return { ok: true, job: stmtGetJob.get(full.id) };
      } catch (e) {
        if (String(e.message).includes('UNIQUE')) {
          const existing = stmtFindByVideo.get(full.platform, full.video_id);
          return { ok: false, duplicate: true, job: existing || null, error: 'duplicate' };
        }
        throw e;
      }
    },
    getJob(id) { return stmtGetJob.get(id) || null; },
    findByVideo(platform, video_id) {
      if (!platform || !video_id) return null;
      return stmtFindByVideo.get(platform, video_id) || null;
    },
    updateJob(id, patch) {
      stmtUpdateJob.run({ id, ...patch, updated_at: now() });
      return stmtGetJob.get(id);
    },
    listJobs(limit = 100, offset = 0) { return stmtListJobs.all(limit, offset); },
    countJobs() { return stmtCountJobs.get().n; },
    deleteJob(id) { return stmtDeleteJob.run(id).changes > 0; },
    kvGet(k, def = '') { const r = stmtKvGet.get(k); return r ? r.v : def; },
    kvSet(k, v) { stmtKvSet.run(k, String(v), now()); },
    recoverInterruptedJobs() {
      const ts = now();
      const dl = db.prepare(
        `UPDATE jobs SET download_status = 'queued', error = 'App restart — dobara queue', updated_at = ?
         WHERE download_status = 'downloading' OR download_status = 'retrying'`).run(ts);
      const ul = db.prepare(
        `UPDATE jobs SET upload_status = 'queued', error = 'App restart — dobara queue', updated_at = ?
         WHERE upload_status = 'uploading'`).run(ts);
      return { downloadsRecovered: Number(dl.changes || 0), uploadsRecovered: Number(ul.changes || 0) };
    },
    /** Queue ke liye: kind + status ke hisaab se agle jobs (kind=null → har kind) */
    nextQueued(kind, statusField, statusValue, limit) {
      const col = statusField === 'download_status' ? 'download_status' : 'upload_status';
      if (kind) {
        return db.prepare(
          `SELECT * FROM jobs WHERE kind = ? AND ${col} = ? ORDER BY created_at ASC LIMIT ?`
        ).all(kind, statusValue, limit);
      }
      return db.prepare(
        `SELECT * FROM jobs WHERE ${col} = ? ORDER BY created_at ASC LIMIT ?`
      ).all(statusValue, limit);
    },
  };
  console.log('[db] SQLite mode (node:sqlite)');
} catch (e) {
  // ── JSON fallback (purana Node) ──
  console.log('[db] node:sqlite nahi mila — JSON file mode (' + String(e.message).slice(0, 60) + ')');
  let store = { jobs: {}, kv: {} };
  try {
    if (fs.existsSync(JSON_PATH)) store = JSON.parse(fs.readFileSync(JSON_PATH, 'utf-8'));
    if (!store.jobs || !store.kv) store = { jobs: {}, kv: {} };
  } catch { store = { jobs: {}, kv: {} }; }
  const save = () => {
    try {
      const tmp = JSON_PATH + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(store), 'utf-8');
      fs.renameSync(tmp, JSON_PATH);
    } catch {}
  };
  const blank = () => ({
    platform: '', video_id: '', source_url: '', title: '', file_path: '', file_size: 0,
    page_id: '', page_name: '', caption: '', quality: '', subfolder: '', max_downloads: 0,
    download_status: 'queued', upload_status: 'pending', facebook_post_id: '',
    progress: 0, speed: '', eta: '', error: '', attempts: 0,
  });
  backend = {
    kind: 'json', db: null,
    createJob(row) {
      // UNIQUE(platform, video_id) — code mein enforce
      if (row.platform && row.video_id) {
        const dup = Object.values(store.jobs).find(
          (j) => j.platform === row.platform && j.video_id === row.video_id);
        if (dup) return { ok: false, duplicate: true, job: dup, error: 'duplicate' };
      }
      const ts = now();
      const full = { ...blank(), ...row, id: row.id,
        download_status: row.download_status || 'queued',
        upload_status: row.upload_status || (row.kind === 'upload' ? 'queued' : 'pending'),
        created_at: ts, updated_at: ts };
      store.jobs[full.id] = full;
      save();
      return { ok: true, job: full };
    },
    getJob(id) { return store.jobs[id] || null; },
    findByVideo(platform, video_id) {
      if (!platform || !video_id) return null;
      return Object.values(store.jobs).find(
        (j) => j.platform === platform && j.video_id === video_id) || null;
    },
    updateJob(id, patch) {
      const j = store.jobs[id];
      if (!j) return null;
      for (const [k, v] of Object.entries(patch)) {
        if (v !== undefined && v !== null) j[k] = v;
      }
      j.updated_at = now();
      save();
      return j;
    },
    listJobs(limit = 100, offset = 0) {
      return Object.values(store.jobs)
        .sort((a, b) => String(b.updated_at).localeCompare(String(a.updated_at)))
        .slice(offset, offset + limit);
    },
    countJobs() { return Object.keys(store.jobs).length; },
    deleteJob(id) {
      if (!store.jobs[id]) return false;
      delete store.jobs[id]; save(); return true;
    },
    kvGet(k, def = '') { return store.kv[k] !== undefined ? store.kv[k] : def; },
    kvSet(k, v) { store.kv[k] = String(v); save(); },
    recoverInterruptedJobs() {
      const ts = now();
      let dl = 0, ul = 0;
      for (const j of Object.values(store.jobs)) {
        if (j.download_status === 'downloading' || j.download_status === 'retrying') {
          j.download_status = 'queued'; j.error = 'App restart — dobara queue'; j.updated_at = ts; dl++;
        }
        if (j.upload_status === 'uploading') {
          j.upload_status = 'queued'; j.error = 'App restart — dobara queue'; j.updated_at = ts; ul++;
        }
      }
      if (dl || ul) save();
      return { downloadsRecovered: dl, uploadsRecovered: ul };
    },
    /** Queue ke liye: kind + status ke hisaab se agle jobs (kind=null → har kind) */
    nextQueued(kind, statusField, statusValue, limit) {
      return this.listJobs(10000, 0)
        .filter((j) => (!kind || j.kind === kind) && j[statusField] === statusValue)
        .sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)))
        .slice(0, limit);
    },
  };
}

module.exports = {
  db: backend.db,
  dbKind: backend.kind,
  DB_PATH: backend.kind === 'sqlite' ? DB_PATH : JSON_PATH,
  createJob: backend.createJob.bind(backend),
  getJob: backend.getJob.bind(backend),
  findByVideo: backend.findByVideo.bind(backend),
  updateJob: backend.updateJob.bind(backend),
  listJobs: backend.listJobs.bind(backend),
  countJobs: backend.countJobs.bind(backend),
  deleteJob: backend.deleteJob.bind(backend),
  kvGet: backend.kvGet.bind(backend),
  kvSet: backend.kvSet.bind(backend),
  recoverInterruptedJobs: backend.recoverInterruptedJobs.bind(backend),
  nextQueued: backend.nextQueued.bind(backend),
};
