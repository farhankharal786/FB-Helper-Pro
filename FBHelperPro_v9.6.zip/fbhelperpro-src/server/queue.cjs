/**
 * FBHelperPro — Job queue (items 11, 13, 14)
 *
 * State machine:
 *   download: queued → downloading → downloaded | failed | cancelled
 *              retrying → queued (retry par)
 *   upload:   pending → queued → uploading → uploaded | failed | cancelled | skipped
 *
 * - Concurrency: downloads 2, uploads 1 (configurable)
 * - Har state change DB mein + SSE event
 * - Crash recovery: boot par adhure jobs dobara queue (db.recoverInterruptedJobs)
 * - Pause: naye jobs pick nahi honge; running continue karenge
 */
const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const db = require('./db.cjs');
const yt = require('./yt.cjs');
const fb = require('./fb.cjs');

const VIDEO_EXTS = new Set(['.mp4', '.mov', '.mkv', '.avi', '.webm']);
const PHOTO_EXTS = new Set(['.jpg', '.jpeg', '.png', '.webp', '.bmp']);

function uid(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(4).toString('hex')}`;
}

class JobQueue {
  constructor(opts = {}) {
    this.downloadsDir = opts.downloadsDir;
    this.getDownloadsDir = opts.getDownloadsDir || (() => this.downloadsDir);
    this.getTools = opts.getTools || (() => ({ ytDlpPath: 'yt-dlp' }));
    this.getChildEnv = opts.getChildEnv || (() => process.env);
    this.emit = opts.emit || (() => {}); // SSE broadcast
    this.maxDownloads = opts.maxDownloads || 2;
    this.maxUploads = opts.maxUploads || 1;
    this.paused = false;
    this.active = new Map(); // jobId -> {child, signal}
    this.timer = null;
  }

  start() {
    if (this.timer) return;
    this.timer = setInterval(() => this.tick().catch((e) => console.error('[queue]', e.message)), 1500);
    // foran ek tick
    this.tick().catch(() => {});
  }
  stop() { if (this.timer) clearInterval(this.timer); this.timer = null; }

  setPaused(p) { this.paused = !!p; this.emit('queue', { paused: this.paused }); }

  // ---------- public API ----------
  async addDownload({ url, subfolder, quality, maxDownloads }) {
    const vu = yt.validateUrl(url);
    if (!vu.ok) return { ok: false, error: vu.error || vu.message };
    const norm = yt.normalizeVideoId(vu.url);
    // Permanent dedup — item 9, 10
    if (norm.platform && norm.video_id) {
      const dup = db.findByVideo(norm.platform, norm.video_id);
      if (dup && ['downloaded', 'downloading', 'queued'].includes(dup.download_status)) {
        return { ok: false, duplicate: true, jobId: dup.id,
          error: `Duplicate — ye video pehle se ${dup.download_status} hai (${dup.title || dup.video_id}).` };
      }
    }
    const tools = this.getTools();
    if (!tools.ytDlp) return { ok: false, error: 'yt-dlp installed nahi hai' };
    const r = db.createJob({
      id: uid('dl'), kind: 'download', platform: norm.platform, video_id: norm.video_id,
      source_url: vu.url, title: vu.url.slice(0, 80), quality: quality || '1080p',
      subfolder: subfolder || '', max_downloads: parseInt(maxDownloads, 10) || 0,
      download_status: 'queued',
    });
    if (!r.ok && r.duplicate) {
      return { ok: false, duplicate: true, jobId: r.job.id, error: 'Duplicate video — pehle se maujood hai.' };
    }
    if (!r.ok) return { ok: false, error: r.error || 'Job create fail' };
    this.emit('job', this.publicJob(r.job));
    return { ok: true, jobId: r.job.id, job: this.publicJob(r.job) };
  }

  async addUpload({ pageId, pageToken, pageName, filepath, caption }) {
    if (!pageId || !pageToken) return { ok: false, error: 'pageId/pageToken missing' };
    const fv = fb.validateUploadFile(filepath);
    if (!fv.ok) return { ok: false, error: fv.message };
    const r = db.createJob({
      id: uid('up'), kind: 'upload', source_url: '', title: path.basename(filepath),
      file_path: filepath, file_size: fv.size, page_id: String(pageId),
      page_name: pageName || String(pageId), caption: caption || '',
      download_status: 'downloaded', upload_status: 'queued',
    });
    if (!r.ok) return { ok: false, error: r.error || 'Job create fail' };
    // pageToken DB mein SAVE NAHI hota (sirf runtime mein)
    this.emit('job', this.publicJob(r.job));
    return { ok: true, jobId: r.job.id, job: this.publicJob(r.job), _pageToken: pageToken };
  }

  cancel(jobId) {
    const a = this.active.get(jobId);
    if (a) {
      try { a.controller && a.controller.abort(); } catch {} // upload: asal AbortController
      try { a.signal.aborted = true; } catch {} // download worker ka flag
      try { a.child && a.child.kill('SIGKILL'); } catch {}
    }
    const j = db.getJob(jobId);
    if (!j) return { ok: false, error: 'job nahi mila' };
    const patch = {};
    if (['downloading', 'queued', 'retrying'].includes(j.download_status)) patch.download_status = 'cancelled';
    if (['uploading', 'queued'].includes(j.upload_status)) patch.upload_status = 'cancelled';
    patch.error = 'User ne cancel kiya';
    const uj = db.updateJob(jobId, patch);
    this.active.delete(jobId);
    this.emit('job', this.publicJob(uj));
    return { ok: true, job: this.publicJob(uj) };
  }

  retry(jobId) {
    const j = db.getJob(jobId);
    if (!j) return { ok: false, error: 'job nahi mila' };
    const patch = { attempts: j.attempts, error: '' };
    if (j.kind === 'download' && j.download_status === 'failed') patch.download_status = 'queued';
    else if (j.upload_status === 'failed') patch.upload_status = 'queued';
    else return { ok: false, error: 'Sirf failed jobs retry ho sakte hain.' };
    const uj = db.updateJob(jobId, patch);
    this.emit('job', this.publicJob(uj));
    return { ok: true, job: this.publicJob(uj) };
  }

  publicJob(j) {
    if (!j) return null;
    return {
      id: j.id, kind: j.kind, label: j.title || j.source_url,
      platform: j.platform, video_id: j.video_id, source_url: j.source_url,
      title: j.title, filepath: j.file_path, filename: j.file_path ? path.basename(j.file_path) : '',
      file_size: j.file_size, page_id: j.page_id, page_name: j.page_name,
      subfolder: j.subfolder, max_downloads: j.max_downloads,
      // UI ke liye combined status (purane API jaisa)
      status: j.kind === 'download'
        ? ({ queued: 'queued', downloading: 'downloading', downloaded: 'done', failed: 'failed', cancelled: 'cancelled', retrying: 'retrying' }[j.download_status] || j.download_status)
        : ({ queued: 'queued', uploading: 'uploading', uploaded: 'done', failed: 'failed', cancelled: 'cancelled', skipped: 'skipped', pending: 'queued' }[j.upload_status] || j.upload_status),
      download_status: j.download_status, upload_status: j.upload_status,
      progress: j.progress, speed: j.speed, eta: j.eta,
      error: j.error, postId: j.facebook_post_id, facebook_post_id: j.facebook_post_id,
      attempts: j.attempts, createdAt: j.created_at, updatedAt: j.updated_at,
    };
  }

  // ---------- worker loop ----------
  async tick() {
    if (this.paused) return;
    // downloads
    const activeDl = [...this.active.values()].filter((a) => a.kind === 'download').length;
    if (activeDl < this.maxDownloads) {
      const next = db.nextQueued('download', 'download_status', 'queued', this.maxDownloads - activeDl);
      for (const j of next) this.runDownload(j).catch((e) => console.error('[dl]', e.message));
    }
    // uploads (kind filter nahi — download+upload dono kinds se)
    const activeUp = [...this.active.values()].filter((a) => a.kind === 'upload').length;
    if (activeUp < this.maxUploads) {
      const next = db.nextQueued(null, 'upload_status', 'queued', this.maxUploads - activeUp);
      for (const j of next) {
        const token = this._uploadTokens.get(j.id);
        this.runUpload(j, token).catch((e) => console.error('[up]', e.message));
      }
    }
  }

  _uploadTokens = new Map(); // jobId -> pageToken (sirf memory mein!)
  rememberUploadToken(jobId, token) { this._uploadTokens.set(jobId, token); }

  // ---------- download worker (items 7, 8, 17) ----------
  async runDownload(job) {
    const tools = this.getTools();
    const jobId = job.id;
    this.active.set(jobId, { kind: 'download', signal: { aborted: false } });
    const signal = this.active.get(jobId).signal;
    const set = (patch) => {
      try {
        const uj = db.updateJob(jobId, patch);
        try { this.emit('job', this.publicJob(uj)); } catch {}
        return uj;
      } catch (e) {
        console.error('[queue] db.updateJob fail (backend zinda):', e.message);
        return db.getJob(jobId);
      }
    };

    try {
      set({ download_status: 'downloading', attempts: job.attempts + 1, error: '', progress: 0 });
      const { safeFolderName } = require('./security.cjs');
      const outdir = path.join(this.getDownloadsDir(), safeFolderName(job.subfolder || 'downloads'));
      fs.mkdirSync(outdir, { recursive: true });

      // Disk space check (kam az kam 500MB free)
      // (Windows par statfs nahi — best effort: skip agar na ho sake)

      const quality = job.quality || '1080p';
      const qmap = { best: 'best', '1080p': 'best[height<=1080]/best', '720p': 'best[height<=720]/best', '480p': 'best[height<=480]/best' };
      const before = new Set();
      try {
        for (const f of fs.readdirSync(outdir)) {
          const e = path.extname(f).toLowerCase();
          if (VIDEO_EXTS.has(e) || PHOTO_EXTS.has(e)) before.add(f);
        }
      } catch {}

      const args = ['--newline', '--no-colors', '--no-warnings', '--retries', '3',
        '--socket-timeout', '20',
        '-f', qmap[quality] || qmap['1080p'],
        '-o', path.join(outdir, '%(title).60s-%(id)s.%(ext)s')];
      if (!/\/@|\/channel\/|\/c\/|\/user\//i.test(job.source_url)) args.push('--no-playlist');
      if (tools.aria2c) args.push('--external-downloader', tools.aria2cPath,
        '--external-downloader-args', 'aria2c:-x 16 -s 16 -k 1M');
      args.push(job.source_url);

      await new Promise((resolve, reject) => {
        const child = spawn(tools.ytDlpPath, args, { windowsHide: true, env: this.getChildEnv() });
        this.active.get(jobId).child = child;
        let buf = '', errBuf = '';
        const progRe = /\[download\]\s+(\d+(?:\.\d+)?)%.*?of\s+(\S+).*?at\s+(\S+).*?ETA\s+(\S+)/;
        const progRe2 = /\[download\]\s+(\d+(?:\.\d+)?)%/;
        child.stdout.on('data', (d) => {
          buf += d.toString();
          const lines = buf.split('\n'); buf = lines.pop();
          for (const line of lines) {
            let m = line.match(progRe) || line.match(progRe2);
            if (m) {
              try {
                const uj = db.updateJob(jobId, { progress: Math.min(99, parseFloat(m[1])),
                  speed: m[3] || '', eta: m[4] || '' });
                this.emit('job', this.publicJob(uj));
              } catch (e) { /* progress update fail = backend ko maarne mat do */ }
            }
          }
        });
        child.stderr.on('data', (d) => { errBuf += d.toString(); if (errBuf.length > 2000) errBuf = errBuf.slice(-2000); });
        child.on('error', (e) => reject(new Error('yt-dlp start nahi hua: ' + e.message)));
        child.on('close', (code) => {
          if (signal.aborted) return reject(new Error('cancelled'));
          if (code === 0) return resolve();
          const c = yt.classifyYtError(errBuf, code);
          const err = new Error(c.message);
          err.kind = c.kind; err.code = code;
          reject(err);
        });
      });

      // File verification — item 8: exists + size > 0 (+ nayi file)
      let best = '', bestMt = -1;
      for (const f of fs.readdirSync(outdir)) {
        if (before.has(f)) continue;
        const e = path.extname(f).toLowerCase();
        if (!VIDEO_EXTS.has(e) && !PHOTO_EXTS.has(e)) continue;
        const fp = path.join(outdir, f);
        try { const mt = fs.statSync(fp).mtimeMs; if (mt > bestMt) { bestMt = mt; best = fp; } } catch {}
      }
      if (!best) {
        set({ download_status: 'failed', error: 'Download complete lekin file nahi mili (verify fail).' });
      } else {
        const st = fs.statSync(best);
        if (st.size <= 0) {
          set({ download_status: 'failed', error: 'File khaali hai (0 bytes) — verify fail.' });
        } else {
          set({ download_status: 'downloaded', progress: 100, file_path: best, file_size: st.size, error: '' });
        }
      }
    } catch (e) {
      if (String(e.message) === 'cancelled' || signal.aborted) {
        set({ download_status: 'cancelled', error: 'User ne cancel kiya' });
      } else {
        set({ download_status: 'failed', error: String(e.message || e).slice(0, 300) });
      }
    } finally {
      this.active.delete(jobId);
    }
  }

  // ---------- upload worker (items 4, 5, 6, 12, 16) ----------
  async runUpload(job, pageToken) {
    const jobId = job.id;
    // ASAL AbortController — fetch() ko naqli {aborted:false} object dene par
    // TypeError aata hai aur har upload phase-1 mein hi mar jata hai.
    const controller = new AbortController();
    const signal = controller.signal;
    this.active.set(jobId, { kind: 'upload', signal, controller });
    const set = (patch) => {
      try {
        const uj = db.updateJob(jobId, patch);
        try { this.emit('job', this.publicJob(uj)); } catch {}
        return uj;
      } catch (e) {
        console.error('[queue] db.updateJob fail (backend zinda):', e.message);
        return db.getJob(jobId);
      }
    };

    try {
      set({ upload_status: 'uploading', error: '', progress: 0 });
      const token = pageToken || this._uploadTokens.get(jobId) || '';
      if (!token) throw new Error('Page token nahi mila (dobara sync karo).');

      // Step 1: file validation
      const fv = fb.validateUploadFile(job.file_path);
      if (!fv.ok) { const e = new Error(fv.message); e.kind = 'file'; throw e; }

      // Step 2: page + token validation (asal Graph API)
      const pv = await fb.validatePageToken(job.page_id, token);
      if (!pv.ok) { const e = new Error(pv.message); e.kind = pv.kind; throw e; }

      // Step 3: upload — videos HAMESHA resumable (start→transfer→finish), photos simple
      const ext = path.extname(job.file_path).toLowerCase();
      const isPhoto = PHOTO_EXTS.has(ext);
      const onProgress = (sent, total) => {
        try {
          const pct = total > 0 ? Math.min(99, (sent / total) * 100) : 0;
          const uj = db.updateJob(jobId, { progress: pct });
          this.emit('job', this.publicJob(uj));
        } catch (e) { /* progress update fail = backend ko maarne mat do */ }
      };
      let up;
      if (!isPhoto) {
        up = await fb.uploadVideoResumable(job.page_id, token, job.file_path, job.caption, onProgress, signal);
      } else {
        up = await fb.uploadSimple(job.page_id, token, job.file_path, job.caption, isPhoto, onProgress, signal);
      }
      if (!up.ok) {
        const phaseNote = up.phase ? ` [phase: ${up.phase}]` : '';
        const e = new Error(up.message + phaseNote);
        e.kind = up.kind; e.fbError = up.fbError; throw e;
      }
      if (signal.aborted) throw new Error('cancelled');

      // Step 4: VERIFY — post ID se asal check (item 12: bina verify "Uploaded" nahi)
      // Facebook ko video process karne mein waqt lagta hai — finish ke foran
      // baad verify fail ho sakta hai jabke upload KAMYAB hota hai. Is liye
      // transient errors (network / object-not-found-yet) par backoff retries.
      // Token/permission error par foran fail (retry ka faida nahi).
      let vv = await fb.verifyUpload(up.videoId, token);
      if (!vv.ok && (vv.kind === 'network' || vv.kind === 'param')) {
        for (let vi = 1; vi <= 5 && !vv.ok; vi++) {
          if (signal.aborted) throw new Error('cancelled');
          await new Promise((r) => setTimeout(r, vi * 5000)); // 5,10,15,20,25s
          try { vv = await fb.verifyUpload(up.videoId, token); }
          catch (e) { vv = { ok: false, kind: 'network', message: String(e.message || e).slice(0, 120) }; }
          if (vv.ok) break;
          // sirf transient par retry — token/permission masla ho to ruk jao
          if (vv.kind !== 'network' && vv.kind !== 'param') break;
        }
      }
      if (!vv.ok) {
        const e = new Error(`Upload hua lekin verify nahi ho saka: ${vv.message} (ID: ${up.videoId})`);
        e.kind = vv.kind; throw e;
      }

      set({ upload_status: 'uploaded', progress: 100, facebook_post_id: up.videoId, error: '' });
    } catch (e) {
      if (String(e.message) === 'cancelled' || signal.aborted) {
        set({ upload_status: 'cancelled', error: 'User ne cancel kiya' });
      } else {
        set({ upload_status: 'failed', error: String(e.message || e).slice(0, 300) });
      }
    } finally {
      this.active.delete(jobId);
      // Page token sirf terminal states par bhoolo — failed par RAKHO taake
      // Retry button dobara token ke baghair fail na ho.
      let terminal = true;
      try {
        const jj = db.getJob(jobId);
        terminal = !jj || jj.upload_status === 'uploaded' || jj.upload_status === 'cancelled';
      } catch {}
      if (terminal) this._uploadTokens.delete(jobId);
    }
  }
}

module.exports = { JobQueue, VIDEO_EXTS, PHOTO_EXTS };
