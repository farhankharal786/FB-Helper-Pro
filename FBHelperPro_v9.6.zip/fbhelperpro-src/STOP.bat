@echo off
title FBHelperPro - Stop
echo [*] FBHelperPro band ho raha hai...
REM Sirf FBHelperPro ke processes band karo (ports 8573 + 3000) —
REM pehle taskkill /F /IM node.exe tha jo machine ke SAARE node processes maar deta tha.
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":8573" ^| findstr "LISTENING"') do taskkill /F /PID %%P >nul 2>&1
for /f "tokens=5" %%P in ('netstat -ano ^| findstr ":3000" ^| findstr "LISTENING"') do taskkill /F /PID %%P >nul 2>&1
echo [OK] FBHelperPro band ho gaya.
pause
