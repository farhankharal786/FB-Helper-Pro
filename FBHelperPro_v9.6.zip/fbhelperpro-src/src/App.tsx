import React, { useState, useEffect } from 'react';
import { Sidebar, NavTab } from './components/Sidebar';
import { ConsoleDock } from './components/ConsoleDock';
import { DashboardView } from './components/DashboardView';
import { PageConnectView } from './components/PageConnectView';
import { SettingsView } from './components/SettingsView';
import { CreatorMapping, BmAccount, LogItem, ClientLicenseSession } from './types';
import {
  verifyCurrentLicense,
  subscribeRealTimeKeySync,
  SyncStatus,
} from './services/keyDatabase';
import { LicenseGateModal } from './components/LicenseGateModal';
import { LicenseInfoModal } from './components/LicenseInfoModal';
import { getUiState, saveUiState } from './utils/api';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  // Starts EMPTY until added by the user as requested
  const [creators, setCreators] = useState<CreatorMapping[]>([]);
  const [accounts, setAccounts] = useState<BmAccount[]>([]);
  const [uiStateLoaded, setUiStateLoaded] = useState(false);
  // Sirf KAMYAB load ke baad save enable ho — failed load ke baad khaali
  // arrays save karke creators/accounts hamesha ke liye mit jate thay.
  const [uiStateLoadOk, setUiStateLoadOk] = useState(false);

  // UI state persistence — app dobara khule to creators + accounts wapas
  useEffect(() => {
    getUiState()
      .then((s) => {
        if (Array.isArray(s.creators) && s.creators.length) setCreators(s.creators);
        if (Array.isArray(s.accounts) && s.accounts.length) setAccounts(s.accounts);
        setUiStateLoadOk(true);
      })
      .catch(() => {})
      .finally(() => setUiStateLoaded(true));
  }, []);
  useEffect(() => {
    if (!uiStateLoadOk) return;
    const t = setTimeout(() => {
      saveUiState(creators, accounts).catch(() => {});
    }, 1200);
    return () => clearTimeout(t);
  }, [creators, accounts, uiStateLoadOk]);
  const [privacyMode, setPrivacyMode] = useState<boolean>(false);

  // KEY SYSTEM: License Verification & Gate State
  const [licenseSession, setLicenseSession] = useState<ClientLicenseSession | null>(null);
  const [isLicenseChecking, setIsLicenseChecking] = useState<boolean>(true);
  const [licenseError, setLicenseError] = useState<string | undefined>(undefined);
  const [showLicenseInfoModal, setShowLicenseInfoModal] = useState<boolean>(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    connected: true,
    type: 'sse',
    lastSync: 'Now',
  });

  const [logs, setLogs] = useState<LogItem[]>([
    {
      id: 'log-0',
      timestamp: '5:15:40 PM',
      category: 'system',
      level: 'info',
      message: '⚡ FB HELPER Pro Ready • Developed by Farhan Kharal (WA: 03051705177)',
    },
  ]);
  const [activeLogTab, setActiveLogTab] = useState<'download' | 'upload'>('download');

  const addLog = (
    message: string,
    level: 'info' | 'success' | 'warn' | 'error' = 'info',
    category: 'download' | 'upload' | 'system' = 'download'
  ) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });

    const newLog: LogItem = {
      id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      timestamp: timeStr,
      category,
      level,
      message,
    };

    // Lambi farming runs par logs hazaaron mein — DOM/memory bachao (aakhri 500 rakho)
    setLogs((prev) => (prev.length >= 500 ? [...prev.slice(-400), newLog] : [...prev, newLog]));
  };

  const clearLogs = () => {
    setLogs([]);
  };

  // Verify license against Key Database on startup and subscribe to Real-Time Sync
  useEffect(() => {
    async function checkLicense() {
      try {
        const result = await verifyCurrentLicense();
        if (result.isValid && result.session) {
          setLicenseSession(result.session);
          addLog(
            result.session.isLifetime
              ? `⚡ Lifetime VIP License Verified: ${result.session.planName} • User: ${result.session.clientName} (Lifetime Chly Ga)`
              : `🔐 License verified: ${result.session.planName} • User: ${result.session.clientName}`,
            'success',
            'system'
          );
        } else {
          setLicenseSession(null);
          if (result.error) {
            setLicenseError(result.error);
          }
        }
      } catch {
        setLicenseSession(null);
      } finally {
        setIsLicenseChecking(false);
      }
    }

    checkLicense();

    const unsubscribeSync = subscribeRealTimeKeySync(
      async () => {
        try {
          const result = await verifyCurrentLicense();
          if (result.isValid && result.session) {
            setLicenseSession(result.session);
          } else {
            setLicenseSession(null);
            if (result.error) {
              setLicenseError(result.error);
              addLog(`🚫 License update: ${result.error}`, 'error', 'system');
            }
          }
        } catch {
          // Keep offline state safe
        }
      },
      (newStatus) => {
        setSyncStatus(newStatus);
      }
    );

    return () => {
      unsubscribeSync();
    };
  }, []);

  // License check ho raha ho to splash dikhao
  if (isLicenseChecking) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-[#07090e] text-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin"></div>
          <span className="text-xs font-mono-code text-slate-400">
            Connecting to Key Database & verifying HWID...
          </span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#090c12] text-slate-100 font-sans antialiased">
      {/* KEY SYSTEM ENFORCEMENT: baghair active license poora tool locked */}
      {!licenseSession && (
        <LicenseGateModal
          initialError={licenseError}
          onActivated={(session) => {
            setLicenseSession(session);
            setLicenseError(undefined);
            addLog(
              `⚡ License activated: ${session.planName} (${session.key}) for ${session.clientName}`,
              'success',
              'system'
            );
          }}
        />
      )}

      {/* LEFT SIDEBAR: ONLY Dashboard, Page Connect & Mapping, Settings */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isEngineOnline={true}
        privacyMode={privacyMode}
        setPrivacyMode={setPrivacyMode}
        currentLicense={licenseSession}
        onOpenLicenseInfo={() => setShowLicenseInfoModal(true)}
        syncStatus={syncStatus}
      />

      {/* RIGHT MAIN WORKSPACE */}
      <div className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* VIEW CONTAINER */}
        <main className="flex-1 flex flex-col min-h-0 overflow-hidden">
          {activeTab === 'dashboard' && (
            <DashboardView
              creators={creators}
              setCreators={setCreators}
              accounts={accounts}
              setAccounts={setAccounts}
              onAddLog={addLog}
              onNavigateToMapping={() => setActiveTab('page-connect')}
              privacyMode={privacyMode}
              setPrivacyMode={setPrivacyMode}
            />
          )}

          {activeTab === 'page-connect' && (
            <PageConnectView
              accounts={accounts}
              setAccounts={setAccounts}
              creators={creators}
              onAddLog={addLog}
              onNavigateToDashboard={() => setActiveTab('dashboard')}
              privacyMode={privacyMode}
              setPrivacyMode={setPrivacyMode}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsView onAddLog={addLog} />
          )}
        </main>

        {/* BOTTOM TERMINAL LOGS DOCK */}
        <ConsoleDock
          logs={logs}
          activeLogTab={activeLogTab}
          setActiveLogTab={setActiveLogTab}
          onClearLogs={clearLogs}
        />
      </div>

      {/* LICENSE INFO / DEACTIVATION MODAL */}
      {showLicenseInfoModal && licenseSession && (
        <LicenseInfoModal
          session={licenseSession}
          onClose={() => setShowLicenseInfoModal(false)}
          onDeactivate={() => {
            setLicenseSession(null);
            setShowLicenseInfoModal(false);
            addLog('🔒 License deactivated from this machine.', 'warn', 'system');
          }}
        />
      )}
    </div>
  );
}
