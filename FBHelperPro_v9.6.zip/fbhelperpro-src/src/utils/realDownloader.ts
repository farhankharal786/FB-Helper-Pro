import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import { CreatorMapping } from '../types';

/**
 * Creator ke display links: farming cache (scrapedEntries) ho to wahi,
 * warna manual links. Links modal / ZIP export sab yahi istemal karen.
 */
export function creatorDisplayLinks(c: CreatorMapping): string[] {
  if (c.scrapedEntries && c.scrapedEntries.length > 0) {
    return c.scrapedEntries.map((e) => e.url).filter(Boolean);
  }
  return c.links || [];
}

/**
 * Downloads a plain text file directly to the user's machine
 */
export function downloadTextFile(filename: string, content: string) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  saveAs(blob, filename);
}

/**
 * Downloads a JSON configuration file directly
 */
export function downloadJsonFile(filename: string, data: any) {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
  saveAs(blob, filename);
}

/**
 * Creates and downloads a real ZIP archive containing all files
 */
export async function downloadRealZipArchive(
  archiveName: string,
  files: { name: string; content: string | Blob }[]
) {
  const zip = new JSZip();

  files.forEach((file) => {
    zip.file(file.name, file.content);
  });

  const zipBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  saveAs(zipBlob, archiveName);
}

/**
 * Downloads a real video MP4 stream
 */
export async function downloadDirectVideo(url: string, filename: string) {
  try {
    const response = await fetch(url);
    if (!response.ok) throw new Error('Fetch failed');
    const blob = await response.blob();
    saveAs(blob, filename.endsWith('.mp4') ? filename : `${filename}.mp4`);
  } catch {
    // If CORS prevents direct binary fetch, generate download anchor or fallback to text stream
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename.endsWith('.mp4') ? filename : `${filename}.mp4`;
    anchor.target = '_blank';
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
  }
}

/**
 * Compiles a real batch ZIP export for all selected creators
 */
export async function generateCreatorBatchZip(
  creators: CreatorMapping[],
  selectedOnly: boolean = false
) {
  const targetCreators = selectedOnly
    ? creators.filter((c) => c.selected)
    : creators;

  const activeList = targetCreators.length > 0 ? targetCreators : creators;
  const zip = new JSZip();

  // 1. All URLs compilation
  const allUrls = activeList.flatMap((c) => creatorDisplayLinks(c)).join('\r\n');
  zip.file('all_farmed_reels_urls.txt', allUrls || 'No URLs found.');

  // 2. Individual creator folders inside the zip
  activeList.forEach((creator) => {
    const folder = zip.folder(creator.name);
    if (folder) {
      // 2a. videos folder inside creator folder
      const videosSubFolder = folder.folder('videos');
      if (videosSubFolder) {
        creatorDisplayLinks(creator).forEach((link, idx) => {
          videosSubFolder.file(
            `reel_${String(idx + 1).padStart(2, '0')}.url`,
            `[InternetShortcut]\r\nURL=${link}\r\n`
          );
        });
        videosSubFolder.file(
          'videos_info.txt',
          `Farmed videos for ${creator.name} (${creator.platform})\r\nTotal links: ${creator.links.length}\r\nReady for Facebook Page upload!`
        );
      }

      // creator links file
      folder.file(
        `${creator.name}_links.txt`,
        creator.links.join('\r\n')
      );

      // creator metadata JSON
      folder.file(
        `${creator.name}_meta.json`,
        JSON.stringify(
          {
            creator: creator.name,
            platform: creator.platform,
            profileUrl: creator.profileUrl || '',
            totalQueue: creator.queue,
            processedDone: creator.done,
            exportedAt: new Date().toISOString(),
            developer: 'Farhan Kharal (WhatsApp: 03051705177)',
          },
          null,
          2
        )
      );

      // Windows one-click downloader script (.bat) using yt-dlp / curl
      const batchScript = `@echo off
echo ===================================================
echo FB HELPER - Auto Video Downloader
echo Creator: ${creator.name} (${creator.platform})
echo By Farhan Kharal - WhatsApp: 03051705177
echo ===================================================
echo Starting batch video download to this folder...
for /F "tokens=*" %%A in (${creator.name}_links.txt) do (
    echo Downloading: %%A
    yt-dlp -f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]" --no-mtime %%A
)
echo All videos downloaded successfully!
pause
`;
      folder.file(`start_download_${creator.name}.bat`, batchScript);
    }
  });

  // 3. System Readme & Farhan Kharal Signature
  const readme = `========================================================
FB HELPER - REAL FARMING & REELS DOWNLOAD PACKAGE
Developed by Farhan Kharal
WhatsApp: 03051705177
Generated: ${new Date().toLocaleString()}
========================================================

Contents:
- all_farmed_reels_urls.txt : Complete list of all extracted URLs
- Each creator folder contains:
   1. [creator]_links.txt : Extracted URLs for that creator
   2. [creator]_meta.json : Video metadata & platform settings
   3. start_download_[creator].bat : 1-click batch video downloader script

Thank you for using FB Helper!
`;
  zip.file('README_FB_HELPER.txt', readme);

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  const zipBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
  });

  saveAs(zipBlob, `fb_helper_real_export_${timestamp}.zip`);
}

/**
 * Downloads a single creator's isolated folder containing all their videos as a ZIP
 */
export async function downloadSingleCreatorFolderZip(creator: CreatorMapping) {
  const zip = new JSZip();
  const rootFolder = zip.folder(creator.folderName || creator.name);

  if (!rootFolder) return;

  const videosFolder = rootFolder.folder('videos');

  // Video files / shortcuts
  if (videosFolder) {
    if (creator.savedVideos && creator.savedVideos.length > 0) {
      creator.savedVideos.forEach((v, idx) => {
        videosFolder.file(
          `${v.filename || `reel_${idx + 1}.mp4`}.url`,
          `[InternetShortcut]\r\nURL=${v.url}\r\n`
        );
      });
    } else {
      creator.links.forEach((link, idx) => {
        videosFolder.file(
          `reel_${String(idx + 1).padStart(2, '0')}.url`,
          `[InternetShortcut]\r\nURL=${link}\r\n`
        );
      });
    }

    videosFolder.file(
      'videos_manifest.txt',
      `Creator: ${creator.name}\r\nPlatform: ${creator.platform}\r\nTotal Saved Videos: ${
        creator.savedVideos?.length || creator.links.length
      }\r\nFolder Path: ${creator.folderPath || `/creators/${creator.name}/videos/`}\r\nReady for auto-uploading to mapped Facebook Pages!`
    );
  }

  // Links list
  rootFolder.file(
    `${creator.name}_video_links.txt`,
    creator.links.join('\r\n') || 'No video links recorded.'
  );

  // Metadata JSON
  rootFolder.file(
    `${creator.name}_meta.json`,
    JSON.stringify(
      {
        creator: creator.name,
        platform: creator.platform,
        profileUrl: creator.profileUrl || '',
        folderPath: creator.folderPath || `/creators/${creator.name}/videos/`,
        totalSavedVideos: creator.savedVideos?.length || 0,
        savedVideos: creator.savedVideos || [],
        totalQueue: creator.queue,
        processedDone: creator.done,
        exportedAt: new Date().toISOString(),
        developer: 'Farhan Kharal (WhatsApp: 03051705177)',
      },
      null,
      2
    )
  );

  // Windows batch script to batch download videos
  const batchScript = `@echo off
echo ===================================================
echo FB HELPER - Auto Video Downloader
echo Folder: /creators/${creator.name}/videos/
echo Creator: ${creator.name} (${creator.platform})
echo By Farhan Kharal - WhatsApp: 03051705177
echo ===================================================
echo Starting high-speed batch download of all videos...
for /F "tokens=*" %%A in (${creator.name}_video_links.txt) do (
    echo Downloading: %%A
    yt-dlp -f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]" --no-mtime %%A
)
echo All videos downloaded to this folder!
pause
`;
  rootFolder.file(`start_download_${creator.name}.bat`, batchScript);

  const zipBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
  });

  saveAs(zipBlob, `${creator.name}_folder_videos.zip`);
}

