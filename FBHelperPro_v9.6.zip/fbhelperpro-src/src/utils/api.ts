/**
 * Real backend API client — v7.0
 * - Har request mein x-fbh-token header (local auth)
 * - Jobs: DB-backed queue, SSE real-time events
 * - Facebook: real sync/validate, OAuth
 */

export interface ApiJob {
  id: string;
  kind: 'download' | 'upload';
  label: string;
  status: 'queued' | 'downloading' | 'uploading' | 'done' | 'failed' | 'cancelled' | 'retrying' | 'skipped';
  download_status: string;
  upload_status: string;
  platform: string;
  video_id: string;
  source_url: string;
  title: string;
  progress: number;
  speed: string;
  eta: string;
  filepath: string;
  filename: string;
  file_size: number;
  page_id: string;
  page_name: string;
  error: string;
  postId: string;
  facebook_post_id: string;
  attempts: number;
  createdAt: string;
  updatedAt: string;
}

export interface ApiFile {
  name: string;
  path: string;
  size: number;
  mtime: number;
}

// ---- local auth token (item 15) ----
let _token: string | null = null;
async function getToken(): Promise<string> {
  if (_token) return _token;
  try {
    const w = window as any;
    if (w.__FBH_LOCAL_TOKEN) {
      _token = w.__FBH_LOCAL_TOKEN;
      return _token!;
    }
    // dev mode (vite :3000) — bootstrap se lo
    const r = await fetch('/api/auth/bootstrap');
    const j = await r.json();
    _token = j.token || '';
  } catch {
    _token = '';
  }
  return _token || '';
}
export { getToken };

async function req(path: string, opts?: RequestInit) {
  const t = await getToken();
  const r = await fetch(path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', 'x-fbh-token': t, ...(opts?.headers || {}) },
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.ok === false) {
    const err: any = new Error(j.error || `HTTP ${r.status}`);
    err.duplicate = !!j.duplicate;
    err.jobId = j.jobId;
    throw err;
  }
  return j;
}

export const apiStatus = () => req('/api/status');
/** Halka health check — token nahi chahiye (backend zinda hai ya nahi) */
export const apiHealth = () =>
  fetch('/api/health', { cache: 'no-store' }).then((r) => {
    if (!r.ok) throw new Error('health fail');
    return r.json();
  });

export type BackendState = 'on' | 'proxy-issue' | 'off';
/** Smart check: proxy se, na ho to direct 127.0.0.1:8573 (proxy vs backend farq) */
export const checkBackendSmart = async (): Promise<{ state: BackendState; detail: string }> => {
  try {
    await apiHealth();
    return { state: 'on', detail: 'OK' };
  } catch (e: any) {
    const proxyErr = String(e?.message || e).slice(0, 80);
    // direct try (vite proxy bypass) — no-cors: connect ho to opaque response
    try {
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), 4000);
      await fetch('http://127.0.0.1:8573/api/health', { mode: 'no-cors', cache: 'no-store', signal: ctl.signal });
      clearTimeout(t);
      return { state: 'proxy-issue', detail: `Proxy fail (${proxyErr}) — backend direct chal raha hai` };
    } catch {
      return { state: 'off', detail: `Backend down (${proxyErr})` };
    }
  }
};

export const startDownload = (url: string, subfolder: string, quality = '1080p', maxDownloads = 0) =>
  req('/api/download', {
    method: 'POST',
    body: JSON.stringify({ url, subfolder, quality, maxDownloads }),
  }).then((j) => j.jobId as string);

export const startUpload = (pageId: string, pageToken: string, filepath: string, caption = '', pageName = '') =>
  req('/api/upload', {
    method: 'POST',
    body: JSON.stringify({ pageId, pageToken, pageName, filepath, caption }),
  }).then((j) => j.jobId as string);

export const getJob = (id: string) =>
  req(`/api/job/${id}`).then((j) => j.job as ApiJob);

export const stopJob = (id: string) =>
  req(`/api/job/${id}/stop`, { method: 'POST' });

// ---- jobs queue API (items 11, 13) ----
export const listJobs = (limit = 100, offset = 0) =>
  req(`/api/jobs?limit=${limit}&offset=${offset}`).then((j) => ({
    jobs: j.jobs as ApiJob[], total: j.total as number, paused: !!j.paused,
  }));
export const cancelJob = (id: string) =>
  req(`/api/jobs/${id}/cancel`, { method: 'POST' }).then((j) => j.job as ApiJob);
export const retryJob = (id: string) =>
  req(`/api/jobs/${id}/retry`, { method: 'POST' }).then((j) => j.job as ApiJob);
export const deleteJob = (id: string) =>
  req(`/api/jobs/${id}/delete`, { method: 'POST' });
export const pauseQueue = () => req('/api/jobs/queue/pause', { method: 'POST' });
export const resumeQueue = () => req('/api/jobs/queue/resume', { method: 'POST' });

/** SSE: job events suno (item 11) — onJob(job), onQueue({paused}) */
export function subscribeJobEvents(onJob: (job: ApiJob) => void, onQueue?: (info: any) => void) {
  let es: EventSource | null = null;
  let closed = false;
  // EventSource header nahi bhej sakta — token query param mein
  getToken().then((t) => {
    if (closed) return;
    es = new EventSource(`/api/jobs/events?token=${encodeURIComponent(t)}`);
    es.addEventListener('job', (e: any) => {
      try { onJob(JSON.parse(e.data)); } catch {}
    });
    es.addEventListener('queue', (e: any) => {
      try { onQueue && onQueue(JSON.parse(e.data)); } catch {}
    });
  });
  return () => { closed = true; try { es && es.close(); } catch {} };
}

export const listFiles = (subfolder: string) =>
  req(`/api/files?subfolder=${encodeURIComponent(subfolder)}`).then((j) => j.files as ApiFile[]);

/** Job complete hone tak poll karo (2s interval). */
export function pollJob(
  id: string,
  onTick: (job: ApiJob) => void,
  timeoutMs = 30 * 60 * 1000
): Promise<ApiJob> {
  return new Promise((resolve, reject) => {
    const t0 = Date.now();
    let consecErr = 0;
    const timer = setInterval(async () => {
      try {
        if (Date.now() - t0 > timeoutMs) {
          clearInterval(timer);
          reject(new Error('timeout'));
          return;
        }
        const job = await getJob(id);
        consecErr = 0;
        onTick(job);
        if (job.status === 'done' || job.status === 'failed' || job.status === 'cancelled') {
          clearInterval(timer);
          job.status === 'done' ? resolve(job) : reject(new Error(job.error || job.status));
        }
      } catch (e: any) {
        consecErr += 1;
        // lagatar 5 poll fail = backend down — 30min latkao mat, saaf batao
        if (consecErr >= 5) {
          clearInterval(timer);
          reject(new Error('Backend se rabta toot gaya (lagatar 5 polls fail). RUN.bat ki backend window check karo.'));
        }
        // warna aik-do failed poll ignore (server restart waghera)
      }
    }, 2000);
  });
}

/** Backend /downloads static route par file ka public URL.
 *  Backend layout: <downloadsDir>/<safeFolderName(subfolder)>/<filename>
 *  (server/queue.cjs runDownload + server.cjs '/downloads' static mount) */
const safeFolderName = (name: string) =>
  (String(name || 'creator').replace(/[<>:\"/\\|?*\x00-\x1f]/g, '').trim().replace(/\s+/g, '_') || 'creator').slice(0, 40);
export const downloadFileUrl = (subfolder: string, filename: string) =>
  `/downloads/${encodeURIComponent(safeFolderName(subfolder || 'downloads'))}/${encodeURIComponent(filename)}`;

/** "5" / "All" jaisi limit string → number (0 = sab). */
export function parseLimit(limit: string): number {
  const n = parseInt(limit, 10);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

export interface ScrapeEntry {
  id: string;
  title: string;
  url: string;
  views: number;
  view_count?: number;
  upload_date?: string;
}

/** Pehle run par saari links scrape karo — sort: 'newest' | 'oldest' | 'popular'. */
export const scrapeLinks = (url: string, sort: string) =>
  req('/api/scrape', {
    method: 'POST',
    body: JSON.stringify({ url, sort }),
  }).then((j) => ({ count: j.count as number, entries: j.entries as ScrapeEntry[] }));

/** Download ki hui file(s) delete karo — {all: true} = saari. */
export const deleteFiles = (opts: { path?: string; all?: boolean }) =>
  req('/api/delete', {
    method: 'POST',
    body: JSON.stringify(opts),
  }).then((j) => j.deleted as number);

// ---- Local database info (100% is PC par) ----
export const dbInfo = () => req('/api/db/info');

// ---- UI state persistence (creators + accounts — app dobara khule to wapas) ----
export const getUiState = () => req('/api/ui-state');
export const saveUiState = (creators: unknown[], accounts: unknown[]) =>
  req('/api/ui-state', { method: 'POST', body: JSON.stringify({ creators, accounts }) });

// ---- Downloads folder (user apne PC par choose kare) ----
export const getDownloadsDir = () => req('/api/settings/downloads-dir');
export const setDownloadsDir = (path: string) =>
  req('/api/settings/downloads-dir', { method: 'POST', body: JSON.stringify({ path }) });

// ---- Facebook real sync (items 1, 2, 3) ----
export interface FbPage {
  page_id: string;
  name: string;
  category: string;
  token: string;
  picture: string;
  tasks: string[];
  token_valid: boolean;
  token_error: string;
}
export interface FbBusiness {
  bm_id: string;
  name: string;
  owned_pages: { page_id: string; name: string }[];
}
export const fbSyncPages = (token: string) =>
  req('/api/fb/sync-pages', { method: 'POST', body: JSON.stringify({ token }) }).then((j) => ({
    user: j.user as { id: string; name: string }, pages: j.pages as FbPage[],
  }));
export const fbSyncBusinesses = (token: string) =>
  req('/api/fb/sync-businesses', { method: 'POST', body: JSON.stringify({ token }) }).then((j) => ({
    user: j.user as { id: string; name: string },
    businesses: j.businesses as FbBusiness[],
    permissionMissing: !!j.permissionMissing,
    note: j.note as string,
  }));
export const fbValidateToken = (token: string) =>
  req('/api/fb/validate-token', { method: 'POST', body: JSON.stringify({ token }) });

export const fbValidatePageToken = (pageId: string, token: string) =>
  req('/api/fb/validate-page-token', { method: 'POST', body: JSON.stringify({ pageId, token }) });

export const fbFetchPages = (token: string) =>
  req('/api/fb/fetch-pages', { method: 'POST', body: JSON.stringify({ token }) });

export const fbGetPageToken = (pageId: string, token: string) =>
  req('/api/fb/page-token', { method: 'POST', body: JSON.stringify({ pageId, token }) });

// ---- OAuth (item 1) ----
export const oauthGetConfig = () => req('/api/oauth/config');
export const oauthSaveConfig = (appId: string, appSecret: string) =>
  req('/api/oauth/config', { method: 'POST', body: JSON.stringify({ appId, appSecret }) });
export const oauthStartUrl = () => req('/api/oauth/start').then((j) => j.url as string);
export const oauthTokenStatus = (token: string) =>
  req('/api/oauth/status', { method: 'POST', body: JSON.stringify({ token }) });

/** Automation settings (Settings tab) — localStorage mein. */
export const getAutoDelete = () => localStorage.getItem('fbh_autoDelete') !== '0';
export const getAutoRescrape = () => localStorage.getItem('fbh_autoRescrape') !== '0';
