import { ScrapeEntry } from './utils/api';

export type Platform = 'TikTok' | 'Instagram' | 'YouTube' | 'Facebook';

export interface SavedVideo {
  id: string;
  filename: string;
  title: string;
  url: string;
  /** Backend par asal local file ka absolute path (play/download/delete ke liye) */
  filePath?: string;
  thumbnailUrl?: string;
  duration?: string;
  size?: string;
  resolution?: string;
  createdAt: string;
  status: 'Saved in Folder' | 'Queued for Upload' | 'Uploaded to Page';
  uploadedPages?: string[];
}

export interface CreatorMapping {
  id: string;
  name: string;
  profileUrl?: string;
  platform: Platform;
  capsPage: boolean;
  limit: string;
  queue: number;
  done: number;
  metaAi: boolean;
  monetized: boolean;
  selected: boolean;
  profileId?: string;
  avatarUrl?: string;
  links: string[];
  folderName?: string;
  folderPath?: string;
  savedVideos?: SavedVideo[];
  /** Farming link cache: pehli scrape par SAARI links ek dafa save — har run par dobara scrape nahi */
  scrapedEntries?: ScrapeEntry[];
  scrapedAt?: string;
  /** Jin scraped entries ka download ho chuka (persistent — dobara download nahi hongi) */
  farmedIds?: string[];
}

export interface FbPageMapping {
  id: string;
  name: string;
  pageId: string;
  status: 'Active' | 'Paused' | 'Pending' | 'Error';
  videoFolder: string;
  sourceCreatorId?: string;
  sourceCreatorName?: string;
  sourcePlatform?: string;
  monetized: boolean;
  posts: number;
  dedicatedProxy: string;
  accountId: string;
  pageAccessToken?: string;
  category?: string;
}

export interface BmAccount {
  id: string;
  name: string;
  accountNumber: string;
  accountDisplayId: string;
  type: string;
  accountType?: 'Personal ID' | 'Business Manager (BM)';
  accessToken?: string;
  tokenStatus?: 'Valid' | 'Expired' | 'Unverified';
  proxy: string;
  isPaused: boolean;
  tag: string;
  pages: FbPageMapping[];
}

export interface LogItem {
  id: string;
  timestamp: string;
  category: 'download' | 'upload' | 'system' | 'proxy';
  level: 'info' | 'success' | 'warn' | 'error';
  message: string;
}

export type LicensePlan = '7 Days' | '15 Days' | '30 Days' | '90 Days' | '1 Year' | 'Lifetime';
export type LicenseStatus = 'active' | 'revoked' | 'expired';

export interface ActivatedDevice {
  hwid: string;
  activatedAt: string;
  userAgent?: string;
  lastSeen?: string;
}

export interface LicenseKeyRecord {
  key: string;
  plan: LicensePlan;
  planName: string;
  clientName: string;
  clientContact?: string;
  status: LicenseStatus;
  createdAt: string;
  expiresAt: string | null;
  durationDays: number | null;
  maxDevices: number;
  activatedDevices: ActivatedDevice[];
  hwidLock: boolean;
  notes?: string;
}

export interface KeyDatabaseFile {
  system: string;
  version: string;
  adminContact: string;
  updatedAt: string;
  keys: LicenseKeyRecord[];
}

export interface ClientLicenseSession {
  key: string;
  plan: LicensePlan;
  planName: string;
  clientName: string;
  activatedAt: string;
  expiresAt: string | null;
  hwid: string;
  isLifetime: boolean;
}
