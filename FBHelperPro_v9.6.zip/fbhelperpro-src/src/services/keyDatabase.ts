import { ClientLicenseSession } from '../types';
import { getToken } from '../utils/api';

const STORAGE_KEY_LICENSE = 'fb_helper_active_license_v1';
const STORAGE_KEY_HWID = 'fb_helper_device_hwid_v1';

/**
 * SIGNED LICENSE MODEL (v8.9+):
 * Key khud mukammal hai — HWID lock + expiry key ke andar HMAC-SHA256
 * signature ke saath. Koi keys_database.json nahi, koi sync nahi.
 * Nayi keys SIRF owner keygen se banti hain.
 * Backend (server.cjs) /api/license/* par verify karta hai aur
 * activated license data/license.json mein rakhta hai.
 */

/** Backend local-auth token har license request ke header mein (warna 401) */
async function authHeaders(extra: Record<string, string> = {}): Promise<Record<string, string>> {
  let t = '';
  try { t = await getToken(); } catch {}
  return { 'x-fbh-token': t, ...extra };
}

/**
 * Generates or retrieves a persistent Machine Hardware Fingerprint (HWID)
 */
export function getDeviceHwid(): string {
  if (typeof window === 'undefined') return 'HWID-SERVER-NODE-0000';

  const stored = localStorage.getItem(STORAGE_KEY_HWID);
  if (stored && stored.length > 8) {
    return stored;
  }

  // Construct a deterministic hardware fingerprint from browser environment
  const nav = window.navigator;
  const screen = window.screen;
  const rawFingerprint = [
    nav.platform || 'Platform',
    screen.width + 'x' + screen.height,
    screen.colorDepth,
    nav.hardwareConcurrency || 4,
    Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    nav.language || 'en',
    (nav as any).deviceMemory || 8,
  ].join('###');

  // DJB2-like hash to generate clean HWID format: HWID-XXXX-XXXX-XXXX
  let hash1 = 5381;
  let hash2 = 52711;
  for (let i = 0; i < rawFingerprint.length; i++) {
    const char = rawFingerprint.charCodeAt(i);
    hash1 = ((hash1 << 5) + hash1) ^ char;
    hash2 = ((hash2 << 5) + hash2) ^ (char * 31);
  }

  const p1 = Math.abs(hash1 % 65536)
    .toString(16)
    .toUpperCase()
    .padStart(4, '0');
  const p2 = Math.abs(hash2 % 65536)
    .toString(16)
    .toUpperCase()
    .padStart(4, '0');
  const p3 = Math.floor(1000 + Math.random() * 9000).toString();

  const generatedHwid = `HWID-${p1}-${p2}-${p3}`;
  localStorage.setItem(STORAGE_KEY_HWID, generatedHwid);
  return generatedHwid;
}

/**
 * Verifies the current license with the backend.
 * Backend signed key ko verify karta hai (signature + HWID + expiry).
 */
export async function verifyCurrentLicense(): Promise<{
  isValid: boolean;
  session: ClientLicenseSession | null;
  error?: string;
}> {
  const rawSession = localStorage.getItem(STORAGE_KEY_LICENSE);
  if (!rawSession) {
    return { isValid: false, session: null };
  }

  let session: ClientLicenseSession;
  try {
    session = JSON.parse(rawSession);
  } catch {
    localStorage.removeItem(STORAGE_KEY_LICENSE);
    return { isValid: false, session: null, error: 'Invalid license format' };
  }

  const currentHwid = getDeviceHwid();

  // Backend verification (signed key check)
  try {
    const res = await fetch('/api/license/verify', {
      method: 'POST',
      headers: await authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ key: session.key, hwid: currentHwid }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.isValid && data.session) {
        localStorage.setItem(STORAGE_KEY_LICENSE, JSON.stringify(data.session));
        return { isValid: true, session: data.session };
      }
      localStorage.removeItem(STORAGE_KEY_LICENSE);
      return { isValid: false, session: null, error: data.error || 'License invalid' };
    }
  } catch {
    // Backend down — cached session par local expiry check
  }

  // Offline fallback: sirf cached session ki expiry dekho (signature dobara
  // check nahi ho sakta, lekin expiry backend ne pehle tasdeeq ki thi)
  if (session.isLifetime) return { isValid: true, session };
  if (session.expiresAt && Date.now() > new Date(session.expiresAt).getTime()) {
    localStorage.removeItem(STORAGE_KEY_LICENSE);
    return { isValid: false, session: null, error: 'License has expired.' };
  }
  return { isValid: true, session };
}

/**
 * Activates a signed license key for this machine.
 * Key mein HWID lock hota hai — ghalat PC par reject ho jayegi.
 */
export async function activateLicenseKey(
  inputKey: string
): Promise<{ success: boolean; session?: ClientLicenseSession; error?: string }> {
  const trimmed = inputKey.trim().toUpperCase();
  if (!trimmed) {
    return { success: false, error: 'Please enter a valid license key.' };
  }
  if (!trimmed.startsWith('FBH1-')) {
    return {
      success: false,
      error: 'Ye purani format ki key hai. Owner se nayi signed key lo (Farhan Kharal — 03051705177).',
    };
  }

  const currentHwid = getDeviceHwid();

  try {
    const res = await fetch('/api/license/activate', {
      method: 'POST',
      headers: await authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ key: trimmed, hwid: currentHwid }),
    });

    const data = await res.json().catch(() => ({}));
    if (res.ok && data.success && data.session) {
      localStorage.setItem(STORAGE_KEY_LICENSE, JSON.stringify(data.session));
      return { success: true, session: data.session };
    }
    return { success: false, error: data.error || 'Activation failed.' };
  } catch {
    return {
      success: false,
      error: 'Backend se rabta nahi ho saka. Pehle RUN.bat se backend chalao.',
    };
  }
}

/**
 * Deactivates license on current machine
 */
export async function deactivateCurrentLicense(): Promise<void> {
  try {
    await fetch('/api/license/deactivate', {
      method: 'POST',
      headers: await authHeaders(),
    });
  } catch {
    // backend down ho to bhi local clear karo
  }
  localStorage.removeItem(STORAGE_KEY_LICENSE);
}

/**
 * Calculates remaining days or status string
 */
export function formatRemainingLicense(session: ClientLicenseSession | null): string {
  if (!session) return 'No License';
  if (session.isLifetime || !session.expiresAt) return 'Lifetime VIP Unlimited';

  const expiry = new Date(session.expiresAt).getTime();
  const diffMs = expiry - Date.now();
  if (diffMs <= 0) return 'Expired';

  const days = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
  if (days === 1) return '1 Day Remaining';
  return `${days} Days Remaining`;
}

export interface SyncStatus {
  connected: boolean;
  type: 'sse' | 'polling' | 'offline';
  lastSync: string;
}

/**
 * CONNECTION MONITOR:
 * /api/jobs/events se backend connectivity dekhta hai (Sidebar indicator
 * ke liye). Keys ka koi database nahi raha — sync ki zaroorat nahi.
 */
export function subscribeRealTimeKeySync(
  onUpdate: () => void,
  onStatusChange?: (status: SyncStatus) => void
): () => void {
  let isUnmounted = false;
  let eventSource: EventSource | null = null;
  let pollInterval: ReturnType<typeof setInterval> | null = null;

  const notifyStatus = (status: SyncStatus) => {
    if (!isUnmounted && onStatusChange) {
      onStatusChange(status);
    }
  };

  async function connectSse() {
    if (typeof window === 'undefined' || typeof EventSource === 'undefined') {
      startPolling();
      return;
    }

    try {
      // EventSource header nahi bhej sakta — token query param mein (local auth)
      const w = window as any;
      let tok = w.__FBH_LOCAL_TOKEN || '';
      if (!tok) {
        try {
          const r = await fetch('/api/auth/bootstrap');
          const j = await r.json();
          tok = j.token || '';
          w.__FBH_LOCAL_TOKEN = tok;
        } catch {}
      }
      eventSource = new EventSource(`/api/jobs/events?token=${encodeURIComponent(tok)}`);

      const markOnline = () => {
        notifyStatus({
          connected: true,
          type: 'sse',
          lastSync: new Date().toLocaleTimeString(),
        });
      };

      eventSource.addEventListener('connected', () => {
        markOnline();
        if (!isUnmounted) onUpdate();
      });

      eventSource.addEventListener('ping', markOnline);

      eventSource.onerror = () => {
        notifyStatus({
          connected: false,
          type: 'offline',
          lastSync: new Date().toLocaleTimeString(),
        });
        if (eventSource) {
          eventSource.close();
          eventSource = null;
        }
        if (!isUnmounted) {
          startPolling();
          setTimeout(() => {
            if (!isUnmounted && !eventSource) {
              connectSse();
            }
          }, 6000);
        }
      };
    } catch {
      startPolling();
    }
  }

  function startPolling() {
    if (pollInterval) return;
    pollInterval = setInterval(async () => {
      if (isUnmounted) return;
      try {
        const res = await fetch('/api/health', {
          cache: 'no-store',
          headers: await authHeaders(),
        });
        if (res.ok) {
          notifyStatus({
            connected: true,
            type: 'polling',
            lastSync: new Date().toLocaleTimeString(),
          });
          if (pollInterval) {
            clearInterval(pollInterval);
            pollInterval = null;
          }
          connectSse();
        } else {
          notifyStatus({
            connected: false,
            type: 'offline',
            lastSync: new Date().toLocaleTimeString(),
          });
        }
      } catch {
        notifyStatus({
          connected: false,
          type: 'offline',
          lastSync: new Date().toLocaleTimeString(),
        });
      }
    }, 5000);
  }

  connectSse();

  return () => {
    isUnmounted = true;
    if (eventSource) {
      eventSource.close();
      eventSource = null;
    }
    if (pollInterval) {
      clearInterval(pollInterval);
      pollInterval = null;
    }
  };
}
