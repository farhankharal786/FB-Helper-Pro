import React, { useState, useRef, useEffect } from 'react';
import {
  Zap,
  Download,
  Search,
  ChevronLeft,
  ChevronRight,
  ChevronDown,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Copy,
  Check,
  X,
  ExternalLink,
  Link2,
  FileDown,
  FolderDown,
  Folder,
  FolderOpen,
  Film,
  HardDrive,
} from 'lucide-react';
import { CreatorMapping, Platform, SavedVideo, BmAccount } from '../types';
import { FbHelperLogo } from './FbHelperLogo';
import { CreatorFolderModal } from './CreatorFolderModal';
import { AllFoldersModal } from './AllFoldersModal';
import {
  generateCreatorBatchZip,
  downloadTextFile,
  creatorDisplayLinks,
} from '../utils/realDownloader';
import {
  startDownload,
  startUpload,
  pollJob,
  stopJob,
  scrapeLinks,
  parseLimit,
  deleteFiles,
  listFiles,
  getDownloadsDir,
  setDownloadsDir,
  apiHealth,
  checkBackendSmart,
  BackendState,
  getAutoDelete,
  getAutoRescrape,
  ScrapeEntry,
} from '../utils/api';

interface DashboardViewProps {
  creators: CreatorMapping[];
  setCreators: React.Dispatch<React.SetStateAction<CreatorMapping[]>>;
  accounts?: BmAccount[];
  setAccounts?: React.Dispatch<React.SetStateAction<BmAccount[]>>;
  onAddLog: (
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error',
    category?: 'download' | 'upload' | 'system'
  ) => void;
  onNavigateToMapping?: () => void;
  privacyMode: boolean;
  setPrivacyMode: (val: boolean) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  creators,
  setCreators,
  accounts = [],
  setAccounts,
  onAddLog,
  onNavigateToMapping,
  privacyMode,
  setPrivacyMode,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState<string>('All Platforms');
  const [sortOption, setSortOption] = useState<string>('Newest');
  const [limitCount, setLimitCount] = useState<number>(2);
  const [isFarmingActive, setIsFarmingActive] = useState<boolean>(false);

  // Modals
  const [activeLinksModal, setActiveLinksModal] = useState<CreatorMapping | null>(null);
  const [showAddCreatorModal, setShowAddCreatorModal] = useState(false);
  const [selectedFolderCreator, setSelectedFolderCreator] = useState<CreatorMapping | null>(null);
  const [showAllFoldersModal, setShowAllFoldersModal] = useState(false);
  // Download folder picker (yahan creators ke folders banein ge)
  const [showFolderPicker, setShowFolderPicker] = useState(false);
  const [dlDir, setDlDir] = useState('');
  const [dlDirInput, setDlDirInput] = useState('');
  const [dlDirSuggestions, setDlDirSuggestions] = useState<{ label: string; p: string }[]>([]);
  const [dlDirSaving, setDlDirSaving] = useState(false);
  // Backend state — har 5s smart check (proxy vs backend farq ke saath)
  const [backendState, setBackendState] = useState<BackendState | null>(null);
  const [backendDetail, setBackendDetail] = useState('');
  useEffect(() => {
    let alive = true;
    const check = async () => {
      const r = await checkBackendSmart();
      if (alive) { setBackendState(r.state); setBackendDetail(r.detail); }
    };
    check();
    const t = setInterval(check, 5000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  const openFolderPicker = async () => {
    setShowFolderPicker(true);
    try {
      const d = await getDownloadsDir();
      setDlDir(d.path || '');
      setDlDirInput(d.path || '');
      setDlDirSuggestions(d.suggestions || []);
    } catch {}
  };
  const handleSaveDlDir = async () => {
    if (!dlDirInput.trim()) return;
    setDlDirSaving(true);
    try {
      const r = await setDownloadsDir(dlDirInput.trim());
      setDlDir(r.path);
      setShowFolderPicker(false);
      onAddLog(`📁 Download folder set: ${r.path} — ab har creator ka folder yahin banega.`, 'success', 'system');
    } catch (e: any) {
      onAddLog(`❌ Folder set nahi hua: ${e.message || e}`, 'error', 'system');
    }
    setDlDirSaving(false);
  };

  // Form State for Adding Creator
  const [newCreatorProfileUrl, setNewCreatorProfileUrl] = useState('');
  const [newCreatorName, setNewCreatorName] = useState('');
  const [newCreatorPlatform, setNewCreatorPlatform] = useState<Platform>('TikTok');
  const [newCreatorLimit, setNewCreatorLimit] = useState('All');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  // REAL backend: active download job ids (yt-dlp)
  const activeJobs = useRef<string[]>([]);
  // autopilot loop ko STOP ALL se toro
  const farmingActiveRef = useRef(false);

  // Tab switch par view unmount hota hai — loop ko latka mat rehne do
  // (STOP button unmount ho jata hai, warna background mein kaam chalta rehta).
  useEffect(() => {
    return () => {
      if (farmingActiveRef.current) {
        farmingActiveRef.current = false;
      }
    };
  }, []);

  // rukawat ke sath wait (STOP dabane par foran niklo)
  const sleepMs = (ms: number) =>
    new Promise<void>((resolve) => {
      let t = 0;
      const timer = setInterval(() => {
        t += 2000;
        if (!farmingActiveRef.current || t >= ms) {
          clearInterval(timer);
          resolve();
        }
      }, 2000);
    });

  // Auto-detect platform and username from URL input
  const handleProfileUrlChange = (url: string) => {
    setNewCreatorProfileUrl(url);
    const lower = url.toLowerCase();
    let detectedPlatform: Platform = newCreatorPlatform;

    if (lower.includes('tiktok.com')) {
      detectedPlatform = 'TikTok';
    } else if (lower.includes('instagram.com')) {
      detectedPlatform = 'Instagram';
    } else if (lower.includes('youtube.com') || lower.includes('youtu.be')) {
      detectedPlatform = 'YouTube';
    } else if (lower.includes('facebook.com')) {
      detectedPlatform = 'Facebook';
    }
    setNewCreatorPlatform(detectedPlatform);

    // Try extracting username
    try {
      const matchTiktok = url.match(/@([a-zA-Z0-9_.-]+)/);
      if (matchTiktok && matchTiktok[1]) {
        setNewCreatorName(matchTiktok[1]);
        return;
      }

      const matchIg = url.match(/instagram\.com\/([a-zA-Z0-9_.-]+)/);
      if (matchIg && matchIg[1] && !['p', 'reel', 'stories', 'explore'].includes(matchIg[1])) {
        setNewCreatorName(matchIg[1]);
        return;
      }

      const matchYt = url.match(/youtube\.com\/@?([a-zA-Z0-9_.-]+)/);
      if (matchYt && matchYt[1] && !['watch', 'shorts', 'channel'].includes(matchYt[1])) {
        setNewCreatorName(matchYt[1]);
        return;
      }
    } catch {
      // Fallback
    }
  };

  // Selection handlers
  const allSelected = creators.length > 0 && creators.every((c) => c.selected);

  const toggleSelectAll = () => {
    const next = !allSelected;
    setCreators((prev) => prev.map((c) => ({ ...c, selected: next })));
  };

  const toggleSelectCreator = (id: string) => {
    setCreators((prev) =>
      prev.map((c) => (c.id === id ? { ...c, selected: !c.selected } : c))
    );
  };

  const toggleCapsPage = (id: string) => {
    setCreators((prev) =>
      prev.map((c) => (c.id === id ? { ...c, capsPage: !c.capsPage } : c))
    );
  };

  const handleDeleteCreator = (id: string, name: string) => {
    setCreators((prev) => prev.filter((c) => c.id !== id));
    onAddLog(`🗑 Removed creator profile: ${name}`, 'warn', 'download');
  };

  // REAL downloading system (yt-dlp backend) — naqli timer hata diya
  // ---- pipeline helpers ----
  const sortMode = () => {
    const s = sortOption.toLowerCase();
    if (s.includes('oldest')) return 'oldest';
    if (s.includes('queue high') || s.includes('popular')) return 'popular';
    return 'newest';
  };
  // limit: row wali (agar number ho) warna global Limit input
  const effLimit = (c: CreatorMapping) => parseLimit(c.limit) || limitCount;

  // creator se mapped active pages (token ke saath)
  const mappedPagesFor = (creatorName: string) =>
    accounts.flatMap((a) =>
      a.pages
        .filter(
          (p) =>
            p.sourceCreatorName?.toLowerCase() === creatorName.toLowerCase() &&
            p.status === 'Active' &&
            p.pageAccessToken
        )
        .map((p) => ({ accId: a.id, page: p }))
    );

  // aik entry download karo → filepath
  // DUPLICATE ho (pehle se downloaded) to folder mein maujood file dobara use karo — upload skip NAHI hoga
  const downloadEntry = async (c: CreatorMapping, entry: ScrapeEntry): Promise<string> => {
    const folder = c.folderName || c.name;
    try {
      const jobId = await startDownload(entry.url, folder, '1080p', 0);
      activeJobs.current.push(jobId);
      try {
        const job = await pollJob(jobId, () => {});
        return job.filepath;
      } finally {
        activeJobs.current = activeJobs.current.filter((x) => x !== jobId);
      }
    } catch (e: any) {
      if (e.duplicate) {
        // Pehle se download hai — folder mein asal file dhoondo (video ID filename mein hota hai)
        onAddLog(`ℹ️ [${c.name}] pehle se downloaded — maujood file use ho rahi hai.`, 'info', 'download');
        try {
          const files = await listFiles(folder);
          const vid = (entry.id || '').trim();
          const match = files.find((f) => vid && f.name.includes(vid) && /\.(mp4|mov|mkv|avi|webm)$/i.test(f.name))
            || files.filter((f) => /\.(mp4|mov|mkv|avi|webm)$/i.test(f.name))[0];
          if (match && match.path) return match.path;
        } catch {}
        // file na mile to asal error phir se
      }
      throw e;
    }
  };

  // file ko tamam mapped pages par ORIGINAL TITLE ke saath upload karo
  const uploadToMappedPages = async (
    c: CreatorMapping,
    filepath: string,
    title: string
  ): Promise<number> => {
    if (!setAccounts) return 0;
    const targets = mappedPagesFor(c.name);
    let n = 0;
    for (const { accId, page } of targets) {
      try {
        const jobId = await startUpload(page.pageId, page.pageAccessToken!, filepath, title);
        await pollJob(jobId, () => {});
        setAccounts((prev) =>
          prev.map((a) =>
            a.id === accId
              ? { ...a, pages: a.pages.map((p) => (p.id === page.id ? { ...p, posts: p.posts + 1 } : p)) }
              : a
          )
        );
        n += 1;
        onAddLog(`✅ [${page.name}] "${title.slice(0, 50)}" upload ho gaya!`, 'success', 'upload');
      } catch (e: any) {
        onAddLog(`❌ [${page.name}] upload failed: ${e.message || e}`, 'error', 'upload');
      }
    }
    return n;
  };

  const baseName = (fp: string) => fp.split(/[\\/]/).pop() || fp;

  // first run: saari links scrape karo (sort ke hisaab se) → Queue mein count
  const scrapeCreator = async (c: CreatorMapping) => {
    const url = (c.profileUrl || '').trim();
    if (!url) throw new Error('profile URL missing');
    onAddLog(`🔍 [${c.name}] links scrape ho rahi hain (sort: ${sortOption})...`, 'info', 'download');
    const { count, entries } = await scrapeLinks(url, sortMode());
    setCreators((prev) => prev.map((p) => (p.id === c.id ? { ...p, queue: count } : p)));
    onAddLog(`📋 [${c.name}] ${count} links mili`, 'info', 'download');
    return entries;
  };

  // LINK CACHE (scrape-once model):
  // Pehli scrape par creator ki SAARI links ek dafa save hoti hain.
  // Agli runs mein dobara scrape NAHI — cache reuse hota hai.
  // Cache khatm ho to hi fresh scrape (nayi videos merge).
  const persistLinkCache = (
    creatorId: string,
    cache: ScrapeEntry[],
    processed: Set<string>,
    scrapedAt?: string
  ) => {
    const snap = [...cache];
    const farmed = [...processed];
    setCreators((prev) =>
      prev.map((p) =>
        p.id === creatorId
          ? {
              ...p,
              scrapedEntries: snap,
              scrapedAt: scrapedAt || p.scrapedAt,
              farmedIds: farmed,
              queue: snap.filter((e) => !processed.has(e.id)).length,
            }
          : p
      )
    );
  };

  // START FARMING: download + upload sath sath (original title ke saath)
  // + autopilot: upload ke baad auto-delete, links khatm hon to dobara scrape
  const handleStartFarming = async () => {
    if (creators.length === 0) {
      onAddLog('⚠️ Cannot start farming: No creator accounts added. Click "+ Add Creator" first.', 'warn', 'download');
      return;
    }
    // Double-click guard — doosra loop shuru na ho (duplicate uploads se bacho)
    if (farmingActiveRef.current) {
      onAddLog('⚠️ Farming pehle se chal rahi hai.', 'warn', 'download');
      return;
    }
    // PRE-FLIGHT: backend zinda hai? (na ho to loop mein phasne se pehle roko)
    const pre = await checkBackendSmart();
    setBackendState(pre.state); setBackendDetail(pre.detail);
    if (pre.state !== 'on') {
      onAddLog(`🛑 Backend masla: ${pre.detail}`, 'error', 'download');
      onAddLog('💡 RUN.bat ki "Backend :8573" wali window kholo — wahan asal wajah likhi hogi.', 'warn', 'download');
      onAddLog('💡 STOP.bat chala kar phir RUN.bat chalao (purana backend atka ho sakta hai).', 'warn', 'download');
      return;
    }
    const targets = creators.some((c) => c.selected)
      ? creators.filter((c) => c.selected)
      : creators;
    farmingActiveRef.current = true;
    setIsFarmingActive(true);
    const autoDel = getAutoDelete();
    const autoRe = getAutoRescrape();
    onAddLog(
      `⚡ START FARMING — download + upload pipeline shuru (auto-delete: ${autoDel ? 'ON' : 'OFF'}, auto-rescrape: ${autoRe ? 'ON' : 'OFF'})`,
      'info',
      'download'
    );

    for (const c of targets) {
      if (!farmingActiveRef.current) break;
      const lim = effLimit(c);
      // Persistent cache — pichli runs ki links + processed (app restart par bhi mehfooz)
      let cache: ScrapeEntry[] = [...(c.scrapedEntries || [])];
      let cacheStamp: string | undefined = c.scrapedAt;
      const processed = new Set<string>(c.farmedIds || []);
      let emptyRounds = 0;
      // LIMIT = is run mein TOTAL kitni videos (pehle har batch par lagti thi — bug tha)
      const limTotal = lim > 0 ? lim : Number.POSITIVE_INFINITY;
      const limLabel = lim > 0 ? String(lim) : 'All';
      let doneThisRun = 0;
      let consecUploadFails = 0;
      let stopCreator = false;

      while (farmingActiveRef.current && !stopCreator) {
        if (doneThisRun >= limTotal) {
          onAddLog(`🏁 [${c.name}] limit ${limLabel} poori — ruk gaya.`, 'info', 'download');
          break;
        }
        // 1) Pehle CACHE use karo — dobara scrape nahi
        let entries: ScrapeEntry[] = cache.filter((e) => !processed.has(e.id));
        if (!entries.length) {
          // 2) Cache khaali/khatam — pehli baar? ya dobara scrape?
          const neverScraped = !cacheStamp && cache.length === 0;
          if (!neverScraped && !autoRe) {
            onAddLog(`🏁 [${c.name}] links khatm aur auto-rescrape OFF hai — ruk gaya.`, 'info', 'download');
            break;
          }
          try {
            onAddLog(
              neverScraped
                ? `🔍 [${c.name}] pehli scrape — saari links ek dafa save ho rahi hain...`
                : `🔄 [${c.name}] links khatm — dobara scrape ho rahi hai...`,
              'info',
              'download'
            );
            const fresh = await scrapeCreator(c);
            const seen = new Set(cache.map((e) => e.id));
            const newOnes = fresh.filter((e) => !seen.has(e.id));
            if (newOnes.length) {
              cache = [...cache, ...newOnes];
              onAddLog(`📋 [${c.name}] ${newOnes.length} nayi links cache mein (total ${cache.length})`, 'info', 'download');
            } else if (neverScraped) {
              cache = [...fresh];
            }
            cacheStamp = new Date().toISOString();
            persistLinkCache(c.id, cache, processed, cacheStamp);
            entries = cache.filter((e) => !processed.has(e.id));
          } catch (e: any) {
            onAddLog(`❌ [${c.name}] scrape failed: ${e.message || e}`, 'error', 'download');
            break;
          }
        }
        if (!entries.length) {
          emptyRounds += 1;
          if (emptyRounds >= 10) {
            onAddLog(`⏹ [${c.name}] 10 baar koi nayi video nahi mili — rok diya.`, 'warn', 'download');
            break;
          }
          onAddLog(
            `🔄 [${c.name}] koi nayi link nahi — 60s baad dobara try... (STOP se roko)`,
            'info',
            'download'
          );
          await sleepMs(60000);
          continue;
        }
        emptyRounds = 0;
        let consecFails = 0;
        const take = entries.slice(0, limTotal - doneThisRun);
        onAddLog(`🎯 [${c.name}] limit ${limLabel} — ${take.length} video(s) download+upload (run: ${doneThisRun}/${limLabel})`, 'info', 'download');
        for (const entry of take) {
          if (!farmingActiveRef.current || stopCreator) break;
          doneThisRun += 1; // har attempt limit mein gina jayega (kamyaab ya nakam)
          try {
            onAddLog(`📥 [${c.name}] downloading: ${entry.title.slice(0, 60)}...`, 'info', 'download');
            const fp = await downloadEntry(c, entry);
            processed.add(entry.id);
            persistLinkCache(c.id, cache, processed, cacheStamp);
            setCreators((prev) =>
              prev.map((p) =>
                p.id === c.id
                  ? {
                      ...p,
                      done: p.done + 1,
                      savedVideos: [
                        ...(p.savedVideos || []),
                        {
                          id: `vid-${Date.now()}-${p.done}`,
                          filename: baseName(fp),
                          title: entry.title,
                          url: entry.url,
                          filePath: fp,
                          createdAt: new Date().toLocaleTimeString(),
                          status: 'Saved in Folder',
                        } as SavedVideo,
                      ],
                    }
                  : p
              )
            );
            onAddLog(`✅ [${c.name}] downloaded: ${baseName(fp)}`, 'success', 'download');
            consecFails = 0;
            // sath sath upload — ORIGINAL TITLE ke saath
            const upN = await uploadToMappedPages(c, fp, entry.title);
            const mappedN = mappedPagesFor(c.name).length;
            if (mappedN === 0) {
              onAddLog(`ℹ️ [${c.name}] koi mapped page nahi — sirf download hua`, 'info', 'upload');
              consecUploadFails = 0;
            } else if (upN > 0) {
              consecUploadFails = 0;
              if (autoDel) {
                // upload kamyab → local file auto delete (jagah bache)
                try {
                  await deleteFiles({ path: fp });
                  onAddLog(`🗑 [${c.name}] local file auto-delete: ${baseName(fp)}`, 'info', 'download');
                } catch {}
              }
            } else {
              // page mapped hai lekin upload fail — token kharab ho sakta hai
              consecUploadFails += 1;
              if (consecUploadFails >= 3) {
                onAddLog(
                  `⏹ [${c.name}] lagatar 3 uploads fail — page token check karo (Page Connect mein Verify dabao). Download hui videos mehfooz hain, zaya nahi hongi.`,
                  'error',
                  'upload'
                );
                stopCreator = true;
                break;
              }
            }
          } catch (e: any) {
            onAddLog(`❌ [${c.name}] "${entry.title.slice(0, 40)}": ${e.message || e}`, 'error', 'download');
            // fail hone wali video ko dobara retry NA karo (infinite loop rokne ke liye)
            processed.add(entry.id);
            persistLinkCache(c.id, cache, processed, cacheStamp);
            consecFails += 1;
            if (consecFails >= 5) {
              onAddLog(
                `⏹ [${c.name}] lagatar 5 downloads fail — kuch garbar hai (backend/network check karo). Ruk gaya.`,
                'error',
                'download'
              );
              break;
            }
          }
        }
        setCreators((prev) => prev.map((p) => (p.id === c.id ? { ...p, queue: 0 } : p)));
        if (!autoRe) break;
      }
    }
    farmingActiveRef.current = false;
    setIsFarmingActive(false);
    onAddLog('🏁 Farming complete', 'success', 'download');
  };

  // DOWNLOAD: sirf downloading (upload nahi)
  const handleDownload = async () => {
    if (creators.length === 0) {
      onAddLog('⚠️ No creators to download. Add a creator first.', 'warn', 'download');
      return;
    }
    // Double-click guard
    if (farmingActiveRef.current) {
      onAddLog('⚠️ Download pehle se chal raha hai.', 'warn', 'download');
      return;
    }
    const targets = creators.some((c) => c.selected)
      ? creators.filter((c) => c.selected)
      : creators;
    farmingActiveRef.current = true;
    setIsFarmingActive(true);
    onAddLog('📥 DOWNLOAD ONLY — sirf downloading hogi, upload nahi', 'info', 'download');

    try {
    for (const c of targets) {
      if (!farmingActiveRef.current) break;
      // Persistent cache — pehle saved links, khatam hon to hi fresh scrape
      let cache: ScrapeEntry[] = [...(c.scrapedEntries || [])];
      let cacheStamp: string | undefined = c.scrapedAt;
      const processed = new Set<string>(c.farmedIds || []);
      let entries: ScrapeEntry[] = cache.filter((e) => !processed.has(e.id));
      if (!entries.length) {
        try {
          if (!cacheStamp) onAddLog(`🔍 [${c.name}] pehli scrape — saari links ek dafa save ho rahi hain...`, 'info', 'download');
          const fresh = await scrapeCreator(c);
          const seen = new Set(cache.map((e) => e.id));
          const newOnes = fresh.filter((e) => !seen.has(e.id));
          if (newOnes.length) cache = [...cache, ...newOnes];
          else if (!cacheStamp) cache = [...fresh];
          cacheStamp = new Date().toISOString();
          persistLinkCache(c.id, cache, processed, cacheStamp);
          entries = cache.filter((e) => !processed.has(e.id));
        } catch (e: any) {
          onAddLog(`❌ [${c.name}] scrape failed: ${e.message || e}`, 'error', 'download');
          continue;
        }
      } else {
        onAddLog(`♻️ [${c.name}] cache se ${entries.length} links (dobara scrape nahi)`, 'info', 'download');
      }
      const lim = effLimit(c);
      const take = entries.slice(0, lim);
      for (const entry of take) {
        if (!farmingActiveRef.current) break;
        try {
          onAddLog(`📥 [${c.name}] downloading: ${entry.title.slice(0, 60)}...`, 'info', 'download');
          const fp = await downloadEntry(c, entry);
          processed.add(entry.id);
          persistLinkCache(c.id, cache, processed, cacheStamp);
          setCreators((prev) =>
            prev.map((p) =>
              p.id === c.id
                ? {
                    ...p,
                    done: p.done + 1,
                    savedVideos: [
                      ...(p.savedVideos || []),
                      {
                        id: `vid-${Date.now()}-${p.done}`,
                        filename: baseName(fp),
                        title: entry.title,
                        url: entry.url,
                        filePath: fp,
                        createdAt: new Date().toLocaleTimeString(),
                        status: 'Saved in Folder',
                      } as SavedVideo,
                    ],
                  }
                : p
            )
          );
          onAddLog(`✅ [${c.name}] downloaded: ${baseName(fp)}`, 'success', 'download');
        } catch (e: any) {
          onAddLog(`❌ [${c.name}] "${entry.title.slice(0, 40)}": ${e.message || e}`, 'error', 'download');
        }
      }
      setCreators((prev) => prev.map((p) => (p.id === c.id ? { ...p, queue: 0 } : p)));
    }
    } finally {
      farmingActiveRef.current = false;
      setIsFarmingActive(false);
    }
    onAddLog('🏁 Download complete', 'success', 'download');
  };

  const handleStopAll = async () => {
    farmingActiveRef.current = false;
    setIsFarmingActive(false);
    const ids = [...activeJobs.current];
    activeJobs.current = [];
    for (const id of ids) {
      try {
        await stopJob(id);
      } catch {}
    }
    setCreators((prev) => prev.map((p) => ({ ...p, queue: 0 })));
    onAddLog('🛑 STOP: all active downloads stopped.', 'warn', 'download');
  };

  const handleAddCreatorSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCreatorProfileUrl.trim()) return;

    let handle = newCreatorName.trim().replace(/^@/, '');
    if (!handle) {
      // derive from URL
      const parts = newCreatorProfileUrl.split('/').filter(Boolean);
      handle = parts[parts.length - 1]?.replace(/^@/, '') || `creator_${Date.now().toString().slice(-4)}`;
    }

    const cleanUrl = newCreatorProfileUrl.trim().startsWith('http')
      ? newCreatorProfileUrl.trim()
      : `https://${newCreatorProfileUrl.trim()}`;

    const folderName = handle;
    const folderPath = `/creators/${handle}/videos/`;

    // Naya creator khaali folder ke saath — koi fake videos nahi.
    // Asal videos START FARMING / DOWNLOAD se aayengi (yt-dlp scrape + download).
    const newCreator: CreatorMapping = {
      id: `creator-${Date.now()}`,
      name: handle,
      profileUrl: cleanUrl,
      platform: newCreatorPlatform,
      capsPage: false,
      limit: newCreatorLimit,
      queue: 0,
      done: 0,
      metaAi: false,
      monetized: false,
      selected: false,
      profileId: `usr_${Date.now().toString().slice(-5)}`,
      links: [],
      folderName,
      folderPath,
      savedVideos: [],
    };

    setCreators((prev) => [...prev, newCreator]);
    onAddLog(`➕ New creator added: @${newCreator.name} (${cleanUrl})`, 'success', 'download');
    onAddLog(
      `📁 Dedicated folder created: ${folderPath} (0 videos — START FARMING se asal videos aayengi)`,
      'info',
      'system'
    );
    setNewCreatorProfileUrl('');
    setNewCreatorName('');
    setShowAddCreatorModal(false);
  };

  // Filter creators
  const filteredCreators = creators.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.platform.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (c.profileUrl && c.profileUrl.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesPlatform =
      platformFilter === 'All Platforms' || c.platform === platformFilter;
    return matchesSearch && matchesPlatform;
  });

  return (
    <div className="flex-1 flex flex-col bg-[#0b0e14] overflow-hidden text-slate-200">
      {/* TOP ACTION BAR */}
      <div className="px-5 py-3 border-b border-[#182030] flex flex-wrap items-center justify-between gap-3 bg-[#0d111a]">
        <div className="flex flex-wrap items-center gap-2.5">
          {/* START AUTOMATION BUTTON (Green) */}
          <button
            onClick={handleStartFarming}
            disabled={isFarmingActive}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider text-black bg-[#10b981] hover:bg-[#059669] active:scale-98 transition shadow-[0_0_12px_rgba(16,185,129,0.35)] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed ${
              isFarmingActive ? 'ring-2 ring-emerald-300 animate-pulse' : ''
            }`}
          >
            <Zap className="w-3.5 h-3.5 fill-black stroke-black" />
            <span>START AUTOMATION</span>
          </button>

          {/* DOWNLOAD BUTTON (Indigo) */}
          <button
            onClick={handleDownload}
            disabled={isFarmingActive}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider text-white bg-[#6366f1] hover:bg-[#4f46e5] active:scale-98 transition shadow-[0_0_12px_rgba(99,102,241,0.3)] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Download className="w-3.5 h-3.5" />
            <span>DOWNLOAD</span>
          </button>

          {/* STOP ALL BUTTON (Red) */}
          <button
            onClick={handleStopAll}
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider text-white bg-[#ef4444] hover:bg-[#dc2626] active:scale-98 transition shadow-[0_0_12px_rgba(239,68,68,0.3)] cursor-pointer"
          >
            <div className="w-3.5 h-3.5 rounded-full border-2 border-white flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
            </div>
            <span>STOP ALL</span>
          </button>

          {/* BROWSE FOLDER — creators ke folders yahan banein ge */}
          <button
            onClick={openFolderPicker}
            title="Wo folder choose karo jahan har creator ka apne naam ka folder banega"
            className="flex items-center gap-2 px-4 py-2 rounded-lg font-bold text-xs uppercase tracking-wider text-white bg-[#0ea5e9] hover:bg-[#0284c7] active:scale-98 transition shadow-[0_0_12px_rgba(14,165,233,0.3)] cursor-pointer"
          >
            <FolderOpen className="w-3.5 h-3.5" />
            <span>Browse Folder</span>
          </button>

          {/* BACKEND STATUS — smart: green/yellow/red + wajah */}
          <div
            title={backendDetail || 'Backend check ho raha hai...'}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-[11px] font-bold border ${
              backendState === 'off'
                ? 'bg-red-950/60 border-red-500 text-red-300 animate-pulse'
                : backendState === 'proxy-issue'
                  ? 'bg-amber-950/60 border-amber-500 text-amber-300 animate-pulse'
                  : backendState === 'on'
                    ? 'bg-emerald-950/40 border-emerald-700 text-emerald-300'
                    : 'bg-[#141a26] border-[#222c3f] text-slate-500'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${backendState === 'off' ? 'bg-red-500' : backendState === 'proxy-issue' ? 'bg-amber-400' : backendState === 'on' ? 'bg-emerald-400' : 'bg-slate-500'}`} />
            <span>{backendState === 'off' ? 'Backend OFF' : backendState === 'proxy-issue' ? 'Proxy Issue' : backendState === 'on' ? 'Backend ON' : '...'}</span>
          </div>

          {/* Sort Select */}
          <div className="flex items-center gap-1.5 bg-[#141a26] border border-[#232c40] rounded-lg px-2.5 py-1.5 text-xs text-slate-300">
            <span className="text-slate-400">Sort:</span>
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value)}
              className="bg-transparent text-white font-medium focus:outline-none cursor-pointer pr-1"
            >
              <option value="Newest" className="bg-[#141a26] text-white">Newest</option>
              <option value="Oldest" className="bg-[#141a26] text-white">Oldest</option>
              <option value="Queue High" className="bg-[#141a26] text-white">Queue High</option>
            </select>
          </div>

          {/* Limit input */}
          <div className="flex items-center gap-1.5 bg-[#141a26] border border-[#232c40] rounded-lg px-2.5 py-1.5 text-xs text-slate-300">
            <span className="text-slate-400">Limit:</span>
            <input
              type="number"
              min="1"
              max="100"
              value={limitCount}
              onChange={(e) => setLimitCount(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-8 bg-transparent text-white font-semibold text-center focus:outline-none"
            />
          </div>
        </div>

        {/* TOP PRIVACY MODE BUTTON */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const next = !privacyMode;
              setPrivacyMode(next);
              onAddLog(
                `Privacy Mode ${next ? 'ACTIVATED (Tokens & Names Blurred)' : 'DEACTIVATED'}`,
                next ? 'warn' : 'info',
                'system'
              );
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-bold transition cursor-pointer shadow-sm ${
              privacyMode
                ? 'bg-amber-950/80 border-amber-500 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                : 'bg-[#141a26] border-[#222c3f] text-slate-300 hover:text-white hover:border-slate-500'
            }`}
          >
            {privacyMode ? (
              <EyeOff className="w-4 h-4 text-amber-400" />
            ) : (
              <Eye className="w-4 h-4 text-slate-400" />
            )}
            <span>Privacy Mode: {privacyMode ? 'ON' : 'OFF'}</span>
          </button>
        </div>
      </div>

      {/* SUB-HEADER / FILTER BAR */}
      <div className="px-5 py-2.5 border-b border-[#141a26] flex flex-wrap items-center justify-between gap-3 bg-[#0a0d14]">
        <div className="flex flex-wrap items-center gap-3 flex-1">
          {/* Search Input */}
          <div className="relative min-w-[240px] max-w-sm flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search creators by handle or link..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#121622] border border-[#20293d] rounded-lg pl-8.5 pr-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500"
            />
          </div>

          {/* All Platforms Dropdown with Cyan Dot */}
          <div className="relative">
            <select
              value={platformFilter}
              onChange={(e) => setPlatformFilter(e.target.value)}
              className="appearance-none bg-[#121622] border border-[#20293d] rounded-lg pl-6 pr-7 py-1.5 text-xs text-slate-300 font-medium focus:outline-none cursor-pointer"
            >
              <option value="All Platforms" className="bg-[#121622]">All Platforms</option>
              <option value="TikTok" className="bg-[#121622]">TikTok</option>
              <option value="Instagram" className="bg-[#121622]">Instagram</option>
              <option value="YouTube" className="bg-[#121622]">YouTube Shorts</option>
              <option value="Facebook" className="bg-[#121622]">Facebook Reels</option>
            </select>
            <div className="w-2 h-2 rounded-full bg-cyan-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none"></div>
            <ChevronDown className="w-3.5 h-3.5 absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
          </div>

          {/* Add Creator Button */}
          <button
            onClick={() => setShowAddCreatorModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-500/50 bg-emerald-950/40 text-emerald-300 text-xs font-semibold hover:bg-emerald-900/60 transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
            <span>Add Creator</span>
          </button>

          {/* All Creator Folders Manager Button */}
          {creators.length > 0 && (
            <button
              onClick={() => setShowAllFoldersModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-500/50 bg-amber-950/40 text-amber-300 text-xs font-semibold hover:bg-amber-900/60 transition cursor-pointer"
              title="View all isolated creator folders and saved videos"
            >
              <Folder className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
              <span>Creator Folders ({creators.length})</span>
            </button>
          )}
        </div>

        {/* Right Pagination */}
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <button
            disabled
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#121622] border border-[#20293d] text-slate-400 hover:text-white cursor-pointer disabled:opacity-40"
          >
            <ChevronLeft className="w-3 h-3" />
            <span>Prev</span>
          </button>
          <span className="font-medium text-slate-300 px-1">
            Page 1/1 ({filteredCreators.length})
          </span>
          <button
            disabled
            className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#121622] border border-[#20293d] text-slate-400 hover:text-white cursor-pointer disabled:opacity-40"
          >
            <span>Next</span>
            <ChevronRight className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* TABLE VIEW / EMPTY STATE */}
      <div className="flex-1 overflow-auto">
        {creators.length === 0 ? (
          /* EMPTY STATE - WHEN NO ACCOUNT IS ADDED (NO LOAD SAMPLE BUTTON) */
          <div className="h-full flex flex-col items-center justify-center p-8 text-center space-y-4">
            <div className="p-4 rounded-2xl bg-[#0f1422] border border-[#1e273b] shadow-xl">
              <FbHelperLogo size="lg" showSubtitle={false} />
            </div>

            <div className="max-w-md space-y-1.5">
              <h3 className="font-bold text-base text-white">
                No Creator Profiles Added Yet
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Add a creator profile link (TikTok, Instagram, or YouTube) to start automated scraping and page mapping.
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setShowAddCreatorModal(true)}
                className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.3)]"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Add Target Creator</span>
              </button>
            </div>
          </div>
        ) : (
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-[#182030] bg-[#0c1018] text-[11px] font-bold text-slate-400 tracking-wider">
                {/* CREATOR / PROFILE MAPPING */}
                <th className="py-3 px-4 w-[320px]">
                  <div className="flex items-center gap-3">
                    <input
                      type="checkbox"
                      checked={allSelected}
                      onChange={toggleSelectAll}
                      className="w-3.5 h-3.5 rounded bg-[#151c2a] border-[#253046] accent-indigo-600 cursor-pointer"
                    />
                    <span>CREATOR / PROFILE MAPPING</span>
                  </div>
                </th>

                {/* CAPS */}
                <th className="py-3 px-3 text-center w-[120px]">CAPS</th>

                {/* PLATFORM */}
                <th className="py-3 px-3 text-center w-[130px]">PLATFORM</th>

                {/* LIMIT */}
                <th className="py-3 px-3 text-center w-[100px]">LIMIT</th>

                {/* QUEUE */}
                <th className="py-3 px-3 text-center w-[90px]">QUEUE</th>

                {/* DONE */}
                <th className="py-3 px-3 text-center w-[80px]">DONE</th>

                {/* ACTIONS */}
                <th className="py-3 px-4 text-right w-[160px]">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#131924]">
              {filteredCreators.map((creator) => (
                <tr
                  key={creator.id}
                  className="hover:bg-[#111724]/70 transition-colors group"
                >
                  {/* Creator name & Profile URL (Blurred in Privacy Mode) */}
                  <td className="py-3.5 px-4 font-medium text-slate-200">
                    <div className="flex items-center gap-3">
                      <input
                        type="checkbox"
                        checked={creator.selected}
                        onChange={() => toggleSelectCreator(creator.id)}
                        className="w-3.5 h-3.5 rounded bg-[#151c2a] border-[#253046] accent-indigo-600 cursor-pointer"
                      />
                      <div className="flex flex-col">
                        <span
                          className={`font-semibold text-slate-100 hover:text-indigo-400 transition cursor-pointer text-xs ${
                            privacyMode ? 'filter blur-[5px] select-none' : ''
                          }`}
                        >
                          {creator.name}
                        </span>
                        <div
                          onClick={() => setSelectedFolderCreator(creator)}
                          className={`text-[10px] text-amber-400 hover:text-amber-300 hover:underline font-mono-code flex items-center gap-1 mt-0.5 cursor-pointer ${
                            privacyMode ? 'filter blur-[4px] select-none' : ''
                          }`}
                          title="Click to open this creator's dedicated folder"
                        >
                          <span className="text-amber-500">📁</span>
                          <span>/{creator.name}/videos/</span>
                          <span className="text-emerald-400 font-semibold text-[9px] bg-emerald-950/80 px-1 rounded border border-emerald-800">
                            {creator.savedVideos?.length || creatorDisplayLinks(creator).length} vids
                          </span>
                        </div>
                        {creator.profileUrl && (
                          <a
                            href={creator.profileUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={`text-[11px] text-cyan-400 hover:text-cyan-300 hover:underline flex items-center gap-1 font-mono-code truncate max-w-[220px] mt-0.5 ${
                              privacyMode ? 'filter blur-[5px] select-none' : ''
                            }`}
                            title={creator.profileUrl}
                          >
                            <ExternalLink className="w-2.5 h-2.5 shrink-0" />
                            <span className="truncate">{creator.profileUrl}</span>
                          </a>
                        )}
                      </div>
                    </div>
                  </td>

                  {/* CAPS (+ Page and checkbox) */}
                  <td className="py-3.5 px-3 text-center">
                    <div className="inline-flex items-center gap-2 justify-center">
                      <button
                        onClick={() => {
                          if (onNavigateToMapping) {
                            onNavigateToMapping();
                          } else {
                            toggleCapsPage(creator.id);
                          }
                        }}
                        className="px-2 py-0.5 rounded text-[11px] font-medium bg-[#141a26] border border-[#242f44] text-slate-300 hover:text-white hover:border-slate-500 transition cursor-pointer"
                      >
                        + Page
                      </button>
                      <input
                        type="checkbox"
                        checked={creator.capsPage}
                        onChange={() => toggleCapsPage(creator.id)}
                        className="w-3.5 h-3.5 rounded bg-[#151c2a] border-[#253046] accent-indigo-600 cursor-pointer"
                      />
                    </div>
                  </td>

                  {/* PLATFORM BADGE */}
                  <td className="py-3.5 px-3 text-center">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-[#0c242c] border border-[#06b6d4]/70 text-[#22d3ee]">
                      <svg viewBox="0 0 24 24" className="w-3.5 h-3.5 fill-current">
                        <path d="M19.589 6.686a4.793 4.793 0 0 1-3.77-4.245V2h-3.445v13.672a2.896 2.896 0 0 1-2.887 2.887 2.896 2.896 0 0 1-2.887-2.887 2.896 2.896 0 0 1 2.887-2.887c.307 0 .6.048.874.137V9.45a6.335 6.335 0 0 0-.874-.06 6.34 6.34 0 0 0-6.332 6.332 6.34 6.34 0 0 0 6.332 6.332 6.34 6.34 0 0 0 6.332-6.332V8.46a8.214 8.214 0 0 0 4.673 1.442V6.686h-.906z" />
                      </svg>
                      <span>{creator.platform}</span>
                    </div>
                  </td>

                  {/* LIMIT SELECT */}
                  <td className="py-3.5 px-3 text-center">
                    <div className="inline-flex items-center gap-1 bg-[#141a26] border border-[#20293d] rounded-md px-2 py-0.5">
                      <select
                        value={creator.limit}
                        onChange={(e) => {
                          const val = e.target.value;
                          setCreators((prev) =>
                            prev.map((c) =>
                              c.id === creator.id ? { ...c, limit: val } : c
                            )
                          );
                        }}
                        className="bg-transparent text-slate-200 focus:outline-none cursor-pointer"
                      >
                        <option value="All" className="bg-[#141a26]">All</option>
                        <option value="5" className="bg-[#141a26]">5</option>
                        <option value="10" className="bg-[#141a26]">10</option>
                        <option value="25" className="bg-[#141a26]">25</option>
                      </select>
                    </div>
                  </td>

                  {/* QUEUE */}
                  <td className="py-3.5 px-3 text-center font-semibold text-slate-300">
                    <span className={privacyMode ? 'filter blur-[4px]' : ''}>
                      {creator.queue}
                    </span>
                  </td>

                  {/* DONE */}
                  <td className="py-3.5 px-3 text-center">
                    <div className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-[#0d281e] border border-[#10b981]/50 text-emerald-400 font-bold text-xs">
                      {creator.done}
                    </div>
                  </td>

                  {/* ACTIONS: Folder Button + Links Button + Delete Button */}
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5 flex-wrap">
                      {/* Open Dedicated Folder Button */}
                      <button
                        onClick={() => setSelectedFolderCreator(creator)}
                        className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#20180d] border border-[#543815] text-amber-300 hover:bg-amber-900/50 hover:text-white transition text-[11px] font-semibold cursor-pointer shadow-sm"
                        title="Open this creator's dedicated folder to view and play saved videos"
                      >
                        <Folder className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
                        <span>Folder ({creator.savedVideos?.length || creatorDisplayLinks(creator).length})</span>
                      </button>

                      <button
                        onClick={() => setActiveLinksModal(creator)}
                        className="px-2.5 py-1 rounded bg-[#141a26] border border-[#253046] text-slate-300 hover:text-white hover:border-slate-500 transition text-[11px] font-medium cursor-pointer"
                      >
                        Links
                      </button>

                      {/* Delete Button */}
                      <button
                        onClick={() => handleDeleteCreator(creator.id, creator.name)}
                        className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#2a1318] border border-[#5a1c27] text-rose-400 hover:bg-rose-900/60 hover:text-rose-100 transition text-[11px] font-semibold cursor-pointer"
                        title="Delete creator from queue"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>Delete</span>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* LINKS VIEWER MODAL */}
      {activeLinksModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0f1422] border border-[#243048] rounded-xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1c263c] pb-3">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <span className={privacyMode ? 'filter blur-[5px]' : ''}>
                    Video Links: {activeLinksModal.name}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-700">
                    {activeLinksModal.platform}
                  </span>
                </h3>
                <p className="text-xs text-slate-400">
                  {creatorDisplayLinks(activeLinksModal).length} extracted video URLs
                </p>
              </div>
              <button
                onClick={() => setActiveLinksModal(null)}
                className="text-slate-400 hover:text-white p-1 rounded hover:bg-[#1a2234]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* REAL DOWNLOAD ACTION BUTTONS */}
            <div className="flex flex-wrap items-center gap-2 p-2.5 rounded-lg bg-[#0a0f1b] border border-[#1b253b]">
              <span className="text-[11px] font-bold text-slate-400">Download Real Files:</span>
              <button
                type="button"
                onClick={() => {
                  downloadTextFile(
                    `${activeLinksModal.name}_reels_urls.txt`,
                    creatorDisplayLinks(activeLinksModal).join('\r\n')
                  );
                  onAddLog(`📥 Downloaded ${activeLinksModal.name}_reels_urls.txt directly to your computer!`, 'success', 'download');
                }}
                className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#18233a] border border-[#2b3a5a] text-cyan-300 hover:text-white hover:bg-cyan-900/50 text-[11px] font-semibold transition cursor-pointer"
              >
                <FileDown className="w-3.5 h-3.5 text-cyan-400" />
                <span>Download .TXT</span>
              </button>

              <button
                type="button"
                onClick={async () => {
                  onAddLog(`📦 Compiling real ZIP for ${activeLinksModal.name}...`, 'info', 'download');
                  await generateCreatorBatchZip([activeLinksModal]);
                  onAddLog(`✅ Downloaded ${activeLinksModal.name}_package.zip with downloader scripts!`, 'success', 'download');
                }}
                className="flex items-center gap-1.5 px-3 py-1 rounded bg-indigo-900/60 border border-indigo-600/60 text-indigo-200 hover:bg-indigo-800 text-[11px] font-semibold transition cursor-pointer"
              >
                <FolderDown className="w-3.5 h-3.5 text-indigo-400" />
                <span>Download .ZIP</span>
              </button>
            </div>

            <div className="max-h-60 overflow-y-auto space-y-2 text-xs font-mono-code">
              {creatorDisplayLinks(activeLinksModal).map((link, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2 rounded bg-[#090d16] border border-[#1b2438] text-slate-300"
                >
                  <span
                    className={`truncate max-w-[280px] text-cyan-300 ${
                      privacyMode ? 'filter blur-[5px] select-none' : ''
                    }`}
                  >
                    {link}
                  </span>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => {
                        downloadTextFile(
                          `${activeLinksModal.name}_reel_${idx + 1}.txt`,
                          link
                        );
                        onAddLog(`📥 Downloaded link file: ${activeLinksModal.name}_reel_${idx + 1}.txt`, 'success', 'download');
                      }}
                      className="p-1 text-slate-400 hover:text-cyan-300 hover:bg-[#151d2e] rounded transition"
                      title="Download this link as file"
                    >
                      <Download className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(link);
                        setCopyFeedback(`link-${idx}`);
                        setTimeout(() => setCopyFeedback(null), 1500);
                      }}
                      className="p-1 text-slate-400 hover:text-white hover:bg-[#151d2e] rounded transition"
                      title="Copy URL"
                    >
                      {copyFeedback === `link-${idx}` ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-[#1c263c]">
              <button
                onClick={() => {
                  const allUrls = activeLinksModal.links.join('\n');
                  navigator.clipboard.writeText(allUrls);
                  setCopyFeedback('all');
                  setTimeout(() => setCopyFeedback(null), 1500);
                }}
                className="text-xs text-indigo-400 hover:text-indigo-300 font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                {copyFeedback === 'all' ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Copied all URLs!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy All URLs</span>
                  </>
                )}
              </button>

              <button
                onClick={() => setActiveLinksModal(null)}
                className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ADD CREATOR MODAL WITH MANDATORY PROFILE LINK */}
      {showAddCreatorModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleAddCreatorSubmit}
            className="bg-[#0f1422] border border-[#243048] rounded-xl max-w-md w-full p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-[#1c263c] pb-3">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-400" />
                <span>Add Creator via Profile Link</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddCreatorModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded hover:bg-[#1a2234]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {/* PRIMARY REQUIRED FIELD: CREATOR PROFILE LINK */}
              <div>
                <label className="block text-slate-300 mb-1 font-semibold flex items-center gap-1.5">
                  <Link2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Creator Profile Link / URL (Required)</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="https://www.tiktok.com/@username or https://instagram.com/username"
                  value={newCreatorProfileUrl}
                  onChange={(e) => handleProfileUrlChange(e.target.value)}
                  className="w-full bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white font-mono-code placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 text-xs"
                />
                <p className="text-[10px] text-slate-500 mt-1">
                  Paste the profile URL to auto-extract the username and target platform.
                </p>
              </div>

              {/* USERNAME (AUTO-EXTRACTED OR EDITABLE) */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Creator Handle / Username
                </label>
                <input
                  type="text"
                  placeholder="e.g. charlidamelio or luh.naty"
                  value={newCreatorName}
                  onChange={(e) => setNewCreatorName(e.target.value)}
                  className="w-full bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
                />
              </div>

              {/* PLATFORM SELECT */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Source Platform
                </label>
                <select
                  value={newCreatorPlatform}
                  onChange={(e) => setNewCreatorPlatform(e.target.value as Platform)}
                  className="w-full bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="TikTok">TikTok</option>
                  <option value="Instagram">Instagram Reels</option>
                  <option value="YouTube">YouTube Shorts</option>
                  <option value="Facebook">Facebook Reels</option>
                </select>
              </div>

              {/* BATCH LIMIT */}
              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Scrape Batch Limit
                </label>
                <select
                  value={newCreatorLimit}
                  onChange={(e) => setNewCreatorLimit(e.target.value)}
                  className="w-full bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="All">All available reels</option>
                  <option value="5">Latest 5 reels</option>
                  <option value="10">Latest 10 reels</option>
                  <option value="25">Latest 25 reels</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1c263c]">
              <button
                type="button"
                onClick={() => setShowAddCreatorModal(false)}
                className="px-3.5 py-1.5 rounded-lg border border-[#232c40] text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs cursor-pointer"
              >
                Add Creator
              </button>
            </div>
          </form>
        </div>
      )}

      {/* INDIVIDUAL CREATOR FOLDER EXPLORER MODAL */}
      {selectedFolderCreator && (
        <CreatorFolderModal
          creator={selectedFolderCreator}
          onClose={() => setSelectedFolderCreator(null)}
          onUpdateCreator={(updated) => {
            setCreators((prev) =>
              prev.map((c) => (c.id === updated.id ? updated : c))
            );
            setSelectedFolderCreator(updated);
          }}
          onAddLog={onAddLog}
          privacyMode={privacyMode}
          accounts={accounts}
        />
      )}

      {/* ALL CREATOR FOLDERS BROWSER MODAL */}
      {showAllFoldersModal && (
        <AllFoldersModal
          creators={creators}
          onClose={() => setShowAllFoldersModal(false)}
          onOpenCreatorFolder={(c) => {
            setSelectedFolderCreator(c);
          }}
          onAddLog={onAddLog}
          privacyMode={privacyMode}
        />
      )}

      {/* DOWNLOAD FOLDER PICKER — yahan creators ke folders banein ge */}
      {showFolderPicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-md bg-[#0f1422] border border-[#20293d] rounded-xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1a2336] pb-2.5">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <FolderOpen className="w-4 h-4 text-sky-400" />
                <span>Download Folder</span>
              </h3>
              <button
                onClick={() => setShowFolderPicker(false)}
                className="text-slate-400 hover:text-white text-lg leading-none cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-[11px] text-slate-400">
              Wo folder choose karo jahan <b className="text-slate-200">har creator ka apne naam ka folder</b> banega.
            </p>

            <div className="p-2.5 rounded-lg bg-[#080c14] border border-[#1b253b]">
              <div className="text-[10px] text-slate-500 mb-1">Current:</div>
              <div className="text-[11px] text-slate-200 font-mono break-all">{dlDir || '...'}</div>
            </div>

            {dlDirSuggestions.length > 0 && (
              <div>
                <div className="text-[10px] text-slate-500 mb-1.5">Quick pick:</div>
                <div className="flex flex-wrap gap-1.5">
                  {dlDirSuggestions.map((s) => (
                    <button
                      key={s.p}
                      onClick={() => setDlDirInput(s.p)}
                      className="px-2.5 py-1.5 rounded-lg bg-[#141a26] border border-[#222c3f] text-slate-300 hover:text-white hover:border-sky-500 text-[11px] transition cursor-pointer"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <input
              value={dlDirInput}
              onChange={(e) => setDlDirInput(e.target.value)}
              placeholder="D:\Videos\FBHelper"
              className="w-full bg-[#080c14] border border-[#1b253b] rounded-lg px-3 py-2.5 text-white text-xs font-mono focus:outline-none focus:border-sky-500"
            />

            <button
              onClick={handleSaveDlDir}
              disabled={dlDirSaving}
              className="w-full py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer"
            >
              {dlDirSaving ? 'Setting...' : '📁 Set This Folder'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
