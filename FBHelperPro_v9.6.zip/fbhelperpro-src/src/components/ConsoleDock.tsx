import React, { useState, useEffect, useRef } from 'react';
import {
  Download,
  CloudUpload,
  Eye,
  EyeOff,
  Copy,
  Trash2,
  ChevronDown,
  ChevronUp,
  Check,
  ArrowDownToLine,
} from 'lucide-react';
import { LogItem } from '../types';

interface ConsoleDockProps {
  logs: LogItem[];
  activeLogTab: 'download' | 'upload';
  setActiveLogTab: (tab: 'download' | 'upload') => void;
  onClearLogs: () => void;
}

export const ConsoleDock: React.FC<ConsoleDockProps> = ({
  logs,
  activeLogTab,
  setActiveLogTab,
  onClearLogs,
}) => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isBlurred, setIsBlurred] = useState(false);
  const [copied, setCopied] = useState(false);
  // auto-scroll: naye logs aayen to neeche scroll; user upar scroll kare to ruk jaye
  const [autoScroll, setAutoScroll] = useState(true);
  const logBoxRef = useRef<HTMLDivElement | null>(null);

  const handleLogScroll = () => {
    const el = logBoxRef.current;
    if (!el) return;
    // neeche se 24px ke andar = neeche hi samjho
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 24;
    setAutoScroll(atBottom);
  };

  const filteredLogs = logs.filter((log) => {
    if (activeLogTab === 'download') {
      return log.category === 'download' || log.category === 'system';
    } else {
      return log.category === 'upload' || log.category === 'system';
    }
  });

  useEffect(() => {
    const el = logBoxRef.current;
    if (el && autoScroll && !isCollapsed) {
      el.scrollTop = el.scrollHeight;
    }
  }, [filteredLogs, autoScroll, isCollapsed]);

  const handleCopy = () => {
    const text = filteredLogs
      .map((l) => `[${l.timestamp}] ${l.message}`)
      .join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full bg-[#080b11] border-t border-[#1a2232] select-none flex flex-col shrink-0">
      {/* Console Top Control Bar */}
      <div className="px-4 py-2 flex items-center justify-between border-b border-[#141a26] text-xs">
        {/* Left Tabs */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveLogTab('download')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeLogTab === 'download'
                ? 'bg-[#1e1b4b] text-indigo-200 border border-[#4338ca]/80 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#121824]'
            }`}
          >
            <Download className="w-3.5 h-3.5 text-indigo-400" />
            <span>Download Logs</span>
          </button>

          <button
            onClick={() => setActiveLogTab('upload')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              activeLogTab === 'upload'
                ? 'bg-[#1e1b4b] text-indigo-200 border border-[#4338ca]/80 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#121824]'
            }`}
          >
            <CloudUpload className="w-3.5 h-3.5 text-indigo-400" />
            <span>Upload Logs</span>
          </button>
        </div>

        {/* Right Tools */}
        <div className="flex items-center gap-2 text-slate-400 text-xs">
          <button
            onClick={() => setIsBlurred(!isBlurred)}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md hover:bg-[#151c2a] hover:text-slate-200 transition-colors"
            title="Blur sensitive creator tags & IP addresses"
          >
            {isBlurred ? (
              <EyeOff className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <Eye className="w-3.5 h-3.5" />
            )}
            <span>Blur Logs</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md hover:bg-[#151c2a] hover:text-slate-200 transition-colors"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Copy className="w-3.5 h-3.5" />
            )}
            <span>{copied ? 'Copied' : 'Copy Logs'}</span>
          </button>

          <button
            onClick={() => setAutoScroll(!autoScroll)}
            title={autoScroll ? 'Auto-scroll band karo' : 'Auto-scroll chalu karo'}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-colors ${
              autoScroll
                ? 'bg-emerald-900/50 text-emerald-300 hover:bg-emerald-900/70'
                : 'hover:bg-[#151c2a] hover:text-slate-200'
            }`}
          >
            <ArrowDownToLine className="w-3.5 h-3.5" />
            <span>Auto-scroll {autoScroll ? 'ON' : 'OFF'}</span>
          </button>

          <button
            onClick={onClearLogs}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-md hover:bg-[#151c2a] hover:text-rose-300 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear</span>
          </button>

          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="flex items-center gap-1 px-2 py-1 rounded-md hover:bg-[#151c2a] hover:text-slate-200 transition-colors"
          >
            {isCollapsed ? (
              <>
                <ChevronUp className="w-3.5 h-3.5" />
                <span>Expand</span>
              </>
            ) : (
              <>
                <ChevronDown className="w-3.5 h-3.5" />
                <span>Collapse</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Console Log Output Terminal */}
      {!isCollapsed && (
        <div
          ref={logBoxRef}
          onScroll={handleLogScroll}
          className={`h-24 overflow-y-auto p-3 font-mono-code text-[11px] leading-relaxed transition-all ${
            isBlurred ? 'blur-xs select-none' : ''
          }`}
        >
          {filteredLogs.map((log) => {
            if (log.category === 'system') {
              return (
                <div
                  key={log.id}
                  className="flex items-center gap-2 text-cyan-400/90 py-0.5 tracking-wide"
                >
                  <span className="text-slate-500 font-bold">—</span>
                  <span className="font-medium">{log.message}</span>
                  <span className="text-slate-500 font-bold">—</span>
                </div>
              );
            }

            return (
              <div
                key={log.id}
                className="flex items-center gap-2 py-0.5 text-slate-300"
              >
                <span className="text-slate-500">[{log.timestamp}]</span>
                {log.level === 'error' ? (
                  <span className="text-rose-400 font-medium">{log.message}</span>
                ) : log.level === 'warn' ? (
                  <span className="text-amber-400 font-medium">{log.message}</span>
                ) : log.level === 'success' ? (
                  <span className="text-emerald-400 font-medium">
                    {log.message}
                  </span>
                ) : (
                  <span className="text-slate-200">{log.message}</span>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
