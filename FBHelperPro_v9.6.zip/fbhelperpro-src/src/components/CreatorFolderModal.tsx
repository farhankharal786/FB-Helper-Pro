import React, { useState } from 'react';
import {
  Folder,
  X,
  Download,
  Film,
  Play,
  Trash2,
  Plus,
  RefreshCw,
  ExternalLink,
  CheckCircle2,
  HardDrive,
  Share2,
  FileText,
} from 'lucide-react';
import { CreatorMapping, SavedVideo, BmAccount } from '../types';
import { scrapeLinks, downloadFileUrl, deleteFiles } from '../utils/api';
import {
  downloadSingleCreatorFolderZip,
  downloadTextFile,
  downloadDirectVideo,
} from '../utils/realDownloader';

interface CreatorFolderModalProps {
  creator: CreatorMapping;
  onClose: () => void;
  onUpdateCreator: (updated: CreatorMapping) => void;
  onAddLog: (
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error',
    category?: 'download' | 'upload' | 'system'
  ) => void;
  privacyMode: boolean;
  accounts?: BmAccount[];
}

export const CreatorFolderModal: React.FC<CreatorFolderModalProps> = ({
  creator,
  onClose,
  onUpdateCreator,
  onAddLog,
  privacyMode,
  accounts = [],
}) => {
  const [playingVideo, setPlayingVideo] = useState<SavedVideo | null>(null);
  const [showAddVideoInput, setShowAddVideoInput] = useState(false);
  const [newVideoUrl, setNewVideoUrl] = useState('');
  const [newVideoTitle, setNewVideoTitle] = useState('');
  const [isScrapingMore, setIsScrapingMore] = useState(false);
  const [uploadTargetPageId, setUploadTargetPageId] = useState<string>('');

  const savedVideos = creator.savedVideos || [];

  // Scrape more videos (ASAL — yt-dlp se, koi fake data nahi)
  const handleScrapeMoreVideos = async () => {
    const profileUrl = (creator.profileUrl || '').trim();
    if (!profileUrl) {
      onAddLog(`❌ @${creator.name} ka profile URL nahi hai — scrape nahi ho sakta.`, 'error', 'download');
      return;
    }
    setIsScrapingMore(true);
    onAddLog(
      `⚡ Asal scrape: @${creator.name} (${profileUrl}) se naye reels nikal raha hai...`,
      'info',
      'download'
    );
    try {
      const { count, entries } = await scrapeLinks(profileUrl, 'newest');
      const newUrls = (entries || []).map((e: any) => e.url).filter(Boolean);
      // pehle se maujood links dobara na aayen
      const existing = new Set(creator.links || []);
      const fresh = newUrls.filter((u: string) => !existing.has(u));
      const updatedCreator: CreatorMapping = {
        ...creator,
        links: [...(creator.links || []), ...fresh],
        queue: (creator.queue || 0) + fresh.length,
      };
      onUpdateCreator(updatedCreator);
      onAddLog(
        `✅ Scrape complete: ${count} mile, ${fresh.length} naye queue mein (Total queue: ${updatedCreator.queue}). DOWNLOAD se asal videos aayengi.`,
        'success',
        'download'
      );
    } catch (e: any) {
      onAddLog(
        `❌ Scrape fail: ${String(e?.message || e).slice(0, 140)}`,
        'error',
        'download'
      );
    } finally {
      setIsScrapingMore(false);
    }
  };

  // Add custom video link or name to this folder
  const handleAddCustomVideo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVideoUrl.trim()) {
      onAddLog(`❌ Video URL lazmi hai — khaali title se fake video nahi banegi.`, 'error', 'download');
      return;
    }

    const nextIndex = savedVideos.length + 1;
    const cleanUrl = newVideoUrl.trim();
    const title =
      newVideoTitle.trim() || `${creator.name} - Custom Reel #${nextIndex}`;

    const newVideo: SavedVideo = {
      id: `vid-${Date.now()}`,
      filename: `${creator.name}_custom_${Date.now().toString().slice(-4)}.mp4`,
      title,
      url: cleanUrl,
      duration: '—',
      size: '—',
      resolution: '—',
      createdAt: new Date().toLocaleTimeString(),
      status: 'Saved in Folder',
    };

    const updatedVideos = [...savedVideos, newVideo];
    const updatedCreator: CreatorMapping = {
      ...creator,
      savedVideos: updatedVideos,
      links: [...creator.links, cleanUrl],
    };

    onUpdateCreator(updatedCreator);
    setNewVideoUrl('');
    setNewVideoTitle('');
    setShowAddVideoInput(false);
    onAddLog(
      `💾 Saved new video "${newVideo.filename}" into folder /creators/${creator.name}/videos/`,
      'success',
      'download'
    );
  };

  // Backend /downloads par asal local file ka URL — source page URL (TikTok/IG)
  // video player mein nahi chalta, is liye local file use karo.
  const folderName = creator.folderName || creator.name;
  const localVideoUrl = (v: SavedVideo) =>
    v.filePath ? downloadFileUrl(folderName, v.filename) : v.url;

  // Delete a video from creator's folder (UI + disk dono se)
  const handleDeleteVideo = (videoId: string, filename: string) => {
    const vid = savedVideos.find((v) => v.id === videoId);
    const updatedVideos = savedVideos.filter((v) => v.id !== videoId);
    onUpdateCreator({
      ...creator,
      savedVideos: updatedVideos,
    });
    // Disk se bhi delete karo (warna jagah bharti rahegi)
    if (vid?.filePath) {
      deleteFiles({ path: vid.filePath })
        .then((n) => {
          if (n > 0) onAddLog(`🗑 Disk se delete: ${filename}`, 'info', 'download');
        })
        .catch(() => {});
    }
    onAddLog(
      `🗑 Deleted ${filename} from folder /creators/${creator.name}/videos/`,
      'warn',
      'download'
    );
  };

  // Download entire folder as ZIP
  const handleDownloadFolderZip = async () => {
    onAddLog(
      `📦 Compiling real ZIP for folder: /creators/${creator.name}/videos/...`,
      'info',
      'download'
    );
    await downloadSingleCreatorFolderZip(creator);
    onAddLog(
      `✅ Downloaded folder "${creator.name}_folder_videos.zip" to your computer!`,
      'success',
      'download'
    );
  };

  // Download individual video (asal local file, corrupt page-HTML nahi)
  const handleDownloadSingleVideo = (video: SavedVideo) => {
    onAddLog(`⬇️ Downloading ${video.filename} to your computer...`, 'info', 'download');
    downloadDirectVideo(localVideoUrl(video), video.filename);
  };

  // All pages from connected accounts
  const allConnectedPages = accounts.flatMap((acc) =>
    acc.pages.map((p) => ({ ...p, accountName: acc.name }))
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#0f1422] border border-[#243048] rounded-2xl max-w-3xl w-full flex flex-col max-h-[92vh] shadow-2xl overflow-hidden">
        {/* MODAL HEADER */}
        <div className="p-4 sm:p-5 border-b border-[#1c263c] bg-[#0b0f1a] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
              <Folder className="w-6 h-6 fill-amber-400/20" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-bold text-sm sm:text-base text-white truncate">
                  <span className="text-amber-400">📁</span> /creators/
                  <span
                    className={`text-white ${
                      privacyMode ? 'filter blur-[5px] select-none' : ''
                    }`}
                  >
                    {creator.name}
                  </span>
                  /videos/
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-semibold">
                  {creator.platform}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-semibold">
                  {savedVideos.length} Videos Saved
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 truncate">
                Isolated video storage directory • Ready to download or upload to mapped Facebook Pages
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a2337] transition cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* FOLDER ACTION TOOLBAR */}
        <div className="px-5 py-3 border-b border-[#1c263c] bg-[#0d121f] flex flex-wrap items-center justify-between gap-2.5">
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={handleDownloadFolderZip}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition cursor-pointer shadow-[0_0_10px_rgba(16,185,129,0.25)]"
              title="Download entire folder with videos, metadata, and 1-click batch script"
            >
              <Download className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Download Folder (ZIP)</span>
            </button>

            <button
              onClick={() => {
                downloadTextFile(
                  `${creator.name}_video_links.txt`,
                  creator.links.join('\r\n')
                );
                onAddLog(`📥 Downloaded ${creator.name}_video_links.txt`, 'success', 'download');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#141b2a] border border-[#232f48] text-slate-300 hover:text-white text-xs font-semibold transition cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 text-cyan-400" />
              <span>Export URLs (.txt)</span>
            </button>

            <button
              onClick={handleScrapeMoreVideos}
              disabled={isScrapingMore}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#16233b] border border-[#283e66] text-cyan-300 hover:bg-[#1d3052] text-xs font-semibold transition cursor-pointer disabled:opacity-50"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 ${isScrapingMore ? 'animate-spin' : ''}`}
              />
              <span>{isScrapingMore ? 'Saving...' : '+ Scrape 2 More Videos'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddVideoInput(!showAddVideoInput)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#1a2336] border border-[#2b3a58] text-slate-200 hover:text-white text-xs font-semibold transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-400" />
              <span>Add Video Manually</span>
            </button>
          </div>
        </div>

        {/* OPTIONAL FORM: ADD VIDEO MANUALLY */}
        {showAddVideoInput && (
          <form
            onSubmit={handleAddCustomVideo}
            className="p-4 bg-[#0a0e18] border-b border-[#1c263c] space-y-3"
          >
            <div className="text-xs font-bold text-slate-200 flex items-center gap-2">
              <Plus className="w-3.5 h-3.5 text-emerald-400" />
              <span>Add Video File or Link to /{creator.name}/videos/</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Video Title (e.g. Summer Viral Reel #4)"
                value={newVideoTitle}
                onChange={(e) => setNewVideoTitle(e.target.value)}
                className="bg-[#121828] border border-[#232f48] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
              />
              <input
                type="text"
                placeholder="Video MP4 URL or Reel Link"
                value={newVideoUrl}
                onChange={(e) => setNewVideoUrl(e.target.value)}
                className="bg-[#121828] border border-[#232f48] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setShowAddVideoInput(false)}
                className="px-3 py-1 rounded border border-[#222c40] text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs"
              >
                Save Video into Folder
              </button>
            </div>
          </form>
        )}

        {/* VIDEOS LIST IN THIS FOLDER */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3">
          {savedVideos.length === 0 ? (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
              <div className="w-14 h-14 rounded-2xl bg-[#141b2a] border border-[#222e44] flex items-center justify-center text-amber-400">
                <Folder className="w-7 h-7" />
              </div>
              <div className="max-w-sm space-y-1">
                <h4 className="font-bold text-white text-sm">
                  Folder is Empty: /creators/{creator.name}/videos/
                </h4>
                <p className="text-xs text-slate-400">
                  No video files saved yet. Click below to automatically scrape and save videos into this creator's folder.
                </p>
              </div>
              <button
                onClick={handleScrapeMoreVideos}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>⚡ Auto-Scrape & Save Videos to This Folder</span>
              </button>
            </div>
          ) : (
            savedVideos.map((video, idx) => (
              <div
                key={video.id}
                className="p-3.5 rounded-xl bg-[#0b0f1a] border border-[#1b253b] hover:border-slate-600 transition flex flex-col sm:flex-row sm:items-center justify-between gap-3 group"
              >
                {/* Left: Video details */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="relative w-14 h-14 rounded-lg bg-[#141c2e] border border-[#243350] flex items-center justify-center text-cyan-400 shrink-0 group-hover:border-cyan-500 transition overflow-hidden">
                    <Film className="w-6 h-6 text-cyan-400/80" />
                    <button
                      onClick={() => setPlayingVideo(video)}
                      className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition cursor-pointer"
                      title="Play Preview"
                    >
                      <Play className="w-5 h-5 fill-white text-white" />
                    </button>
                    <span className="absolute bottom-0.5 right-1 text-[9px] font-mono-code text-cyan-300 font-bold">
                      {video.duration || '0:45'}
                    </span>
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono-code text-xs font-bold text-amber-300 truncate">
                        {video.filename}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-medium">
                        {video.status}
                      </span>
                    </div>

                    <p
                      className={`text-xs text-slate-200 font-medium mt-0.5 truncate ${
                        privacyMode ? 'filter blur-[4px] select-none' : ''
                      }`}
                    >
                      {video.title}
                    </p>

                    <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono-code mt-1 flex-wrap">
                      <span>📁 /creators/{creator.name}/videos/</span>
                      <span>•</span>
                      <span>{video.size || '14.2 MB'}</span>
                      <span>•</span>
                      <span>{video.resolution || '1080p HD'}</span>
                      <span>•</span>
                      <span>Saved: {video.createdAt}</span>
                    </div>
                  </div>
                </div>

                {/* Right: Actions for this video */}
                <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                  <button
                    onClick={() => setPlayingVideo(video)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#182338] border border-[#293d62] text-cyan-300 hover:text-white hover:bg-cyan-900/60 transition text-xs font-semibold cursor-pointer"
                    title="Watch video in preview player"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Watch</span>
                  </button>

                  <button
                    onClick={() => handleDownloadSingleVideo(video)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition cursor-pointer shadow-sm"
                    title="Download this MP4 video to your computer"
                  >
                    <Download className="w-3 h-3 stroke-[2.5]" />
                    <span>Download</span>
                  </button>

                  <button
                    onClick={() => handleDeleteVideo(video.id, video.filename)}
                    className="p-1.5 rounded-lg bg-[#27141a] border border-[#521c27] text-rose-400 hover:bg-rose-900/50 hover:text-rose-200 transition cursor-pointer"
                    title="Delete video from folder"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* FOLDER FOOTER SUMMARY */}
        <div className="p-3.5 sm:px-5 border-t border-[#1c263c] bg-[#0b0f1a] flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <HardDrive className="w-3.5 h-3.5 text-amber-400" />
            <span>
              Directory:{' '}
              <span className="font-mono-code text-slate-200 font-bold">
                /creators/{creator.name}/videos/
              </span>
            </span>
            <span className="text-slate-600">•</span>
            <span>
              {savedVideos.length} files ({savedVideos.length * 14} MB estimated)
            </span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg bg-[#151c2a] border border-[#232f48] text-slate-300 hover:text-white transition cursor-pointer"
          >
            Done
          </button>
        </div>
      </div>

      {/* HTML5 VIDEO PLAYER PREVIEW MODAL */}
      {playingVideo && (
        <div className="fixed inset-0 z-60 bg-black/90 flex items-center justify-center p-4">
          <div className="bg-[#0f1422] border border-[#25324c] rounded-2xl max-w-xl w-full p-4 space-y-3 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-[#1c263c]">
              <div className="min-w-0">
                <h4 className="font-bold text-sm text-white truncate">
                  🎬 Playing: {playingVideo.filename}
                </h4>
                <p className="text-xs text-amber-400 font-mono-code">
                  Saved in /creators/{creator.name}/videos/
                </p>
              </div>
              <button
                onClick={() => setPlayingVideo(null)}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-xl overflow-hidden bg-black aspect-video flex items-center justify-center border border-[#1b253b]">
              <video
                src={localVideoUrl(playingVideo)}
                controls
                autoPlay
                className="w-full h-full object-contain"
              >
                Your browser does not support the video tag.
              </video>
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-xs text-slate-400">
                Resolution: {playingVideo.resolution || '1080p HD'} • Duration: {playingVideo.duration}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownloadSingleVideo(playingVideo)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs"
                >
                  <Download className="w-3.5 h-3.5 stroke-[2.5]" />
                  <span>Download MP4</span>
                </button>
                <button
                  onClick={() => setPlayingVideo(null)}
                  className="px-3 py-1.5 rounded-lg border border-[#232f48] text-slate-300 hover:text-white text-xs"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
