import React, { useState } from 'react';
import {
  ShieldCheck,
  X,
  Copy,
  Check,
  ExternalLink,
  MessageCircle,
  Cpu,
  Key,
  LogOut,
  Calendar,
  User,
  Clock,
} from 'lucide-react';
import { ClientLicenseSession } from '../types';
import { formatRemainingLicense, deactivateCurrentLicense } from '../services/keyDatabase';

interface LicenseInfoModalProps {
  session: ClientLicenseSession;
  onClose: () => void;
  onDeactivate: () => void;
}

export const LicenseInfoModal: React.FC<LicenseInfoModalProps> = ({
  session,
  onClose,
  onDeactivate,
}) => {
  const [copiedKey, setCopiedKey] = useState(false);
  const [copiedHwid, setCopiedHwid] = useState(false);
  const [confirmDeactivate, setConfirmDeactivate] = useState(false);

  const handleCopyKey = () => {
    navigator.clipboard.writeText(session.key);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 2000);
  };

  const handleCopyHwid = () => {
    navigator.clipboard.writeText(session.hwid);
    setCopiedHwid(true);
    setTimeout(() => setCopiedHwid(false), 2000);
  };

  const handleExecuteDeactivate = () => {
    deactivateCurrentLicense();
    onDeactivate();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 selection:bg-indigo-600 selection:text-white">
      <div className="w-full max-w-md bg-[#0e1320] border border-[#202c46] rounded-2xl p-6 shadow-2xl relative space-y-5 animate-in fade-in duration-150">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#1a2336] pb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-950/70 border border-emerald-500/40 text-emerald-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">License Authentication</h3>
              <p className="text-[11px] text-emerald-400 font-medium">
                ● Status: Active & Authorized
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a2234] transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Plan / Tier Badge Banner */}
        <div className="p-3.5 rounded-xl bg-gradient-to-r from-indigo-950/70 to-purple-950/40 border border-indigo-500/30 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider block">
              Tier / Plan
            </span>
            <span className="text-base font-black text-white">{session.planName}</span>
          </div>
          <span className="px-2.5 py-1 rounded-lg bg-emerald-950 border border-emerald-500/40 text-emerald-300 text-xs font-bold">
            {formatRemainingLicense(session)}
          </span>
        </div>

        {/* Details Grid */}
        <div className="space-y-3 text-xs">
          {/* Key row */}
          <div className="p-3 rounded-xl bg-[#080c14] border border-[#1b253b] space-y-1.5">
            <div className="flex items-center justify-between text-slate-400">
              <span className="flex items-center gap-1.5 font-medium">
                <Key className="w-3.5 h-3.5 text-indigo-400" />
                <span>Activated License Key</span>
              </span>
              <button
                onClick={handleCopyKey}
                className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold cursor-pointer text-[11px]"
              >
                {copiedKey ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <div className="font-mono-code font-bold text-white text-xs select-all bg-[#05070c] p-2 rounded border border-[#162034]">
              {session.key}
            </div>
          </div>

          {/* Bound Hardware ID */}
          <div className="p-3 rounded-xl bg-[#080c14] border border-[#1b253b] space-y-1.5">
            <div className="flex items-center justify-between text-slate-400">
              <span className="flex items-center gap-1.5 font-medium">
                <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                <span>Bound Machine HWID</span>
              </span>
              <button
                onClick={handleCopyHwid}
                className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold cursor-pointer text-[11px]"
              >
                {copiedHwid ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <div className="font-mono-code text-indigo-300 text-xs bg-[#05070c] p-2 rounded border border-[#162034] truncate">
              {session.hwid}
            </div>
          </div>

          {/* Client & Expiration row */}
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="p-2.5 rounded-xl bg-[#080c14] border border-[#1b253b] space-y-1">
              <span className="text-slate-400 flex items-center gap-1">
                <User className="w-3 h-3 text-slate-400" />
                <span>Licensed To</span>
              </span>
              <div className="font-semibold text-slate-200 truncate">{session.clientName}</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#080c14] border border-[#1b253b] space-y-1">
              <span className="text-slate-400 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-slate-400" />
                <span>Expiration Date</span>
              </span>
              <div className="font-semibold text-slate-200 truncate">
                {session.expiresAt
                  ? new Date(session.expiresAt).toLocaleDateString()
                  : 'Never (Lifetime)'}
              </div>
            </div>
          </div>
        </div>

        {/* Support & Logout Buttons */}
        <div className="space-y-2 pt-1 border-t border-[#1a2336]">
          {confirmDeactivate ? (
            <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/50 space-y-2 text-xs">
              <div className="text-rose-200 font-semibold">
                Deactivate license on this machine? You will need to enter a valid key to re-enter.
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleExecuteDeactivate}
                  className="flex-1 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition cursor-pointer"
                >
                  Yes, Deactivate Key
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmDeactivate(false)}
                  className="px-3 py-1.5 rounded-lg bg-[#141b2a] hover:bg-[#1f293d] text-slate-300 text-xs transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-between gap-2">
              <a
                href="https://wa.me/923051705177"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 py-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/40 text-emerald-300 font-semibold text-xs transition flex items-center justify-center gap-1.5"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>Contact Farhan Kharal</span>
              </a>
              <button
                type="button"
                onClick={() => setConfirmDeactivate(true)}
                className="py-2 px-3 rounded-xl bg-rose-950/50 hover:bg-rose-900/60 border border-rose-500/40 text-rose-300 font-semibold text-xs transition flex items-center gap-1.5 cursor-pointer"
                title="Deactivate / Switch Key"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Deactivate</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
