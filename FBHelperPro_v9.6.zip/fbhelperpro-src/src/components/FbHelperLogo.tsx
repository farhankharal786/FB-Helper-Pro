import React from 'react';

interface FbHelperLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
}

export const FbHelperLogo: React.FC<FbHelperLogoProps> = ({
  size = 'md',
  showSubtitle = true,
}) => {
  const iconSize = size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-11 h-11' : 'w-9 h-9';
  const titleSize = size === 'sm' ? 'text-xs' : size === 'lg' ? 'text-lg' : 'text-sm';
  const subSize = size === 'sm' ? 'text-[9px]' : size === 'lg' ? 'text-xs' : 'text-[10px]';

  return (
    <div className="flex items-center gap-2.5 select-none">
      {/* High-tech FB Helper Logo Icon */}
      <div
        className={`${iconSize} relative rounded-xl bg-gradient-to-br from-blue-600 via-indigo-600 to-sky-500 p-0.5 shadow-[0_0_15px_rgba(37,99,235,0.45)] flex items-center justify-center shrink-0 group`}
      >
        <div className="w-full h-full bg-[#0a0f1d] rounded-[10px] flex items-center justify-center relative overflow-hidden">
          {/* Subtle neon glow inside */}
          <div className="absolute inset-0 bg-blue-500/15 blur-xs"></div>
          {/* Facebook 'f' glyph stylized */}
          <svg
            viewBox="0 0 24 24"
            className="w-5 h-5 fill-blue-400 relative z-10 drop-shadow-[0_0_6px_rgba(96,165,250,0.8)]"
          >
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
          </svg>
        </div>
      </div>

      {/* Brand Text */}
      <div className="flex flex-col">
        <div className="flex items-center gap-1.5">
          <span className={`font-black tracking-wider text-white ${titleSize} uppercase`}>
            FB HELPER
          </span>
          <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">
            PRO
          </span>
        </div>
        {showSubtitle && (
          <span className={`font-semibold text-slate-400 ${subSize}`}>
            By <span className="text-blue-400">Farhan Kharal</span>
          </span>
        )}
      </div>
    </div>
  );
};
