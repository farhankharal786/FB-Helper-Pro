import React, { useState, useEffect } from 'react';
import {
  Settings as SettingsIcon,
  MessageCircle,
  User,
  Shield,
  Cpu,
  RefreshCw,
  Phone,
  CheckCircle2,
  Sliders,
  Database,
  ExternalLink,
  Trash2,
  Film,
  FolderOpen,
} from 'lucide-react';
import { deleteFiles, dbInfo, getDownloadsDir, setDownloadsDir } from '../utils/api';

interface SettingsViewProps {
  onAddLog: (
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error',
    category?: 'download' | 'upload' | 'system'
  ) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onAddLog }) => {
  const [hardwareAccel, setHardwareAccel] = useState(true);
  const [antiBanMode, setAntiBanMode] = useState(true);
  const [requestDelay, setRequestDelay] = useState('3.5s');
  const [copiedNumber, setCopiedNumber] = useState(false);

  // Automation settings (Dashboard farming parho — localStorage)
  const [autoDelete, setAutoDelete] = useState(() => localStorage.getItem('fbh_autoDelete') !== '0');
  const [autoRescrape, setAutoRescrape] = useState(() => localStorage.getItem('fbh_autoRescrape') !== '0');
  const [deleting, setDeleting] = useState(false);


  useEffect(() => {
  }, []);





  // Local database info (100% is PC par — koi server nahi)
  const [dbPath, setDbPath] = useState('');
  const [dbCounts, setDbCounts] = useState({ total: 0, downloaded: 0, uploaded: 0, failed: 0 });

  useEffect(() => {
    dbInfo()
      .then((d) => {
        setDbPath(d.path || '');
        setDbCounts(d.counts || { total: 0, downloaded: 0, uploaded: 0, failed: 0 });
      })
      .catch(() => {});
    getDownloadsDir()
      .then((d) => {
        setDlDir(d.path || '');
        setDlDirInput(d.path || '');
        setDlDirIsDefault(!!d.isDefault);
      })
      .catch(() => {});
  }, []);

  // Downloads folder — user apne PC par choose kare (yahan creators ke folders banein ge)
  const [dlDir, setDlDir] = useState('');
  const [dlDirInput, setDlDirInput] = useState('');
  const [dlDirIsDefault, setDlDirIsDefault] = useState(true);
  const [dlDirSaving, setDlDirSaving] = useState(false);

  const handleSaveDlDir = async () => {
    if (!dlDirInput.trim()) {
      onAddLog('❌ Folder path khaali hai.', 'error', 'system');
      return;
    }
    setDlDirSaving(true);
    try {
      const r = await setDownloadsDir(dlDirInput.trim());
      setDlDir(r.path);
      setDlDirIsDefault(false);
      onAddLog(`📁 Downloads folder set: ${r.path} — ab har creator ka folder yahin banega.`, 'success', 'system');
    } catch (e: any) {
      onAddLog(`❌ Folder set nahi hua: ${e.message || e}`, 'error', 'system');
    }
    setDlDirSaving(false);
  };

  const handleDeleteAll = async () => {
    if (!window.confirm('Saari downloaded videos delete ho jayengi. Pakka?')) return;
    setDeleting(true);
    try {
      const n = await deleteFiles({ all: true });
      onAddLog(`🗑 ${n} downloaded file(s) delete ho gayin.`, 'warn', 'system');
    } catch (e: any) {
      onAddLog(`❌ Delete failed: ${e.message || e}`, 'error', 'system');
    }
    setDeleting(false);
  };

  const handleCopyWhatsApp = () => {
    navigator.clipboard.writeText('03051705177');
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
    onAddLog('WhatsApp number copied: 03051705177', 'info', 'system');
  };

  const handleSaveSettings = () => {
    onAddLog('✅ FB Helper settings applied successfully.', 'success', 'system');
  };

  return (
    <div className="flex-1 flex flex-col bg-[#0b0e14] p-6 overflow-y-auto space-y-6 text-slate-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#182030] pb-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-indigo-400" />
            <span>FB HELPER • System Settings</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure Facebook automation engine, developer details & proxy parameters.
          </p>
        </div>

        {/* Developer Badge */}
        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-lg bg-blue-950/60 border border-blue-600/40 text-blue-300 text-xs font-semibold flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-blue-400" />
            <span>By Farhan Kharal</span>
          </div>
          <a
            href="https://wa.me/923051705177"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-[0_0_10px_rgba(16,185,129,0.3)] cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-white" />
            <span>WhatsApp 03051705177</span>
          </a>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-5xl">
        {/* Developer & Contact Card */}
        <div className="bg-[#0f1422] border border-[#20293d] rounded-xl p-5 space-y-4">
          <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-[#1a2336] pb-2.5">
            <User className="w-4 h-4 text-blue-400" />
            <span>Developer & Contact Information</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div className="p-3.5 rounded-lg bg-[#080c14] border border-[#1b253b] space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Software:</span>
                <span className="text-white font-bold text-sm tracking-wide">FB HELPER</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Developer:</span>
                <span className="text-blue-400 font-bold">Farhan Kharal</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">WhatsApp:</span>
                <div className="flex items-center gap-2">
                  <span className="text-emerald-400 font-mono-code font-bold">
                    03051705177
                  </span>
                  <button
                    onClick={handleCopyWhatsApp}
                    className="px-2 py-0.5 rounded bg-[#162034] text-slate-300 hover:text-white border border-[#25334d] text-[10px] cursor-pointer"
                  >
                    {copiedNumber ? 'Copied' : 'Copy'}
                  </button>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Direct Chat:</span>
                <a
                  href="https://wa.me/923051705177"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>Chat on WhatsApp</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>

            <div className="p-3 rounded-lg bg-[#0d2218] border border-emerald-600/40 text-emerald-300 text-xs">
              <div className="font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Authorized FB Helper License</span>
              </div>
              <p className="text-[11px] text-emerald-200/80 mt-1">
                Custom build by Farhan Kharal with Facebook multi-page mapping and isolated Business Manager hub.
              </p>
            </div>
          </div>
        </div>

        {/* Engine Parameters */}
        <div className="bg-[#0f1422] border border-[#20293d] rounded-xl p-5 space-y-4">
          <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-[#1a2336] pb-2.5">
            <Sliders className="w-4 h-4 text-indigo-400" />
            <span>Automation Engine Parameters</span>
          </h3>

          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-3 rounded-lg bg-[#080c14] border border-[#1b253b] cursor-pointer">
              <div>
                <div className="font-semibold text-slate-200">Zero Cross-Linkage Socket Shield</div>
                <div className="text-[11px] text-slate-400">
                  Prevents Facebook BM accounts from sharing browser cookies or IP fingerprint
                </div>
              </div>
              <input
                type="checkbox"
                checked={antiBanMode}
                onChange={(e) => setAntiBanMode(e.target.checked)}
                className="w-4 h-4 rounded accent-indigo-600"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-lg bg-[#080c14] border border-[#1b253b] cursor-pointer">
              <div>
                <div className="font-semibold text-slate-200">Hardware GPU Acceleration</div>
                <div className="text-[11px] text-slate-400">
                  Intel HD 4600 (QSV) accelerated video thumbnail rendering
                </div>
              </div>
              <input
                type="checkbox"
                checked={hardwareAccel}
                onChange={(e) => setHardwareAccel(e.target.checked)}
                className="w-4 h-4 rounded accent-indigo-600"
              />
            </label>

            <div className="p-3 rounded-lg bg-[#080c14] border border-[#1b253b] flex items-center justify-between">
              <div>
                <div className="font-semibold text-slate-200">Graph API Request Jitter / Delay</div>
                <div className="text-[11px] text-slate-400">
                  Human-like randomized delays between batch page posts
                </div>
              </div>
              <select
                value={requestDelay}
                onChange={(e) => setRequestDelay(e.target.value)}
                className="bg-[#141a26] border border-[#222c3f] rounded px-2.5 py-1 text-white font-mono-code focus:outline-none"
              >
                <option value="2.0s">2.0s (Fast)</option>
                <option value="3.5s">3.5s (Safe / Recommended)</option>
                <option value="5.0s">5.0s (Ultra Stealth)</option>
              </select>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={handleSaveSettings}
              className="w-full py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer"
            >
              Save Configuration
            </button>
          </div>
        </div>

        {/* Download Folder — user apne PC par choose kare */}
        <div className="bg-[#0f1422] border border-[#20293d] rounded-xl p-5 space-y-4">
          <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-[#1a2336] pb-2.5">
            <FolderOpen className="w-4 h-4 text-amber-400" />
            <span>Download Folder</span>
            <span className={`ml-auto text-[10px] px-2 py-0.5 rounded ${dlDirIsDefault ? 'bg-slate-800 text-slate-400' : 'bg-emerald-900/60 text-emerald-300'}`}>
              {dlDirIsDefault ? '○ Default' : '● Custom'}
            </span>
          </h3>

          <p className="text-[11px] text-slate-400">
            Apne PC ka wo folder likho jahan <b className="text-slate-200">har creator ka apne naam ka folder</b> banega
            aur usi ki videos save hongi. Poora path likho, masalan:
          </p>

          <div className="p-2.5 rounded-lg bg-[#080c14] border border-[#1b253b]">
            <div className="text-[10px] text-slate-500 mb-1">Current folder:</div>
            <div className="text-[11px] text-slate-200 font-mono-code break-all">{dlDir || '...'}</div>
          </div>

          <div className="flex gap-2">
            <input
              value={dlDirInput}
              onChange={(e) => setDlDirInput(e.target.value)}
              placeholder="D:\Videos\FBHelper"
              className="flex-1 bg-[#080c14] border border-[#1b253b] rounded-lg px-3 py-2 text-white text-xs font-mono-code focus:outline-none focus:border-amber-500"
            />
            <button
              onClick={handleSaveDlDir}
              disabled={dlDirSaving}
              className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white font-bold text-xs transition cursor-pointer"
            >
              {dlDirSaving ? '...' : 'Set'}
            </button>
          </div>
          <p className="text-[10px] text-slate-500">
            Nayi downloads isi folder mein jayengi. Pehle download ki hui files apni jagah rehti hain.
          </p>
        </div>

        {/* Local Database — 100% is PC par */}
        <div className="bg-[#0f1422] border border-[#20293d] rounded-xl p-5 space-y-4">
          <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-[#1a2336] pb-2.5">
            <Database className="w-4 h-4 text-emerald-400" />
            <span>Local Database</span>
            <span className="ml-auto text-[10px] px-2 py-0.5 rounded bg-emerald-900/60 text-emerald-300">
              ● 100% is PC par
            </span>
          </h3>

          <div className="p-3.5 rounded-lg bg-[#080c14] border border-[#1b253b] space-y-2 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Database file:</span>
              <span className="text-slate-200 font-mono-code text-[10px] break-all text-right max-w-[60%]">{dbPath || '...'}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Total jobs:</span>
              <span className="text-white font-bold">{dbCounts.total}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Downloaded:</span>
              <span className="text-emerald-400 font-bold">{dbCounts.downloaded}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Uploaded (verified):</span>
              <span className="text-blue-400 font-bold">{dbCounts.uploaded}</span>
            </div>
            {dbCounts.failed > 0 && (
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Failed:</span>
                <span className="text-red-400 font-bold">{dbCounts.failed}</span>
              </div>
            )}
          </div>

          <div className="p-3 rounded-lg bg-[#0d2218] border border-emerald-600/40 text-emerald-300 text-[11px]">
            <div className="font-bold flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Koi server / cloud nahi</span>
            </div>
            <p className="text-emerald-200/80 mt-1">
              Tumhara saara data (jobs, links, uploads) sirf is PC ki file mein save hota hai.
              Internet par sirf Facebook (upload/page sync) aur video sites (download) se baat hoti hai.
            </p>
          </div>
        </div>

        {/* Storage & Automation */}
        <div className="bg-[#0f1422] border border-[#20293d] rounded-xl p-5 space-y-4">
          <h3 className="font-bold text-sm text-white flex items-center gap-2 border-b border-[#1a2336] pb-2.5">
            <Database className="w-4 h-4 text-amber-400" />
            <span>Storage & Automation</span>
          </h3>

          <div className="space-y-3 text-xs">
            <label className="flex items-center justify-between p-3 rounded-lg bg-[#080c14] border border-[#1b253b] cursor-pointer">
              <div>
                <div className="font-semibold text-slate-200">Auto-delete video after upload</div>
                <div className="text-[11px] text-slate-400">
                  Farming mein upload kamyab hote hi local file delete (jagah bache)
                </div>
              </div>
              <input
                type="checkbox"
                checked={autoDelete}
                onChange={(e) => {
                  setAutoDelete(e.target.checked);
                  localStorage.setItem('fbh_autoDelete', e.target.checked ? '1' : '0');
                }}
                className="w-4 h-4 rounded accent-indigo-600"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-lg bg-[#080c14] border border-[#1b253b] cursor-pointer">
              <div>
                <div className="font-semibold text-slate-200">Auto re-scrape (24/7 Autopilot)</div>
                <div className="text-[11px] text-slate-400">
                  Account ki links khatm hon to settings ke mutabiq dobara scrape
                </div>
              </div>
              <input
                type="checkbox"
                checked={autoRescrape}
                onChange={(e) => {
                  setAutoRescrape(e.target.checked);
                  localStorage.setItem('fbh_autoRescrape', e.target.checked ? '1' : '0');
                }}
                className="w-4 h-4 rounded accent-indigo-600"
              />
            </label>

            <div className="p-3 rounded-lg bg-[#080c14] border border-[#1b253b]">
              <div className="font-semibold text-slate-200 flex items-center gap-2">
                <Film className="w-4 h-4 text-slate-400" />
                <span>Downloaded Videos</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 mb-3">
                Pehle download ki hui saari videos aik click mein delete karo.
              </p>
              <button
                onClick={handleDeleteAll}
                disabled={deleting}
                className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>{deleting ? 'Deleting...' : 'Delete All'}</span>
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
