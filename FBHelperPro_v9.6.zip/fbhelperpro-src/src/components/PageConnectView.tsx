import React, { useState, useRef, useEffect } from 'react';
import {
  Shield,
  Layers,
  RotateCw,
  Plus,
  RefreshCw,
  User,
  Upload,
  Pause,
  Play,
  Trash2,
  Folder,
  CheckCircle2,
  AlertCircle,
  ArrowLeft,
  X,
  Eye,
  EyeOff,
  Key,
  Building2,
  Check,
  ExternalLink,
  FileDown,
  Film,
  Link2,
  Zap,
} from 'lucide-react';
import { BmAccount, FbPageMapping, CreatorMapping } from '../types';
import { FbHelperLogo } from './FbHelperLogo';
import { downloadJsonFile } from '../utils/realDownloader';
import { startUpload, listFiles, pollJob, parseLimit, ApiFile, fbValidateToken, fbValidatePageToken, fbFetchPages, fbGetPageToken } from '../utils/api';

interface PageConnectViewProps {
  accounts: BmAccount[];
  setAccounts: React.Dispatch<React.SetStateAction<BmAccount[]>>;
  creators: CreatorMapping[];
  onAddLog: (
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error',
    category?: 'download' | 'upload' | 'system'
  ) => void;
  onNavigateToDashboard?: () => void;
  privacyMode: boolean;
  setPrivacyMode: (val: boolean) => void;
}

interface DiscoveredPage {
  name: string;
  pageId: string;
  category: string;
  pageAccessToken?: string;
  selected: boolean;
}

type SubTab = 'multi-bm' | 'channel-mapping';

export const PageConnectView: React.FC<PageConnectViewProps> = ({
  accounts,
  setAccounts,
  creators,
  onAddLog,
  onNavigateToDashboard,
  privacyMode,
  setPrivacyMode,
}) => {
  const [activeSubTab, setActiveSubTab] = useState<SubTab>('multi-bm');
  const [selectedAccountId, setSelectedAccountId] = useState<string>(
    accounts[0]?.id || ''
  );

  // Source Creator Mapping modal for a Facebook page
  const [mappingSourcePage, setMappingSourcePage] = useState<FbPageMapping | null>(null);
  const [customSourceInput, setCustomSourceInput] = useState('');

  // Add Account / BM via Access Token Modal
  const [showAddBmModal, setShowAddBmModal] = useState<boolean>(false);
  const [accountType, setAccountType] = useState<'Personal ID' | 'Business Manager (BM)'>('Personal ID');
  const [accessTokenInput, setAccessTokenInput] = useState('');
  const [accountNameInput, setAccountNameInput] = useState('');
  const [accountIdInput, setAccountIdInput] = useState('');
  const [isFetchingPages, setIsFetchingPages] = useState(false);
  const [fetchedPages, setFetchedPages] = useState<DiscoveredPage[]>([]);

  // Existing Account Re-fetch Pages Modal
  const [showRefetchModal, setShowRefetchModal] = useState<boolean>(false);
  const [refetchTokenInput, setRefetchTokenInput] = useState('');
  const [refetchDiscoveredPages, setRefetchDiscoveredPages] = useState<DiscoveredPage[]>([]);
  const [isRefetching, setIsRefetching] = useState(false);

  // Manual Add Page Modal
  const [showAddPageModal, setShowAddPageModal] = useState<boolean>(false);
  const [newPageName, setNewPageName] = useState('');
  const [newPageId, setNewPageId] = useState('');

  // Extension 1-Click Sync import
  const [isSyncingFromExt, setIsSyncingFromExt] = useState(false);
  // Real BM sync (backend /api/fb/sync-businesses)
  const [isSyncingBm, setIsSyncingBm] = useState(false);

  const handleRealBmSync = async () => {
    const acc = selectedAccount;
    const cleanToken = (acc?.accessToken || '').trim();
    if (!cleanToken) {
      onAddLog('❌ Pehle koi account connect karo (token chahiye) — phir Real BM Sync dabao.', 'error', 'system');
      return;
    }
    setIsSyncingBm(true);
    onAddLog('🏢 Asal Business Managers nikal raha hai (Graph API)...', 'info', 'system');
    try {
      const { fbSyncBusinesses } = await import('../utils/api');
      const r = await fbSyncBusinesses(cleanToken);
      if (r.permissionMissing) {
        onAddLog(`⚠️ ${r.note || 'business_management permission nahi hai.'}`, 'warn', 'system');
        return;
      }
      const bms = r.businesses || [];
      if (!bms.length) {
        onAddLog('ℹ️ Is account ke neeche koi Business Manager nahi mila (API ne khaali list di — koi fake BM nahi banaya).', 'info', 'system');
        return;
      }
      // Har owned page ka ASAL page token nikalo — /owned_pages sirf id/name deta hai,
      // user token pageAccessToken mein daalne se uploads fail hoti thin (token invalid).
      const newAccounts: BmAccount[] = await Promise.all(bms.map(async (b) => {
        const pages: FbPageMapping[] = await Promise.all((b.owned_pages || []).map(async (p, i) => {
          let pageToken: string | undefined;
          try {
            const tj: any = await fbGetPageToken(p.page_id, cleanToken);
            if (tj && tj.found && tj.token) pageToken = String(tj.token);
          } catch {}
          if (!pageToken) {
            onAddLog(`⚠️ [${p.name}] page token nahi mil saka — is page par upload se pehle page token chahiye hoga.`, 'warn', 'system');
          }
          return {
            id: `page-bm-${b.bm_id}-${i}-${Date.now()}`,
            name: p.name,
            pageId: p.page_id,
            status: 'Active' as const,
            videoFolder: 'No Source Mapped',
            monetized: false,
            posts: 0,
            dedicatedProxy: 'Direct',
            accountId: `acc-bm-${b.bm_id}`,
            category: 'Page',
            pageAccessToken: pageToken, // undefined = naqli user token kabhi nahi
          };
        }));
        return {
          id: `acc-bm-${b.bm_id}-${Date.now()}`,
          name: b.name,
          accountNumber: `BM-${b.bm_id}`,
          accountDisplayId: b.bm_id,
          type: 'Business Manager (BM)',
          accountType: 'Business Manager (BM)',
          accessToken: cleanToken,
          tokenStatus: 'Valid',
          proxy: 'Direct',
          isPaused: false,
          tag: `${(b.owned_pages || []).length} Owned Pages`,
          pages,
        };
      }));
      setAccounts((prev) => {
        const next = [...prev];
        for (const na of newAccounts) {
          if (!next.some((a) => a.accountDisplayId === na.accountDisplayId)) next.push(na);
        }
        return next;
      });
      onAddLog(`✅ ${bms.length} ASAL Business Manager(s) sync ho gaye!`, 'success', 'system');
    } catch (e: any) {
      onAddLog(`❌ BM sync fail: ${String(e?.message || e).slice(0, 160)}`, 'error', 'system');
    } finally {
      setIsSyncingBm(false);
    }
  };

  const selectedAccount =
    accounts.find((a) => a.id === selectedAccountId) || accounts[0];

  // Browser extension (1-Click Sync) se aaya data import karo
  const handleExtensionSyncImport = async () => {
    setIsSyncingFromExt(true);
    onAddLog('⚡ Extension sync data la raha hai...', 'info', 'system');
    try {
      // GET /api/extension-sync par auth lazmi hai (page tokens) — local token header bhejo
      const { getToken } = await import('../utils/api');
      const res = await fetch('/api/extension-sync', {
        headers: { 'x-fbh-token': await getToken().catch(() => '') },
      });
      const data = await res.json();
      if (!data || !data.ok || !data.synced) {
        onAddLog(`❌ ${data?.error || 'Sync data nahi mila.'} Pehle Chrome extension se 1-CLICK SYNC dabao.`, 'error', 'system');
        return;
      }
      if (data.synced_at) {
        try { localStorage.setItem('fbh_last_ext_sync', data.synced_at); } catch {}
      }
      await importExtSyncData(data);
    } catch {
      onAddLog('❌ App server se rabta nahi ho saka — RUN.bat se app khuli honi chahiye.', 'error', 'system');
    } finally {
      setIsSyncingFromExt(false);
    }
  };

  // Extension sync data -> accounts/pages (manual + auto-import dono yahi use karte hain)
  const importExtSyncData = async (data: any) => {
      const now = Date.now();
      const newAccounts: BmAccount[] = [];

      // 1) Personal ID account — user + uske pages
      const userId = data.user?.id || `ext-${now}`;
      const pages: FbPageMapping[] = (data.pages || []).map((p: any, i: number) => ({
        id: `page-${now}-${i}`,
        name: p.name || 'Facebook Page',
        pageId: String(p.page_id),
        status: 'Active',
        videoFolder: 'No Source Mapped',
        monetized: false,
        posts: 0,
        dedicatedProxy: 'Direct',
        accountId: `acc-ext-${userId}`,
        category: p.category || 'Page',
        // page_token_valid=false = extension ko page token nahi mila — naqli
        // user token rakhne se upload fail hota hai, is liye khaali chhoro
        pageAccessToken: p.page_token_valid === false ? undefined : (p.token || undefined),
      }));
      const pagesWithoutToken = (data.pages || []).filter((p: any) => p.page_token_valid === false).length;
      if (pagesWithoutToken > 0) {
        onAddLog(`⚠️ ${pagesWithoutToken} page(s) ka page-token nahi mil saka (sirf IDs mili) — in par upload se pehle page token dobara sync karo.`, 'warn', 'system');
      }
      newAccounts.push({
        id: `acc-ext-${userId}`,
        name: data.user?.name || 'Facebook Account',
        accountNumber: `Account-${userId}`,
        accountDisplayId: userId,
        type: 'Personal ID',
        accountType: 'Personal ID',
        accessToken: (data.user_token || '').trim(),
        tokenStatus: 'Valid',
        proxy: 'Direct',
        isPaused: false,
        tag: `${pages.length} Pages`,
        pages,
      });

      // 2) Business Managers — alag accounts (pages refetch token se aa sakte hain)
      (data.businesses || []).forEach((b: any, i: number) => {
        const bmId = String(b.bm_id);
        newAccounts.push({
          id: `acc-ext-bm-${bmId}`,
          name: b.name || 'Business Manager',
          accountNumber: `BM-${bmId}`,
          accountDisplayId: bmId,
          type: 'Business Manager (BM)',
          accountType: 'Business Manager (BM)',
          accessToken: (data.user_token || '').trim(),
          tokenStatus: 'Valid',
          proxy: 'Direct',
          isPaused: false,
          tag: '0 Pages',
          pages: [],
        });
      });

      // Duplicate accounts ko update karo, naye add karo —
      // pages ko pageId se MERGE karo taake purani sourceCreatorName mapping
      // (Upload/Upload All ke liye) dobara sync par na mite.
      setAccounts((prev) => {
        const next = [...prev];
        for (const na of newAccounts) {
          const idx = next.findIndex((a) => a.accountDisplayId === na.accountDisplayId);
          if (idx >= 0) {
            const existing = next[idx];
            const prevPages = new Map((existing.pages || []).map((p) => [String(p.pageId), p]));
            const mergedPages = na.pages.map((p) => {
              const old = prevPages.get(String(p.pageId));
              const merged = { ...(old || {}), ...p, id: old?.id || p.id };
              // Naya token khaali ho to purana SAHI token NA mitayo (re-sync overwrite bug)
              if (!p.pageAccessToken && old && old.pageAccessToken) {
                merged.pageAccessToken = old.pageAccessToken;
              }
              return merged;
            });
            next[idx] = { ...existing, ...na, id: existing.id, pages: mergedPages };
          } else {
            next.push(na);
          }
        }
        return next;
      });
      setSelectedAccountId(`acc-ext-${userId}`);
      // Token status asal mein check karo — hardcoded 'Valid' nahi
      try {
        const vt = await fbValidateToken((data.user_token || '').trim());
        if (vt && (vt as any).valid === false) {
          setAccounts((prev) =>
            prev.map((a) => (a.accountDisplayId === userId ? { ...a, tokenStatus: 'Unverified' as const } : a))
          );
          onAddLog('⚠️ Sync import hua lekin token invalid/expired lag raha hai — dobara sync karo.', 'warn', 'system');
        }
      } catch {}
      onAddLog(
        `✅ Extension sync import: ${data.user?.name} — ${pages.length} pages connected!`,
        'success',
        'system'
      );
  };

  // AUTO-IMPORT: extension ne naya sync kiya ho to khud import kar lo (bina click ke)
  useEffect(() => {
    let alive = true;
    const check = async () => {
      try {
        const { getToken } = await import('../utils/api');
        const res = await fetch('/api/extension-sync', {
          headers: { 'x-fbh-token': await getToken().catch(() => '') },
        });
        const data = await res.json().catch(() => ({}));
        if (!alive || !data || !data.ok || !data.synced || !data.synced_at) return;
        const cur = (() => { try { return localStorage.getItem('fbh_last_ext_sync') || ''; } catch { return ''; } })();
        if (data.synced_at && data.synced_at !== cur) {
          try { localStorage.setItem('fbh_last_ext_sync', data.synced_at); } catch {}
          onAddLog('🔄 Extension ka naya sync mila — auto-import ho raha hai...', 'info', 'system');
          setIsSyncingFromExt(true);
          try {
            await importExtSyncData(data);
          } finally {
            if (alive) setIsSyncingFromExt(false);
          }
        }
      } catch {}
    };
    check();
    const t = setInterval(check, 30000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  // is session mein upload ho chuki files (dobara upload se bachao)
  const uploadedThisSession = useRef<Set<string>>(new Set());
  // abhi upload chal raha hai kin pages par (double-click se duplicate upload roko)
  const uploadingPages = useRef<Set<string>>(new Set());

  // Token inspect — SIRF asal Graph API, koi fake pages nahi
  const executeTokenFetch = async (token: string, mode: 'Personal ID' | 'Business Manager (BM)', accountName?: string) => {
    const cleanToken = token.trim();
    if (!cleanToken) {
      onAddLog(`❌ Pehle token paste karo.`, 'error', 'system');
      return;
    }
    setIsFetchingPages(true);
    setFetchedPages([]);
    onAddLog(`🔍 Graph API se asal pages nikal raha hai...`, 'info', 'system');

    try {
      const data: any = await fbFetchPages(cleanToken);
      if (!data || data.valid === false) {
        throw new Error(data?.message || 'Token invalid/expired hai.');
      }
      // User ID auto-fill (pehle khaali rehta tha)
      if (data.user && data.user.id) {
        setAccountIdInput(String(data.user.id));
        if (!accountNameInput.trim() && data.user.name) setAccountNameInput(String(data.user.name));
      }
      const list = Array.isArray(data?.pages) ? data.pages : [];
      if (!list.length) {
        onAddLog(`⚠️ Token theek hai (ID: ${data?.user?.id || '?'}) lekin is account ke neeche koi Facebook Page nahi mila.`, 'warn', 'system');
        return;
      }
      const pages: DiscoveredPage[] = list
        .filter((p: any) => p.page_id && p.token)
        .map((p: any) => ({
          name: p.name || 'Facebook Page',
          pageId: String(p.page_id),
          category: p.category || 'Page',
          pageAccessToken: p.token,
          selected: true,
        }));
      if (!pages.length) {
        onAddLog(`⚠️ ${list.length} entries milein lekin page tokens nahi mile — dobara login karke naya token lo.`, 'warn', 'system');
        return;
      }
      setFetchedPages(pages);
      onAddLog(`✅ ${pages.length} ASAL Facebook Pages mile! (User: ${data?.user?.name || ''} — ID: ${data?.user?.id || ''})`, 'success', 'system');
    } catch (e: any) {
      onAddLog(`❌ Pages nahi mile: ${String(e?.message || e).slice(0, 160)}`, 'error', 'system');
    } finally {
      setIsFetchingPages(false);
    }
  };

  const handleRefetchPages = async () => {
    if (!selectedAccount || !refetchTokenInput.trim()) return;
    const cleanToken = refetchTokenInput.trim();
    setIsRefetching(true);
    setRefetchDiscoveredPages([]);
    onAddLog(`🔄 Graph API se asal pages nikal raha hai...`, 'info', 'system');

    try {
      const data: any = await fbFetchPages(cleanToken);
      if (!data || data.valid === false) {
        throw new Error(data?.message || 'Token invalid/expired hai.');
      }
      const list = Array.isArray(data?.pages) ? data.pages : [];
      const existingIds = new Set((selectedAccount.pages || []).map((p) => String(p.pageId)));
      const newPages: DiscoveredPage[] = list
        .filter((p: any) => p.page_id && p.token && !existingIds.has(String(p.page_id)))
        .map((p: any) => ({
          name: p.name || 'Facebook Page',
          pageId: String(p.page_id),
          category: p.category || 'Page',
          pageAccessToken: p.token,
          selected: true,
        }));
      setRefetchDiscoveredPages(newPages);
      onAddLog(
        newPages.length
          ? `✅ ${newPages.length} naye ASAL pages mile — import ke liye ready!`
          : `ℹ️ Koi naya page nahi mila (sab pehle se added hain ya token ke neeche pages nahi).`,
        newPages.length ? 'success' : 'info',
        'system'
      );
    } catch (e: any) {
      onAddLog(`❌ Refetch fail: ${String(e?.message || e).slice(0, 160)}`, 'error', 'system');
    } finally {
      setIsRefetching(false);
    }
  };

  const handleApplyRefetchedPages = () => {
    if (!selectedAccount) return;
    const toAdd: FbPageMapping[] = refetchDiscoveredPages
      .filter((p) => p.selected)
      .map((p) => ({
        id: `page-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
        name: p.name,
        pageId: p.pageId,
        status: 'Active' as const,
        videoFolder: 'No Source Mapped',
        monetized: false,
        posts: 0,
        dedicatedProxy: 'Direct',
        accountId: selectedAccount.id,
        category: p.category,
        pageAccessToken: p.pageAccessToken,
      }));

    setAccounts((prev) =>
      prev.map((acc) =>
        acc.id === selectedAccount.id
          ? { ...acc, pages: [...acc.pages, ...toAdd] }
          : acc
      )
    );

    onAddLog(`➕ Successfully imported ${toAdd.length} fetched pages to ${selectedAccount.name}`, 'success', 'system');
    setShowRefetchModal(false);
    setRefetchTokenInput('');
    setRefetchDiscoveredPages([]);
  };

  // MAPPING SOURCE CREATOR TO FACEBOOK PAGE
  const handleSelectSourceCreator = (creator: CreatorMapping) => {
    if (!mappingSourcePage || !selectedAccount) return;
    const folderPath = `/creators/${creator.name}/videos/`;

    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === selectedAccount.id) {
          return {
            ...acc,
            pages: acc.pages.map((p) =>
              p.id === mappingSourcePage.id
                ? {
                    ...p,
                    sourceCreatorName: creator.name,
                    sourceCreatorId: creator.id,
                    sourcePlatform: creator.platform,
                    videoFolder: folderPath,
                  }
                : p
            ),
          };
        }
        return acc;
      })
    );

    onAddLog(
      `🔗 Video Source Mapped: [${mappingSourcePage.name}] will download & upload reels from Creator [${creator.name}] (${folderPath})`,
      'success',
      'upload'
    );
    setMappingSourcePage(null);
    setCustomSourceInput('');
  };

  const handleSelectCustomSource = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mappingSourcePage || !selectedAccount || !customSourceInput.trim()) return;

    const cleanName = customSourceInput.trim().replace(/^@/, '');
    const folderPath = `/creators/${cleanName}/videos/`;

    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === selectedAccount.id) {
          return {
            ...acc,
            pages: acc.pages.map((p) =>
              p.id === mappingSourcePage.id
                ? {
                    ...p,
                    sourceCreatorName: cleanName,
                    sourcePlatform: 'Social',
                    videoFolder: folderPath,
                  }
                : p
            ),
          };
        }
        return acc;
      })
    );

    onAddLog(
      `🔗 Video Source Mapped: [${mappingSourcePage.name}] -> Source Account [${cleanName}] (${folderPath})`,
      'success',
      'upload'
    );
    setMappingSourcePage(null);
    setCustomSourceInput('');
  };

  // REAL upload (AutoFarm wala method: Graph API video/photo)
  // Upload All / Upload: source ke FOLDER mein jo videos pehle se hain
  // wahi upload hongi — nayi download NAHI hogi.
  const uploadPageVideo = async (page: FbPageMapping): Promise<boolean> => {
    if (!page.sourceCreatorName) {
      onAddLog(
        `⚠️ Please select a Source Creator account for ${page.name} first!`,
        'warn',
        'upload'
      );
      setMappingSourcePage(page);
      return false;
    }
    if (!page.pageAccessToken) {
      onAddLog(
        `⚠️ [${page.name}] page access token missing — 1-Click Sync se dobara sync karo.`,
        'error',
        'upload'
      );
      return false;
    }
    const creator = creators.find(
      (c) => c.name.toLowerCase() === page.sourceCreatorName?.toLowerCase()
    );
    const folder = creator?.folderName || page.sourceCreatorName || '';
    const lim = (creator && parseLimit(creator.limit)) || 5;

    let files: ApiFile[] = [];
    try {
      files = await listFiles(folder);
    } catch (e: any) {
      onAddLog(`❌ [${page.name}] folder read failed: ${e.message || e}`, 'error', 'upload');
      return false;
    }
    // folder ki videos (newest first), jo is session mein upload ho chuki skip
    const videos = files
      .filter((f) => /\.(mp4|mov|mkv|avi|webm)$/i.test(f.name))
      .filter((f) => !uploadedThisSession.current.has(f.path))
      .slice(0, lim);
    if (!videos.length) {
      onAddLog(
        `⚠️ [${page.name}] 📁 ${folder}/ mein koi nayi video nahi — pehle DOWNLOAD / START FARMING se download karo.`,
        'warn',
        'upload'
      );
      return false;
    }
    onAddLog(
      `📤 [${page.name}] folder se ${videos.length} video(s) upload ho rahi hain...`,
      'info',
      'upload'
    );
    let ok = 0;
    for (const v of videos) {
      // filename mein original title hota hai: "%(title).60s-%(id)s.%(ext)s"
      const title = v.name.replace(/\.[^.]+$/, '').replace(/-[A-Za-z0-9_-]{6,}$/, '').slice(0, 100) || v.name;
      try {
        onAddLog(`📤 [${page.name}] uploading: ${v.name} ...`, 'info', 'upload');
        const upId = await startUpload(page.pageId, page.pageAccessToken, v.path, title);
        const upJob = await pollJob(upId, () => {});
        uploadedThisSession.current.add(v.path);
        setAccounts((prev) =>
          prev.map((acc) =>
            acc.id === selectedAccount.id
              ? { ...acc, pages: acc.pages.map((p) => (p.id === page.id ? { ...p, posts: p.posts + 1 } : p)) }
              : acc
          )
        );
        ok += 1;
        onAddLog(
          `✅ [${page.name}] "${title.slice(0, 50)}" upload ho gaya! (post ${(upJob.postId || '').slice(0, 24)})`,
          'success',
          'upload'
        );
      } catch (e: any) {
        onAddLog(`❌ [${page.name}] "${v.name.slice(0, 40)}": ${e.message || e}`, 'error', 'upload');
      }
    }
    return ok > 0;
  };

  const handleUploadAll = async () => {
    if (!selectedAccount) return;
    const mappedPages = selectedAccount.pages.filter(
      (p) => p.sourceCreatorName && p.status === 'Active'
    );
    if (mappedPages.length === 0) {
      onAddLog(
        `⚠️ No video sources mapped yet. Please click "Select Source" for your pages first.`,
        'warn',
        'upload'
      );
      return;
    }

    onAddLog(
      `▲ UPLOAD ALL: har page apne source folder ki videos upload karega (${mappedPages.length} pages)...`,
      'info',
      'upload'
    );
    let ok = 0;
    for (const p of mappedPages) {
      // eslint-disable-next-line no-await-in-loop
      if (await uploadPageVideo(p)) ok += 1;
    }
    onAddLog(
      `✅ Upload All complete: ${ok}/${mappedPages.length} page(s) par videos upload ho gayin.`,
      'success',
      'upload'
    );
  };

  const handlePauseAccount = () => {
    if (!selectedAccount) return;
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === selectedAccount.id) {
          const nextPaused = !acc.isPaused;
          onAddLog(
            `Account ${acc.name} is now ${nextPaused ? 'PAUSED' : 'RESUMED'}`,
            nextPaused ? 'warn' : 'info',
            'upload'
          );
          return {
            ...acc,
            isPaused: nextPaused,
            pages: acc.pages.map((p) => ({
              ...p,
              status: nextPaused ? 'Paused' : 'Active',
            })),
          };
        }
        return acc;
      })
    );
  };

  const handleSyncAccount = async () => {
    if (!selectedAccount) return;
    const cleanToken = (selectedAccount.accessToken || '').trim();
    if (!cleanToken) {
      onAddLog(`❌ ${selectedAccount.name}: koi token nahi hai — pehle token do.`, 'error', 'system');
      return;
    }
    onAddLog(`🔄 Graph API se ${selectedAccount.name} ka token verify ho raha hai...`, 'info', 'system');
    try {
      const data: any = await fbValidateToken(cleanToken);
      if (!data || data.valid === false) throw new Error(data?.message || 'Token invalid/expired hai.');
      onAddLog(`✅ Token VALID: ${data.name || selectedAccount.name} (ID: ${data.id})`, 'success', 'system');
    } catch (e: any) {
      onAddLog(`❌ Token INVALID: ${String(e?.message || e).slice(0, 140)}`, 'error', 'system');
    }
  };

  const handleDeleteAccount = () => {
    if (!selectedAccount) return;
    if (confirm(`Remove Account ${selectedAccount.name}?`)) {
      setAccounts((prev) => prev.filter((a) => a.id !== selectedAccount.id));
      onAddLog(`Account ${selectedAccount.name} deleted`, 'warn', 'system');
    }
  };

  const handleSinglePageUpload = (page: FbPageMapping) => {
    // fire-and-forget — progress logs mein ata hai (double-click guard ke saath)
    if (uploadingPages.current.has(page.id)) {
      onAddLog(`⚠️ [${page.name}] upload pehle se chal raha hai.`, 'warn', 'upload');
      return;
    }
    uploadingPages.current.add(page.id);
    void uploadPageVideo(page).finally(() => uploadingPages.current.delete(page.id));
  };

  const handleSinglePagePause = (pageId: string) => {
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === selectedAccount.id) {
          return {
            ...acc,
            pages: acc.pages.map((p) => {
              if (p.id === pageId) {
                const nextStatus = p.status === 'Active' ? 'Paused' : 'Active';
                onAddLog(`Page ${p.name} status updated to ${nextStatus}`, 'info', 'upload');
                return { ...p, status: nextStatus };
              }
              return p;
            }),
          };
        }
        return acc;
      })
    );
  };

  const handleSinglePageVerify = async (page: FbPageMapping) => {
    const cleanToken = (page.pageAccessToken || '').trim();
    if (!cleanToken) {
      onAddLog(`❌ ${page.name}: page token nahi hai — verify nahi ho sakta.`, 'error', 'system');
      return;
    }
    onAddLog(`🔍 ${page.name} ka page token verify ho raha hai...`, 'info', 'system');
    try {
      const vt: any = await fbValidatePageToken(page.pageId, cleanToken);
      if (vt && vt.valid) {
        onAddLog(`✅ VERIFIED: ${vt.name || page.name} — page token kaam kar raha hai.`, 'success', 'system');
      } else {
        onAddLog(`❌ VERIFY FAIL (${page.name}): ${vt?.message || 'token invalid/expired'}`, 'error', 'system');
      }
    } catch (e: any) {
      onAddLog(`❌ VERIFY FAIL (${page.name}): ${String(e?.message || e).slice(0, 140)}`, 'error', 'system');
    }
  };

  const handleSinglePageClean = (page: FbPageMapping) => {
    // Local view refresh — koi fake delay/claim nahi
    onAddLog(`🧹 ${page.name}: local view refreshed.`, 'info', 'system');
  };

  const handleSinglePageDelete = (pageId: string) => {
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === selectedAccount.id) {
          return {
            ...acc,
            pages: acc.pages.filter((p) => p.id !== pageId),
          };
        }
        return acc;
      })
    );
    onAddLog(`Deleted page mapping from account`, 'warn', 'upload');
  };

  const togglePageMonetized = (pageId: string) => {
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.id === selectedAccount.id) {
          return {
            ...acc,
            pages: acc.pages.map((p) =>
              p.id === pageId ? { ...p, monetized: !p.monetized } : p
            ),
          };
        }
        return acc;
      })
    );
  };

  // Submit connecting account + all selected fetched pages
  const handleAddAccountWithTokenSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessTokenInput.trim()) {
      alert('Please provide a Facebook Access Token');
      return;
    }

    const name = accountNameInput.trim() || (accountType === 'Personal ID' ? 'Facebook User' : 'Business Manager');
    const displayId =
      accountIdInput.trim() ||
      (accountType === 'Personal ID'
        ? `ID-FB-${Math.floor(100000000000000 + Math.random() * 900000000000000)}`
        : `ID-BM-${Math.floor(100000000000000 + Math.random() * 900000000000000)}`);
    const newAccountId = `acc-${Date.now()}`;

    const selectedDiscovered = fetchedPages.filter((p) => p.selected);
    const initialPages: FbPageMapping[] =
      selectedDiscovered.length > 0
        ? selectedDiscovered.map((p, idx) => ({
            id: `page-${Date.now()}-${idx}`,
            name: p.name,
            pageId: p.pageId,
            status: 'Active',
            videoFolder: 'No Source Mapped',
            monetized: false,
            posts: 0,
            dedicatedProxy: 'Direct',
            accountId: newAccountId,
            category: p.category,
            pageAccessToken: p.pageAccessToken,
          }))
        : [
            {
              id: `page-${Date.now()}-0`,
              name: `${name} Main Page`,
              pageId: `${Math.floor(100000000000000 + Math.random() * 900000000000000)}`,
              status: 'Active',
              videoFolder: 'No Source Mapped',
              monetized: false,
              posts: 0,
              dedicatedProxy: 'Direct',
              accountId: newAccountId,
            },
          ];

    const newAccount: BmAccount = {
      id: newAccountId,
      name,
      accountNumber: `Account-${Math.floor(10000000000000 + Math.random() * 90000000000000)}`,
      accountDisplayId: displayId,
      type: accountType,
      accountType,
      accessToken: accessTokenInput.trim(),
      tokenStatus: 'Valid',
      proxy: 'Direct',
      isPaused: false,
      tag: `${initialPages.length} Pages`,
      pages: initialPages,
    };

    setAccounts((prev) => [...prev, newAccount]);
    setSelectedAccountId(newAccount.id);
    onAddLog(
      `➕ Connected ${accountType}: ${newAccount.name} (${initialPages.length} Facebook Pages imported via Access Token)`,
      'success',
      'system'
    );

    setShowAddBmModal(false);
    setAccessTokenInput('');
    setAccountNameInput('');
    setAccountIdInput('');
    setFetchedPages([]);
  };

  const handleManualAddPageSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPageName.trim() || !selectedAccount) return;

    const newPage: FbPageMapping = {
      id: `page-${Date.now()}`,
      name: newPageName.trim(),
      pageId: newPageId.trim() || `${Math.floor(100000000000000 + Math.random() * 900000000000000)}`,
      status: 'Active',
      videoFolder: 'No Source Mapped',
      monetized: false,
      posts: 0,
      dedicatedProxy: 'Direct',
      accountId: selectedAccount.id,
    };

    setAccounts((prev) =>
      prev.map((acc) =>
        acc.id === selectedAccount.id
          ? { ...acc, pages: [...acc.pages, newPage] }
          : acc
      )
    );

    onAddLog(`➕ Added Facebook Page: ${newPage.name}`, 'success', 'system');
    setShowAddPageModal(false);
    setNewPageName('');
    setNewPageId('');
  };

  return (
    <div className="flex-1 flex flex-col bg-[#0b0e14] overflow-hidden text-slate-200">
      {/* TOP SUB-TAB NAVIGATION BAR */}
      <div className="px-5 py-2.5 border-b border-[#182030] flex flex-wrap items-center justify-between gap-3 bg-[#0d111a]">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setActiveSubTab('multi-bm')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeSubTab === 'multi-bm'
                ? 'bg-[#1d4ed8] text-white shadow-[0_0_12px_rgba(29,78,216,0.5)]'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141a26]'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Multi-BM & FB Profile Hub</span>
          </button>

          <button
            onClick={() => setActiveSubTab('channel-mapping')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
              activeSubTab === 'channel-mapping'
                ? 'bg-[#1d4ed8] text-white'
                : 'text-slate-400 hover:text-slate-200 hover:bg-[#141a26]'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span>Channel Mapping</span>
          </button>
        </div>

        {/* Right Tools */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              const next = !privacyMode;
              setPrivacyMode(next);
              onAddLog(
                `Privacy Mode ${next ? 'ACTIVATED (Tokens & Names Blurred)' : 'DEACTIVATED'}`,
                next ? 'warn' : 'info',
                'system'
              );
            }}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-bold transition cursor-pointer ${
              privacyMode
                ? 'bg-amber-950/80 border-amber-500 text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.4)]'
                : 'bg-[#141a26] border-[#222c3f] text-slate-300 hover:text-white'
            }`}
          >
            {privacyMode ? (
              <EyeOff className="w-3.5 h-3.5 text-amber-400" />
            ) : (
              <Eye className="w-3.5 h-3.5 text-slate-400" />
            )}
            <span>Privacy Mode: {privacyMode ? 'ON' : 'OFF'}</span>
          </button>

          <button
            onClick={async () => {
              onAddLog(`⟳ Refreshing Facebook profiles & token life...`, 'info', 'system');
              const acc = selectedAccount;
              const cleanToken = (acc?.accessToken || '').trim();
              if (!cleanToken) {
                onAddLog(`❌ Koi token nahi — refresh nahi ho sakta.`, 'error', 'system');
                return;
              }
              try {
                const data: any = await fbValidateToken(cleanToken);
                if (!data || data.valid === false) throw new Error(data?.message || 'Token invalid/expired hai.');
                onAddLog(`✅ Refresh OK: ${data.name} — token valid hai.`, 'success', 'system');
              } catch (e: any) {
                onAddLog(`❌ Refresh FAIL: ${String(e?.message || e).slice(0, 140)}`, 'error', 'system');
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold text-xs text-black bg-[#10b981] hover:bg-[#059669] transition cursor-pointer"
          >
            <RotateCw className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Refresh Profiles</span>
          </button>
        </div>
      </div>

      {/* SUB-HEADER BANNER */}
      <div className="px-5 py-3 border-b border-[#141a26] flex flex-wrap items-center justify-between gap-3 bg-[#0a0d14]">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 rounded-lg bg-indigo-950/80 border border-indigo-700/60 flex items-center justify-center text-indigo-400">
            <Shield className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-white tracking-wide">
              Facebook Token & Pages Hub
            </h2>
            <p className="text-[11px] text-slate-400 font-medium">
              Map Video Source Creator &rarr; Auto Download &amp; Upload to Connected Facebook Pages
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExtensionSyncImport}
            disabled={isSyncingFromExt}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-bold text-xs text-white bg-[#2563eb] hover:bg-[#1d4ed8] disabled:opacity-60 transition cursor-pointer shadow-[0_0_10px_rgba(37,99,235,0.3)]"
            title="Chrome extension se 1-click mein pages/BM sync karo"
          >
            <Zap className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>{isSyncingFromExt ? 'Syncing...' : '⚡ Sync from Extension'}</span>
          </button>
          <button
            onClick={handleRealBmSync}
            disabled={isSyncingBm}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-bold text-xs text-white bg-[#7c3aed] hover:bg-[#6d28d9] disabled:opacity-60 transition cursor-pointer shadow-[0_0_10px_rgba(124,58,237,0.3)]"
            title="Asal Graph API se Business Managers sync karo (koi fake BM nahi)"
          >
            <Building2 className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>{isSyncingBm ? 'Syncing...' : '🏢 Real BM Sync'}</span>
          </button>
          <button
            onClick={() => setShowAddBmModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-bold text-xs text-black bg-[#10b981] hover:bg-[#059669] transition cursor-pointer shadow-[0_0_10px_rgba(16,185,129,0.3)]"
          >
            <Key className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>+ Connect via Access Token (ID / BM)</span>
          </button>

          {accounts.length > 0 && (
            <button
              onClick={() => {
                downloadJsonFile('facebook_connected_pages_backup.json', accounts);
                onAddLog('📥 Downloaded facebook_connected_pages_backup.json to your computer!', 'success', 'system');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 bg-[#141a26] border border-[#222c3f] hover:text-white transition cursor-pointer"
            >
              <FileDown className="w-3.5 h-3.5 text-indigo-400" />
              <span>Export JSON</span>
            </button>
          )}

          <button
            onClick={() => {
              onAddLog(`Refreshing accounts & token registry...`, 'info', 'system');
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-300 bg-[#141a26] border border-[#222c3f] hover:text-white transition cursor-pointer"
          >
            <RefreshCw className="w-3 h-3 text-slate-400" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* MAIN CONTENT / EMPTY STATE */}
      {accounts.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-4">
          <div className="p-4 rounded-2xl bg-[#0f1422] border border-[#1e273b] shadow-xl">
            <FbHelperLogo size="lg" showSubtitle={false} />
          </div>

          <div className="max-w-md space-y-1.5">
            <h3 className="font-bold text-base text-white">
              No Facebook Accounts or Pages Connected Yet
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Connect your Facebook Personal Profile or Business Manager using your Access Token. All pages will be automatically fetched and ready for video source mapping.
            </p>
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              onClick={handleExtensionSyncImport}
              disabled={isSyncingFromExt}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-[0_0_12px_rgba(37,99,235,0.3)]"
            >
              <Zap className="w-4 h-4 stroke-[2.5]" />
              <span>{isSyncingFromExt ? 'Syncing...' : '⚡ Sync from Extension'}</span>
            </button>
            <button
              onClick={() => setShowAddBmModal(true)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.3)]"
            >
              <Key className="w-4 h-4 stroke-[2.5]" />
              <span>Connect FB ID / BM (Paste Token)</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex overflow-hidden">
          {/* LEFT COLUMN: CONNECTED ACCOUNTS */}
          <div className="w-72 shrink-0 border-r border-[#161d2b] bg-[#0c1018] flex flex-col">
            <div className="px-4 py-3 border-b border-[#161d2b] flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 uppercase tracking-wider text-[11px]">
                CONNECTED FB ACCOUNTS
              </span>
              <span className="text-slate-400 text-[11px]">
                {accounts.length} Active
              </span>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-2">
              {accounts.map((acc) => {
                const isSelected = acc.id === selectedAccount?.id;
                return (
                  <div
                    key={acc.id}
                    onClick={() => setSelectedAccountId(acc.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#12162a] border-[#4338ca] shadow-md shadow-indigo-950/40'
                        : 'bg-[#101420] border-[#1c2436] hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 mb-1.5">
                      <div className="flex items-center gap-1.5 truncate">
                        <div className="w-5 h-5 rounded-full bg-indigo-900/60 flex items-center justify-center text-indigo-400 shrink-0">
                          <User className="w-3 h-3" />
                        </div>
                        <span
                          className={`font-semibold text-xs text-white truncate ${
                            privacyMode ? 'filter blur-[5px] select-none' : ''
                          }`}
                        >
                          {acc.name}
                        </span>
                      </div>
                      <span className="shrink-0 px-2 py-0.5 rounded text-[10px] font-semibold bg-[#1a2238] border border-indigo-500/40 text-indigo-300">
                        {acc.type}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 mb-2 font-mono-code">
                      <span
                        className={`truncate max-w-[170px] ${
                          privacyMode ? 'filter blur-[5px] select-none' : ''
                        }`}
                      >
                        ID: {acc.accountDisplayId}
                      </span>
                      <span className="px-1.5 py-0.2 rounded bg-[#1e1b4b] text-indigo-300 font-bold border border-indigo-700/50">
                        {acc.pages.length} Pages
                      </span>
                    </div>

                    <div className="flex items-center justify-between pt-1 border-t border-[#1a2336] text-[11px]">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePauseAccount();
                        }}
                        className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#141b2c] border border-[#243048] text-slate-300 hover:text-white text-[10px]"
                      >
                        <Pause className="w-2.5 h-2.5" />
                        <span>{acc.isPaused ? 'Resume' : 'Pause'}</span>
                      </button>

                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-emerald-400 flex items-center gap-1 font-semibold">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                          Token Active
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* RIGHT COLUMN: MAIN MANAGEMENT PANEL */}
          {selectedAccount ? (
            <div className="flex-1 flex flex-col bg-[#0b0e14] overflow-hidden">
              {/* Account Banner & Actions */}
              <div className="px-5 py-3.5 border-b border-[#161d2b] bg-[#0e121c] flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-full bg-indigo-950/80 border border-indigo-700/60 flex items-center justify-center text-indigo-300">
                    <User className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-white flex-wrap">
                      <span
                        className={`text-indigo-400 ${
                          privacyMode ? 'filter blur-[5px] select-none' : ''
                        }`}
                      >
                        {selectedAccount.name}
                      </span>
                      <span
                        className={`text-slate-400 ${
                          privacyMode ? 'filter blur-[5px] select-none' : ''
                        }`}
                      >
                        ({selectedAccount.accountNumber}) (ID: {selectedAccount.accountDisplayId})
                      </span>
                      <span className="text-slate-500">•</span>
                      <span className="px-1.5 py-0.5 rounded bg-indigo-950/60 border border-indigo-800 text-indigo-300 text-[10px]">
                        Total Pages: {selectedAccount.pages.length}
                      </span>
                      <span className="text-slate-500">•</span>
                      <span className="px-1.5 py-0.5 rounded bg-[#162034] text-slate-300 text-[10px]">
                        {selectedAccount.type}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 mt-0.5 text-[11px] font-mono-code text-slate-400">
                      <Key className="w-3 h-3 text-emerald-400" />
                      <span>Token Status:</span>
                      <span className="text-emerald-400 font-semibold">Valid</span>
                      <span className="text-slate-600">•</span>
                      <span className={privacyMode ? 'filter blur-[5px]' : ''}>
                        {selectedAccount.accessToken
                          ? `${selectedAccount.accessToken.slice(0, 8)}••••••••${selectedAccount.accessToken.slice(-4)}`
                          : 'EAAB••••••••Connected'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons Right */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => setShowRefetchModal(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs text-cyan-300 bg-cyan-950/70 border border-cyan-600/60 hover:bg-cyan-900 transition cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Fetch Pages via Token</span>
                  </button>

                  <button
                    onClick={() => setShowAddPageModal(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs text-white bg-indigo-600 hover:bg-indigo-500 transition cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Page</span>
                  </button>

                  <button
                    onClick={handleUploadAll}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-bold text-xs text-black bg-[#10b981] hover:bg-[#059669] transition cursor-pointer shadow-[0_0_10px_rgba(16,185,129,0.25)]"
                    title="Upload videos from source creator folders to mapped Facebook pages"
                  >
                    <Upload className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>Upload All</span>
                  </button>

                  <button
                    onClick={handlePauseAccount}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs text-white bg-[#f59e0b] hover:bg-[#d97706] transition cursor-pointer"
                  >
                    <Pause className="w-3.5 h-3.5 fill-white" />
                    <span>{selectedAccount.isPaused ? 'Resume ID' : 'Pause ID'}</span>
                  </button>

                  <button
                    onClick={handleSyncAccount}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs text-white bg-[#3b82f6] hover:bg-[#2563eb] transition cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Sync</span>
                  </button>

                  <button
                    onClick={handleDeleteAccount}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs text-white bg-[#ef4444] hover:bg-[#dc2626] transition cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>

              {/* TABLE OF PAGES: VIDEO SOURCE CREATOR COLUMN */}
              <div className="flex-1 overflow-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-[#182030] bg-[#0c1018] text-[11px] font-bold text-slate-400 tracking-wider">
                      <th className="py-3 px-4 w-[250px]">Facebook Page</th>
                      <th className="py-3 px-3 text-center w-[100px]">Status</th>
                      <th className="py-3 px-3 w-[350px]">Select Source (Creator & Folder)</th>
                      <th className="py-3 px-3 text-center w-[90px]">Monetized</th>
                      <th className="py-3 px-3 text-center w-[70px]">Posts</th>
                      <th className="py-3 px-4 text-right">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#131924]">
                    {selectedAccount.pages.map((page) => (
                      <tr
                        key={page.id}
                        className="hover:bg-[#111724]/70 transition-colors"
                      >
                        {/* Facebook Page Column */}
                        <td className="py-3.5 px-4">
                          <div>
                            <div className="flex items-center gap-2">
                              <span
                                className={`font-bold text-slate-100 text-xs ${
                                  privacyMode ? 'filter blur-[5px] select-none' : ''
                                }`}
                              >
                                {page.name}
                              </span>
                              {page.category && (
                                <span className="px-1.5 py-0.2 rounded text-[9px] bg-indigo-950/80 text-indigo-300 border border-indigo-800">
                                  {page.category}
                                </span>
                              )}
                            </div>
                            <div
                              className={`font-mono-code text-[11px] text-slate-400 ${
                                privacyMode ? 'filter blur-[5px] select-none' : ''
                              }`}
                            >
                              ID: {page.pageId}
                            </div>
                          </div>
                        </td>

                        {/* Status Column */}
                        <td className="py-3.5 px-3 text-center">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                              page.status === 'Active'
                                ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-600/50'
                                : 'bg-amber-950/80 text-amber-400 border border-amber-600/50'
                            }`}
                          >
                            <span
                              className={`w-1.5 h-1.5 rounded-full ${
                                page.status === 'Active'
                                  ? 'bg-emerald-400'
                                  : 'bg-amber-400'
                              }`}
                            ></span>
                            <span>{page.status}</span>
                          </span>
                        </td>

                        {/* SELECT SOURCE (CREATOR ACCOUNT & FOLDER) - EXACT REQUEST */}
                        <td className="py-3.5 px-3">
                          <div className="flex items-center justify-between gap-2 p-2 rounded-lg bg-[#0e1422] border border-[#1b253b]">
                            {page.sourceCreatorName ? (
                              (() => {
                                const matched = creators.find(
                                  (c) =>
                                    c.name.toLowerCase() ===
                                    page.sourceCreatorName?.toLowerCase()
                                );
                                const vCount = matched
                                  ? matched.savedVideos?.length || matched.links.length
                                  : 3;
                                return (
                                  <div className="flex flex-col min-w-0">
                                    <div className="flex items-center gap-1.5 font-bold text-xs text-white">
                                      <Film className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                                      <span
                                        className={`truncate ${
                                          privacyMode
                                            ? 'filter blur-[5px] select-none'
                                            : ''
                                        }`}
                                      >
                                        Source: @{page.sourceCreatorName}
                                      </span>
                                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 shrink-0">
                                        {page.sourcePlatform || 'TikTok'}
                                      </span>
                                    </div>
                                    <div
                                      className={`text-[10px] text-amber-400 font-mono-code truncate max-w-[210px] mt-0.5 flex items-center gap-1.5 ${
                                        privacyMode
                                          ? 'filter blur-[4px] select-none'
                                          : ''
                                      }`}
                                      title={page.videoFolder}
                                    >
                                      <span>
                                        📁 {page.videoFolder || `/creators/${page.sourceCreatorName}/videos/`}
                                      </span>
                                      <span className="text-emerald-400 font-semibold bg-emerald-950/80 px-1 rounded border border-emerald-800 text-[9px]">
                                        {vCount} vids ready
                                      </span>
                                    </div>
                                  </div>
                                );
                              })()
                            ) : (
                              <div className="flex items-center gap-1 text-xs text-amber-400 font-medium">
                                <span>⚠️ No Source Selected</span>
                              </div>
                            )}

                            {/* SELECT SOURCE BUTTON - EXACT TO BRIEF */}
                            <button
                              onClick={() => setMappingSourcePage(page)}
                              className={`px-2.5 py-1 rounded text-[11px] font-bold transition cursor-pointer shrink-0 ${
                                page.sourceCreatorName
                                  ? 'bg-[#18233a] border border-[#2b3a5a] text-cyan-300 hover:text-white hover:bg-cyan-900/50'
                                  : 'bg-amber-500/20 border border-amber-500/80 text-amber-300 hover:bg-amber-500/40 shadow-sm animate-pulse'
                              }`}
                              title="Select creator account to download and upload videos to this page"
                            >
                              Select Source
                            </button>
                          </div>
                        </td>

                        {/* Monetized Checkbox */}
                        <td className="py-3.5 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={page.monetized}
                            onChange={() => togglePageMonetized(page.id)}
                            className="w-3.5 h-3.5 rounded bg-[#151c2a] border-[#253046] accent-indigo-600 cursor-pointer"
                          />
                        </td>

                        {/* Posts Count */}
                        <td className="py-3.5 px-3 text-center font-bold text-slate-200">
                          {page.posts}
                        </td>

                        {/* Action Buttons */}
                        <td className="py-3.5 px-4 text-right">
                          <div className="flex items-center justify-end gap-1.5 flex-wrap">
                            <button
                              onClick={() => handleSinglePageUpload(page)}
                              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#10b981] hover:bg-[#059669] text-black font-bold text-[11px] transition cursor-pointer shadow-sm"
                              title={page.sourceCreatorName ? `Upload reels from source ${page.sourceCreatorName}` : 'Select a source creator first'}
                            >
                              <Upload className="w-2.5 h-2.5 stroke-[2.5]" />
                              <span>Upload</span>
                            </button>

                            <button
                              onClick={() => handleSinglePagePause(page.id)}
                              className="flex items-center gap-1 px-2.5 py-1 rounded bg-[#2563eb] hover:bg-[#1d4ed8] text-white font-semibold text-[11px] transition cursor-pointer"
                            >
                              <Pause className="w-2.5 h-2.5" />
                              <span>Pause</span>
                            </button>

                            <button
                              onClick={() => handleSinglePageVerify(page)}
                              className="px-2 py-1 rounded bg-[#161f30] border border-[#27354f] text-slate-300 hover:text-white font-medium text-[11px] transition cursor-pointer"
                            >
                              Verify
                            </button>

                            <button
                              onClick={() => handleSinglePageClean(page)}
                              className="px-2 py-1 rounded bg-[#221620] border border-[#451e2e] text-rose-300 hover:text-rose-100 font-medium text-[11px] transition cursor-pointer"
                            >
                              Clean
                            </button>

                            <button
                              onClick={() => handleSinglePageDelete(page.id)}
                              className="px-2 py-1 rounded bg-[#291419] border border-[#581c25] text-rose-400 hover:text-rose-200 font-semibold text-[11px] transition cursor-pointer"
                            >
                              ✕ Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* CARD BOTTOM FOOTER BAR */}
              <div className="px-5 py-2.5 border-t border-[#161d2b] bg-[#0c1018] flex items-center justify-between text-xs text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">FB HELPER</span>
                  <span className="text-slate-500">•</span>
                  <span className="text-blue-400">By Farhan Kharal</span>
                  <span className="text-slate-500">•</span>
                  <span className={`text-emerald-400 font-mono-code ${privacyMode ? 'filter blur-[4px]' : ''}`}>
                    WA: 03051705177
                  </span>
                </div>

                <button
                  onClick={() => {
                    if (onNavigateToDashboard) {
                      onNavigateToDashboard();
                    }
                  }}
                  className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-[#141a26] border border-[#222c3f] text-slate-300 hover:text-white transition cursor-pointer text-xs"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back to Dashboard</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-500">
              Select an account from the left panel.
            </div>
          )}
        </div>
      )}

      {/* MODAL: SELECT SOURCE CREATOR ACCOUNT (REPLACED SELECT FOLDER) */}
      {mappingSourcePage && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0f1422] border border-[#243048] rounded-xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1c263c] pb-3">
              <div>
                <h3 className="font-bold text-sm text-white flex items-center gap-2">
                  <Film className="w-4 h-4 text-cyan-400" />
                  <span>Select Video Source Creator for {mappingSourcePage.name}</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Choose the source account whose videos will be downloaded from their folder and uploaded to this page.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setMappingSourcePage(null)}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              {/* CURRENT CREATORS LIST */}
              {creators.length > 0 ? (
                <div className="space-y-2">
                  <div className="text-slate-300 font-semibold text-xs">
                    Choose from Connected Creators ({creators.length} Available):
                  </div>

                  <div className="max-h-52 overflow-y-auto space-y-2 pr-1">
                    {creators.map((c) => {
                      const isCurrent = mappingSourcePage.sourceCreatorName === c.name;
                      return (
                        <div
                          key={c.id}
                          onClick={() => handleSelectSourceCreator(c)}
                          className={`p-3 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition ${
                            isCurrent
                              ? 'bg-cyan-950/60 border-cyan-500 shadow-md shadow-cyan-950/40'
                              : 'bg-[#090d16] border-[#1b253b] hover:border-slate-500'
                          }`}
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="w-8 h-8 rounded-lg bg-indigo-950/80 border border-indigo-700/60 flex items-center justify-center text-cyan-400 shrink-0">
                              <Film className="w-4 h-4" />
                            </div>
                            <div className="min-w-0">
                              <div className="font-bold text-white text-xs truncate flex items-center gap-1.5">
                                <span>{c.name}</span>
                                <span className="px-1.5 py-0.2 rounded text-[9px] bg-slate-800 text-cyan-300">
                                  {c.platform}
                                </span>
                              </div>
                              <div className="text-[10px] text-amber-400 font-mono-code truncate mt-0.5 flex items-center gap-1.5">
                                <span>📁 /creators/{c.name}/videos/</span>
                                <span className="text-emerald-400 font-semibold bg-emerald-950/80 px-1 rounded border border-emerald-800">
                                  {c.savedVideos?.length || c.links.length} Videos Saved
                                </span>
                              </div>
                            </div>
                          </div>

                          <button
                            type="button"
                            className={`px-3 py-1.5 rounded-lg font-bold text-xs shrink-0 transition ${
                              isCurrent
                                ? 'bg-cyan-500 text-black'
                                : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                            }`}
                          >
                            {isCurrent ? 'Selected' : 'Select This Source'}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-[#090d16] border border-[#1b253b] text-center space-y-2">
                  <div className="font-semibold text-amber-400">No Creator Accounts Added Yet</div>
                  <p className="text-[11px] text-slate-400">
                    Add creators in Dashboard to create their folders and save their videos, or type a custom creator source handle below.
                  </p>
                  {onNavigateToDashboard && (
                    <button
                      type="button"
                      onClick={() => {
                        setMappingSourcePage(null);
                        onNavigateToDashboard();
                      }}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition"
                    >
                      <span>Go to Dashboard & Add Creator</span>
                    </button>
                  )}
                </div>
              )}

              {/* CUSTOM CREATOR SOURCE INPUT */}
              <form onSubmit={handleSelectCustomSource} className="pt-2 border-t border-[#1c263c] space-y-2">
                <label className="block text-slate-300 font-semibold">
                  Or Type Custom Source Creator Handle:
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="e.g. charlidamelio or viral_reels_source"
                    value={customSourceInput}
                    onChange={(e) => setCustomSourceInput(e.target.value)}
                    className="flex-1 bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    type="submit"
                    disabled={!customSourceInput.trim()}
                    className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shrink-0 disabled:opacity-40 transition cursor-pointer"
                  >
                    Set Source
                  </button>
                </div>
              </form>
            </div>

            <div className="flex items-center justify-end pt-2 border-t border-[#1c263c]">
              <button
                type="button"
                onClick={() => setMappingSourcePage(null)}
                className="px-3.5 py-1.5 rounded-lg border border-[#232c40] text-slate-400 hover:text-white text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: ADD ACCOUNT / BM VIA ACCESS TOKEN & FETCH PAGES */}
      {showAddBmModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleAddAccountWithTokenSubmit}
            className="bg-[#0f1422] border border-[#243048] rounded-xl max-w-xl w-full p-5 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between border-b border-[#1c263c] pb-3">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Key className="w-4 h-4 text-emerald-400" />
                <span>Connect via Facebook Access Token (Fetch Pages)</span>
              </h3>
              <button
                type="button"
                onClick={() => {
                  setShowAddBmModal(false);
                  setFetchedPages([]);
                }}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 mb-1.5 font-semibold">
                  Account Type
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAccountType('Personal ID')}
                    className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer ${
                      accountType === 'Personal ID'
                        ? 'bg-blue-600/30 border-blue-500 text-white'
                        : 'bg-[#141a26] border-[#222c3f] text-slate-400 hover:text-white'
                    }`}
                  >
                    <User className="w-3.5 h-3.5 text-blue-400" />
                    <span>Facebook Personal ID</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setAccountType('Business Manager (BM)')}
                    className={`py-2 px-3 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 transition cursor-pointer ${
                      accountType === 'Business Manager (BM)'
                        ? 'bg-indigo-600/30 border-indigo-500 text-white'
                        : 'bg-[#141a26] border-[#222c3f] text-slate-400 hover:text-white'
                    }`}
                  >
                    <Shield className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Business Manager (BM)</span>
                  </button>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-slate-300 font-semibold flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{accountType} Access Token (Required)</span>
                  </label>
                  <span className="text-[10px] text-slate-500">EAAB... User / BM Token</span>
                </div>
                <textarea
                  required
                  rows={3}
                  value={accessTokenInput}
                  onChange={(e) => setAccessTokenInput(e.target.value)}
                  placeholder="Paste your Facebook Access Token here (e.g. EAABw...)"
                  className="w-full bg-[#080c14] border border-[#20293d] rounded-lg p-2.5 text-white font-mono-code text-xs focus:outline-none focus:border-emerald-500"
                />

                <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                  <button
                    type="button"
                    disabled={isFetchingPages || !accessTokenInput.trim()}
                    onClick={() =>
                      executeTokenFetch(accessTokenInput, accountType, accountNameInput)
                    }
                    className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer disabled:opacity-40"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isFetchingPages ? 'animate-spin' : ''}`} />
                    <span>{isFetchingPages ? 'Querying Graph API...' : 'Fetch Pages from Token'}</span>
                  </button>

                  <a
                    href="https://developers.facebook.com/tools/explorer/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-cyan-400 hover:text-cyan-300 hover:underline flex items-center gap-1"
                  >
                    <span>Get Token via Meta Explorer</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  {fetchedPages.length > 0 && (
                    <span className="text-emerald-400 font-semibold text-[11px] flex items-center gap-1 w-full mt-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>{fetchedPages.length} Pages Discovered</span>
                    </span>
                  )}
                </div>
              </div>

              {fetchedPages.length > 0 && (
                <div className="p-3 rounded-xl bg-[#090d16] border border-[#1d273c] space-y-2">
                  <div className="flex items-center justify-between text-xs pb-1 border-b border-[#182030]">
                    <span className="font-bold text-white">Discovered Facebook Pages:</span>
                    <button
                      type="button"
                      onClick={() => {
                        const allSelected = fetchedPages.every((p) => p.selected);
                        setFetchedPages((prev) =>
                          prev.map((p) => ({ ...p, selected: !allSelected }))
                        );
                      }}
                      className="text-cyan-400 hover:underline text-[11px]"
                    >
                      Toggle All
                    </button>
                  </div>

                  <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                    {fetchedPages.map((page, idx) => (
                      <label
                        key={idx}
                        className="flex items-center justify-between p-2 rounded-lg bg-[#0e1422] border border-[#1a2336] hover:border-slate-500 cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={page.selected}
                            onChange={() =>
                              setFetchedPages((prev) =>
                                prev.map((p, i) =>
                                  i === idx ? { ...p, selected: !p.selected } : p
                                )
                              )
                            }
                            className="w-3.5 h-3.5 rounded bg-[#141a26] border-[#222c3f] accent-emerald-500"
                          />
                          <div>
                            <div className="font-semibold text-white text-xs">
                              {page.name}
                            </div>
                            <div className="text-[10px] text-slate-400 font-mono-code">
                              ID: {page.pageId}
                            </div>
                          </div>
                        </div>
                        <span className="px-1.5 py-0.5 rounded text-[9px] bg-slate-800 text-slate-300">
                          {page.category}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <label className="block text-slate-400 mb-1 font-medium">
                    Profile / BM Label Name
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Farhan Media ID"
                    value={accountNameInput}
                    onChange={(e) => setAccountNameInput(e.target.value)}
                    className="w-full bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white text-xs focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">
                    Numeric Facebook / BM ID (Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. 1000889182910"
                    value={accountIdInput}
                    onChange={(e) => setAccountIdInput(e.target.value)}
                    className="w-full bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white font-mono-code text-xs focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1c263c]">
              <button
                type="button"
                onClick={() => {
                  setShowAddBmModal(false);
                  setFetchedPages([]);
                }}
                className="px-3.5 py-1.5 rounded-lg border border-[#232c40] text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.3)]"
              >
                Connect & Import {fetchedPages.filter((p) => p.selected).length > 0 ? `(${fetchedPages.filter((p) => p.selected).length} Pages)` : ''}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* MODAL 2: RE-FETCH PAGES FOR EXISTING ACCOUNT VIA TOKEN */}
      {showRefetchModal && selectedAccount && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-[#0f1422] border border-[#243048] rounded-xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#1c263c] pb-3">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <RefreshCw className="w-4 h-4 text-cyan-400" />
                <span>Fetch Pages for {selectedAccount.name}</span>
              </h3>
              <button
                type="button"
                onClick={() => {
                  setShowRefetchModal(false);
                  setRefetchDiscoveredPages([]);
                }}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-300">
                Provide or update the Access Token for <strong className="text-white">{selectedAccount.name}</strong> to fetch all newly created or assigned Facebook pages from Graph API.
              </p>

              <div>
                <label className="block text-slate-300 mb-1 font-semibold">
                  Access Token (User or BM Token)
                </label>
                <textarea
                  rows={3}
                  value={refetchTokenInput}
                  onChange={(e) => setRefetchTokenInput(e.target.value)}
                  placeholder="Paste token (e.g. EAABw...)"
                  className="w-full bg-[#080c14] border border-[#20293d] rounded-lg p-2.5 text-white font-mono-code text-xs focus:outline-none focus:border-cyan-500"
                />
              </div>

              <button
                type="button"
                disabled={isRefetching || !refetchTokenInput.trim()}
                onClick={handleRefetchPages}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs transition cursor-pointer disabled:opacity-40"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isRefetching ? 'animate-spin' : ''}`} />
                <span>{isRefetching ? 'Fetching...' : 'Fetch Facebook Pages'}</span>
              </button>

              {refetchDiscoveredPages.length > 0 && (
                <div className="p-3 rounded-lg bg-[#090d16] border border-[#1b253b] space-y-2">
                  <div className="font-bold text-white text-xs">
                    Discovered {refetchDiscoveredPages.length} Facebook Pages:
                  </div>
                  <div className="space-y-1.5 max-h-36 overflow-y-auto">
                    {refetchDiscoveredPages.map((page, idx) => (
                      <label
                        key={idx}
                        className="flex items-center justify-between p-2 rounded bg-[#0d1320] border border-[#1a2336] cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={page.selected}
                            onChange={() =>
                              setRefetchDiscoveredPages((prev) =>
                                prev.map((p, i) =>
                                  i === idx ? { ...p, selected: !p.selected } : p
                                )
                              )
                            }
                            className="w-3.5 h-3.5 rounded accent-cyan-500"
                          />
                          <span className="font-semibold text-white">{page.name}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono-code">
                          {page.pageId}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1c263c]">
              <button
                type="button"
                onClick={() => {
                  setShowRefetchModal(false);
                  setRefetchDiscoveredPages([]);
                }}
                className="px-3.5 py-1.5 rounded-lg border border-[#232c40] text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={refetchDiscoveredPages.filter((p) => p.selected).length === 0}
                onClick={handleApplyRefetchedPages}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider transition cursor-pointer disabled:opacity-40"
              >
                Import Selected Pages
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 4: MANUAL ADD PAGE */}
      {showAddPageModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleManualAddPageSubmit}
            className="bg-[#0f1422] border border-[#243048] rounded-xl max-w-md w-full p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-[#1c263c] pb-3">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <Plus className="w-4 h-4 text-indigo-400" />
                <span>Add Facebook Page to {selectedAccount?.name}</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowAddPageModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Facebook Page Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Daily Viral Clips"
                  value={newPageName}
                  onChange={(e) => setNewPageName(e.target.value)}
                  className="w-full bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-medium">
                  Facebook Page ID (Numeric)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 109281726481928"
                  value={newPageId}
                  onChange={(e) => setNewPageId(e.target.value)}
                  className="w-full bg-[#080c14] border border-[#20293d] rounded-lg px-3 py-2 text-white font-mono-code focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1c263c]">
              <button
                type="button"
                onClick={() => setShowAddPageModal(false)}
                className="px-3.5 py-1.5 rounded-lg border border-[#232c40] text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs"
              >
                Add Page
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
