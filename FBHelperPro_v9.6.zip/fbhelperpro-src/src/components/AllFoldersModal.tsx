import React from 'react';
import {
  Folder,
  X,
  Download,
  Film,
  HardDrive,
  ExternalLink,
  CheckCircle2,
  FolderDown,
} from 'lucide-react';
import { CreatorMapping } from '../types';
import {
  downloadSingleCreatorFolderZip,
  generateCreatorBatchZip,
} from '../utils/realDownloader';

interface AllFoldersModalProps {
  creators: CreatorMapping[];
  onClose: () => void;
  onOpenCreatorFolder: (creator: CreatorMapping) => void;
  onAddLog: (
    message: string,
    level?: 'info' | 'success' | 'warn' | 'error',
    category?: 'download' | 'upload' | 'system'
  ) => void;
  privacyMode: boolean;
}

export const AllFoldersModal: React.FC<AllFoldersModalProps> = ({
  creators,
  onClose,
  onOpenCreatorFolder,
  onAddLog,
  privacyMode,
}) => {
  const totalVideosCount = creators.reduce(
    (sum, c) => sum + (c.savedVideos?.length || c.links.length),
    0
  );

  const handleDownloadAllZip = async () => {
    onAddLog(
      `📦 Compiling master ZIP archive with all ${creators.length} creator folders...`,
      'info',
      'download'
    );
    await generateCreatorBatchZip(creators, false);
    onAddLog(
      `✅ Downloaded master archive with all creator folders!`,
      'success',
      'download'
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5">
      <div className="bg-[#0f1422] border border-[#243048] rounded-2xl max-w-3xl w-full flex flex-col max-h-[90vh] shadow-2xl overflow-hidden">
        {/* HEADER */}
        <div className="p-4 sm:p-5 border-b border-[#1c263c] bg-[#0b0f1a] flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
              <FolderDown className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-white">
                  Creator Video Folders Explorer
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-semibold">
                  {creators.length} Folders
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-semibold">
                  {totalVideosCount} Total Videos Saved
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Every added creator has their own separate folder containing their downloaded videos.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#1a2337] transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* TOOLBAR */}
        <div className="px-5 py-3 border-b border-[#1c263c] bg-[#0d121f] flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-xs text-slate-300">
            <HardDrive className="w-4 h-4 text-amber-400" />
            <span>Root Storage: <span className="font-mono-code text-cyan-300">/creators/</span></span>
          </div>

          <button
            onClick={handleDownloadAllZip}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-xs transition cursor-pointer shadow-[0_0_10px_rgba(16,185,129,0.25)]"
          >
            <Download className="w-3.5 h-3.5 stroke-[2.5]" />
            <span>Download All Folders (ZIP)</span>
          </button>
        </div>

        {/* FOLDERS GRID */}
        <div className="flex-1 overflow-y-auto p-5 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {creators.length === 0 ? (
            <div className="col-span-2 py-12 text-center text-slate-400 text-xs">
              No creator folders created yet. Add a creator to create their isolated folder.
            </div>
          ) : (
            creators.map((c) => {
              const videosCount = c.savedVideos?.length || c.links.length;
              return (
                <div
                  key={c.id}
                  className="p-4 rounded-xl bg-[#0b0f1a] border border-[#1b253b] hover:border-amber-500/60 transition flex flex-col justify-between gap-3 group"
                >
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 group-hover:scale-105 transition">
                          <Folder className="w-5 h-5 fill-amber-400/20" />
                        </div>
                        <div>
                          <h4
                            className={`font-bold text-sm text-white group-hover:text-amber-300 transition ${
                              privacyMode ? 'filter blur-[5px] select-none' : ''
                            }`}
                          >
                            {c.name}
                          </h4>
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                            {c.platform}
                          </span>
                        </div>
                      </div>

                      <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-[#141d2e] border border-[#202f4a] text-cyan-300 font-mono-code">
                        {videosCount} Videos
                      </span>
                    </div>

                    <div className="mt-3 p-2 rounded-lg bg-[#070b13] border border-[#151e30] font-mono-code text-[11px] text-amber-400/90 truncate">
                      📁 /creators/{c.name}/videos/
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-[#162034]">
                    <span className="text-[11px] text-slate-400">
                      {videosCount * 14} MB stored
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={async () => {
                          onAddLog(
                            `📦 Downloading ZIP for folder /creators/${c.name}/videos/...`,
                            'info',
                            'download'
                          );
                          await downloadSingleCreatorFolderZip(c);
                        }}
                        className="p-1.5 rounded-lg bg-[#141b2a] border border-[#232f48] text-slate-300 hover:text-white transition cursor-pointer"
                        title="Download this creator folder as ZIP"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          onClose();
                          onOpenCreatorFolder(c);
                        }}
                        className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition cursor-pointer"
                      >
                        Open Folder
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* FOOTER */}
        <div className="p-3.5 border-t border-[#1c263c] bg-[#0b0f1a] flex items-center justify-between text-xs text-slate-400">
          <span>FB HELPER • Automated Creator Directory Isolation Engine</span>
          <button
            onClick={onClose}
            className="px-4 py-1 rounded bg-[#141b28] border border-[#232f48] text-slate-300 hover:text-white"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
