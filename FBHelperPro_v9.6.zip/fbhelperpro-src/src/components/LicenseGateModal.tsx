import React, { useState, useEffect } from 'react';
import {
  Key,
  ShieldCheck,
  AlertTriangle,
  Copy,
  Check,
  ExternalLink,
  MessageCircle,
  Cpu,
  Lock,
  ArrowRight,
} from 'lucide-react';
import {
  activateLicenseKey,
  getDeviceHwid,
} from '../services/keyDatabase';
import { ClientLicenseSession } from '../types';

interface LicenseGateModalProps {
  onActivated: (session: ClientLicenseSession) => void;
  initialError?: string;
}

export const LicenseGateModal: React.FC<LicenseGateModalProps> = ({
  onActivated,
  initialError,
}) => {
  const [keyInput, setKeyInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(initialError || null);
  const [copiedHwid, setCopiedHwid] = useState(false);
  const [success, setSuccess] = useState(false);

  // initialError async aata hai (App ki license check ke baad) — mount ke baad
  // aaye to bhi dikhao, warna error kabhi nazar nahi aata.
  useEffect(() => {
    if (initialError) setError(initialError);
  }, [initialError]);

  const hwid = getDeviceHwid();

  const handleCopyHwid = () => {
    navigator.clipboard.writeText(hwid);
    setCopiedHwid(true);
    setTimeout(() => setCopiedHwid(false), 2000);
  };

  const handleActivate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!keyInput.trim()) {
      setError('Please enter your license key.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await activateLicenseKey(keyInput.trim());
      if (res.success && res.session) {
        setSuccess(true);
        setTimeout(() => {
          onActivated(res.session!);
        }, 800);
      } else {
        setError(res.error || 'Activation failed. Please verify your license key.');
      }
    } catch (err: any) {
      setError(err?.message || 'Server error while checking database.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#06080e]/95 backdrop-blur-xl flex items-center justify-center p-4 selection:bg-indigo-600 selection:text-white">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none"></div>

      <div className="w-full max-w-lg bg-[#0e1320] border border-[#202c46] rounded-2xl p-6 sm:p-8 shadow-2xl relative overflow-hidden space-y-6">
        {/* Glow header bar */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400"></div>

        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-900/80 to-slate-900 border border-indigo-500/40 text-indigo-400 mb-1 shadow-lg shadow-indigo-950/60">
            <Lock className="w-7 h-7 text-indigo-400" />
          </div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center justify-center gap-2">
            <span>FB HELPER PRO</span>
            <span className="text-xs px-2 py-0.5 rounded bg-indigo-950 border border-indigo-500/40 text-indigo-300 font-mono-code font-bold">
              v2.4
            </span>
          </h2>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Enterprise Facebook Automation & Scraping Suite • License Verification Required
          </p>
        </div>

        {/* Machine Hardware ID (HWID) Display */}
        <div className="p-3.5 rounded-xl bg-[#080c14] border border-[#1b253b] space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-400 flex items-center gap-1.5 font-medium">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" />
              <span>Machine Hardware ID (HWID)</span>
            </span>
            <button
              type="button"
              onClick={handleCopyHwid}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold cursor-pointer"
            >
              {copiedHwid ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400 text-[11px]">HWID Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span className="text-[11px]">Copy HWID</span>
                </>
              )}
            </button>
          </div>
          <div className="bg-[#05070c] px-3 py-2 rounded-lg border border-[#162034] text-xs font-mono-code text-indigo-300 select-all tracking-wider break-all font-semibold">
            {hwid}
          </div>
          <div className="text-[10px] text-slate-500">
            Send this HWID to Farhan Kharal if your license key requires machine binding.
          </div>
        </div>

        {/* Activation Form */}
        <form onSubmit={handleActivate} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-indigo-400" />
              <span>Enter License Key</span>
            </label>
            <input
              type="text"
              value={keyInput}
              onChange={(e) => {
                setKeyInput(e.target.value.toUpperCase());
                setError(null);
              }}
              placeholder="FB-XXXX-XXXX-XXXX-XXXX"
              className="w-full bg-[#080b13] border border-[#23314d] focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-white font-mono-code font-bold placeholder:text-slate-600 outline-none transition tracking-wider uppercase"
              autoFocus
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-start gap-2 animate-shake">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* Success Message */}
          {success && (
            <div className="p-3 rounded-xl bg-emerald-950/70 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>License Verified! Unlocking FB HELPER Pro...</span>
            </div>
          )}

          {/* Activate Button */}
          <button
            type="submit"
            disabled={loading || success}
            className={`w-full py-3.5 px-4 rounded-xl text-white font-bold text-xs uppercase tracking-wider transition shadow-lg flex items-center justify-center gap-2 cursor-pointer ${
              loading
                ? 'bg-indigo-800 cursor-not-allowed opacity-80'
                : success
                ? 'bg-emerald-600 shadow-emerald-600/30'
                : 'bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 shadow-indigo-600/30'
            }`}
          >
            {loading ? (
              <>
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                <span>Checking Key Database...</span>
              </>
            ) : success ? (
              <>
                <Check className="w-4 h-4" />
                <span>Authorized</span>
              </>
            ) : (
              <>
                <span>Activate License & Launch</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Developer Contact Footer */}
        <div className="p-3.5 rounded-xl bg-[#090e18] border border-[#1b253b] flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div>
            <div className="font-bold text-slate-200">Need an Official License Key?</div>
            <div className="text-[11px] text-slate-400">Contact Developer Farhan Kharal</div>
          </div>
          <a
            href="https://wa.me/923051705177?text=Hello%20Farhan%20Kharal,%20I%20need%20a%20license%20key%20for%20FB%20HELPER%20Pro."
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition shadow-sm shadow-emerald-950 shrink-0 cursor-pointer"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-white" />
            <span>WhatsApp: 03051705177</span>
            <ExternalLink className="w-3 h-3 ml-0.5 opacity-80" />
          </a>
        </div>
      </div>
    </div>
  );
};
