import React from 'react';
import {
  LayoutDashboard,
  Network,
  Settings,
  Cpu,
  MessageCircle,
  Eye,
  EyeOff,
  Shield,
  Key,
} from 'lucide-react';
import { FbHelperLogo } from './FbHelperLogo';
import { ClientLicenseSession } from '../types';
import { formatRemainingLicense, SyncStatus } from '../services/keyDatabase';

export type NavTab = 'dashboard' | 'page-connect' | 'settings';

interface SidebarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
  isEngineOnline?: boolean;
  privacyMode: boolean;
  setPrivacyMode: (val: boolean) => void;
  currentLicense?: ClientLicenseSession | null;
  onOpenLicenseInfo?: () => void;
  syncStatus?: SyncStatus;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isEngineOnline = true,
  privacyMode,
  setPrivacyMode,
  currentLicense,
  onOpenLicenseInfo,
  syncStatus,
}) => {
  const navItems = [
    {
      id: 'dashboard' as NavTab,
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'page-connect' as NavTab,
      label: 'Page Connect & Mapping',
      icon: Network,
    },
    {
      id: 'settings' as NavTab,
      label: 'Settings',
      icon: Settings,
    },
  ];

  return (
    <aside className="w-64 shrink-0 bg-[#0b0e14] border-r border-[#1a2232] flex flex-col justify-between p-3 select-none min-h-screen">
      <div className="space-y-3">
        {/* Logo & Brand Card */}
        <div className="p-3 rounded-xl bg-[#0f1422] border border-[#1b253b] space-y-2.5">
          <FbHelperLogo size="md" showSubtitle={true} />

          {/* Quick WhatsApp Contact Link */}
          <a
            href="https://wa.me/923051705177"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 w-full py-1.5 px-2 rounded-lg bg-emerald-950/70 border border-emerald-600/50 text-emerald-400 hover:bg-emerald-900/80 transition text-[11px] font-semibold"
          >
            <MessageCircle className="w-3.5 h-3.5 fill-emerald-400 text-emerald-950" />
            <span className={privacyMode ? 'blur-xs' : ''}>WA: 03051705177</span>
          </a>

          {/* Privacy Toggle inside Sidebar */}
          <button
            onClick={() => setPrivacyMode(!privacyMode)}
            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-lg border text-xs font-semibold transition cursor-pointer ${
              privacyMode
                ? 'bg-amber-950/60 border-amber-500/70 text-amber-300'
                : 'bg-[#141b2b] border-[#222e46] text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="flex items-center gap-1.5">
              {privacyMode ? (
                <EyeOff className="w-3.5 h-3.5 text-amber-400" />
              ) : (
                <Eye className="w-3.5 h-3.5 text-slate-400" />
              )}
              <span>Privacy Blur</span>
            </div>
            <span
              className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                privacyMode
                  ? 'bg-amber-500 text-black'
                  : 'bg-[#1b2336] text-slate-400'
              }`}
            >
              {privacyMode ? 'ON' : 'OFF'}
            </span>
          </button>
        </div>

        {/* Navigation list */}
        <nav className="space-y-1.5 pt-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-[13px] font-medium transition-all text-left cursor-pointer ${
                  isActive
                    ? 'bg-[#1e1b4b]/70 border border-[#4338ca]/80 text-white shadow-sm shadow-indigo-950/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-[#121824]'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-indigo-400' : 'text-slate-400'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      {/* SYSTEM TELEMETRY at bottom */}
      <div className="mt-auto pt-4 space-y-2">
        {/* Active License Badge (click = info) */}
        {currentLicense && (
          <button
            onClick={onOpenLicenseInfo}
            className={`w-full p-2.5 rounded-xl border transition text-left group cursor-pointer shadow-sm ${
              currentLicense.isLifetime
                ? 'bg-[#151208] border-amber-500/50 hover:border-amber-400'
                : 'bg-[#0f1726] border-emerald-500/40 hover:border-emerald-500/70'
            }`}
          >
            <div className="flex items-center justify-between">
              <span
                className={`text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 ${
                  currentLicense.isLifetime ? 'text-amber-400' : 'text-emerald-400'
                }`}
              >
                <Key className="w-3 h-3" />
                <span
                  className={`w-1.5 h-1.5 rounded-full animate-pulse ${
                    currentLicense.isLifetime ? 'bg-amber-400' : 'bg-emerald-400'
                  }`}
                ></span>
                {currentLicense.isLifetime ? '⚡ LIFETIME VIP ACTIVE' : 'LICENSE ACTIVE'}
              </span>
              <span className="text-[10px] text-slate-400 font-mono-code group-hover:text-white transition">
                Info →
              </span>
            </div>
            <div className="text-xs font-bold text-white truncate mt-1">
              {currentLicense.planName}
            </div>
            <div
              className={`text-[10px] font-mono-code truncate ${
                currentLicense.isLifetime ? 'text-amber-300' : 'text-emerald-300/80'
              }`}
            >
              {currentLicense.isLifetime
                ? 'Permanent Access (Lifetime Chly Ga)'
                : formatRemainingLicense(currentLicense)}
            </div>
          </button>
        )}

        {/* SERVER API & REAL-TIME SYNC STATUS */}
        <div className="rounded-xl border border-[#1e2638] bg-[#0c101a] p-3 space-y-1.5 text-[11px] shadow-inner">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">
              SERVER & REAL-TIME SYNC
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">Server API:</span>
            <span className="font-semibold text-emerald-400 flex items-center gap-1">
              {syncStatus?.connected ?? true ? 'Online (Port 8573)' : 'Reconnecting...'}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">Real-Time Sync:</span>
            <span className="font-mono-code text-[10px] text-indigo-300 font-medium">
              {syncStatus?.type === 'sse'
                ? '⚡ SSE Stream Active'
                : syncStatus?.type === 'offline'
                ? '💾 Local Cache Safe'
                : '🔄 Live Synced'}
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-[#1e2638] bg-[#0f1420]/80 p-3 space-y-1.5 text-[11px] shadow-inner">
          <div className="text-[10px] font-bold tracking-wider text-slate-500 uppercase">
            SYSTEM TELEMETRY
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">Engine:</span>
            <span className="font-semibold text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              {isEngineOnline ? 'Online (Ready)' : 'Offline'}
            </span>
          </div>
          <div className="flex items-center justify-between text-slate-300">
            <span className="text-slate-400">Hardware GPU:</span>
            <span className="font-semibold text-[#38bdf8] flex items-center gap-1">
              <Cpu className="w-3 h-3 text-[#38bdf8]" />
              HD 4600 (QSV)
            </span>
          </div>
        </div>

        {/* Developer signature */}
        <div className="text-center text-[10px] text-slate-500 pt-1">
          FB Helper • By Farhan Kharal
        </div>
      </div>
    </aside>
  );
};
