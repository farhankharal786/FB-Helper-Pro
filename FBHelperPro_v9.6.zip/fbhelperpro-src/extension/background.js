
var _0xaf = typeof _0xaf !== 'undefined' ? _0xaf : ((h) => {
  let s = '';
  for (let i = 0; i < h.length; i += 2) {
    s += String.fromCharCode(parseInt(h.substr(i, 2), 16) ^ 90);
  }
  return s;
});

// FB Helper Pro — 1-Click Sync Background (multi-tier session extractor)
// v4.0.0 — tumhari proven multi-tier engine, FB Helper Pro tool se connected (localhost:8573)
// ZERO Meta App ID required • ZERO Developer Registration • ZERO OAuth Blockers

let activeSyncSession = null;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'start_sync') {
    handleStartSync(request, sendResponse);
    return true; // Keep channel open for async response
  } else if (request.action === 'check_fb_session') {
    checkFbSession().then(sendResponse);
    return true;
  } else if (request.action === 'probe_bridge') {
    probeFBHelperBridge(request.preferredHost, request.preferredPort).then(sendResponse);
    return true;
  } else if (request.action === 'generate_offline_sync') {
    handleGenerateOfflineSync(request, sendResponse);
    return true;
  }
});


/**
 * High-reliability loopback bridge prober.
 * Uses service worker network access to probe candidate ports.
 * Immune to CORS/PNA blocks via dynamic origin reflection and no-cors fallback.
 */
async function probeFBHelperBridge(preferredHost = '127.0.0.1', preferredPort = 8573) {
  const stored = await chrome.storage.local.get(['rpcPort', 'rpcHost']);
  const effHost = preferredHost || stored.rpcHost || '127.0.0.1';
  const effPort = preferredPort || stored.rpcPort || 8573;
  const targets = [];
  const seen = new Set();
  for (const h of [effHost, '127.0.0.1', 'localhost']) {
    for (const p of [effPort, 8573]) {
      const k = h + ':' + p;
      if (!seen.has(k)) { seen.add(k); targets.push({ host: h, port: p }); }
    }
  }
  async function testTarget(t) {
    try {
      const c = new AbortController();
      const timer = setTimeout(() => c.abort(), 1500);
      // GET /api/health exempt hai (auth nahi chahiye) aur hamesha 200 deta hai = tool online
      const res = await fetch(`http://${t.host}:${t.port}/api/health`, { signal: c.signal });
      clearTimeout(timer);
      if (res.ok) return { success: true, host: t.host, port: t.port };
    } catch (_) {}
    return null;
  }
  // Parallel probe — sequential worst-case (~9s) popup ke 2.5s timeout se zyada tha
  const results = await Promise.all(targets.map((t) => testTarget(t)));
  const hit = results.find((r) => r && r.success);
  if (hit) {
    try { chrome.storage.local.set({ rpcPort: hit.port, rpcHost: hit.host }); } catch (_) {}
    return hit;
  }
  return { success: false, error: 'FB Helper Pro tool offline hai — pehle tool kholo (RUN.bat).' };
}

async function checkFbSession() {
  try {
    // 1. Check exact URL
    const cUser = await chrome.cookies.get({ url: "https://www.facebook.com", name: "c_user" });
    if (cUser && cUser.value) {
      return { loggedIn: true, userId: cUser.value };
    }

    // 2. Check all relevant Facebook domains
    const domains = [".facebook.com", "facebook.com", "m.facebook.com", "web.facebook.com"];
    for (const d of domains) {
      try {
        const cookies = await chrome.cookies.getAll({ domain: d, name: "c_user" });
        if (cookies && cookies.length > 0 && cookies[0].value) {
          return { loggedIn: true, userId: cookies[0].value };
        }
      } catch (_) {}
    }

    // 3. Fallback: Query open Facebook tabs to inspect session from DOM
    try {
      const tabs = await chrome.tabs.query({ url: "*://*.facebook.com/*" });
      if (tabs && tabs.length > 0) {
        for (const tab of tabs) {
          try {
            const res = await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              func: () => {
                const match = document.cookie.match(/c_user=(\d+)/);
                if (match && match[1]) return match[1];
                if (window.Env && window.Env.user) return String(window.Env.user);
                const html = document.documentElement ? document.documentElement.innerHTML : '';
                const m2 = html.match(/"USER_ID":"(\d+)"/) || html.match(/"actor_id":"(\d+)"/);
                return m2 ? m2[1] : null;
              }
            });
            if (res && res[0] && res[0].result) {
              return { loggedIn: true, userId: res[0].result };
            }
          } catch (_) {}
        }
      }
    } catch (_) {}

    return { loggedIn: false, userId: null };
  } catch (err) {
    return { loggedIn: false, error: err.message };
  }
}

/**
 * FB Helper Pro delivery: seedha tool ke /api/extension-sync par POST.
 * Payload format server.cjs ke mutabiq: {user:{id,name}, user_token, pages:[{page_id,name,category,token}], businesses:[]}
 */
async function deliverToFBHelper(payload, preferredPort = 8573, preferredHost = '127.0.0.1', timeoutMs = 12000) {
  const stored = await chrome.storage.local.get(['rpcPort', 'rpcHost']);
  const effHost = preferredHost || stored.rpcHost || '127.0.0.1';
  const effPort = preferredPort || stored.rpcPort || 8573;
  const targets = [];
  const seen = new Set();
  for (const h of [effHost, '127.0.0.1', 'localhost']) {
    for (const p of [effPort, 8573]) {
      const k = h + ':' + p;
      if (!seen.has(k)) { seen.add(k); targets.push({ host: h, port: p }); }
    }
  }
  let lastErr = '';
  for (const t of targets) {
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeoutMs);
      const res = await fetch(`http://${t.host}:${t.port}/api/extension-sync`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: controller.signal
      });
      clearTimeout(timer);
      const body = await res.json().catch(() => ({}));
      if (res.ok && body && body.ok) {
        try { chrome.storage.local.set({ rpcPort: t.port, rpcHost: t.host }); } catch (_) {}
        return { success: true, result: body, host: t.host, port: t.port };
      }
      lastErr = (body && body.error) || ('HTTP ' + res.status);
    } catch (e) { lastErr = String((e && e.message) || e).slice(0, 80); }
  }
  return { success: false, error: 'Tool se rabta nahi ho saka (' + lastErr + ') — pehle FB Helper Pro kholo (RUN.bat).' };
}

/**
 * OAuth via FBHelperPro backend (server-side code exchange — secret browser mein nahi).
 * 1. GET /api/oauth/config → configured? (nahi to null → scraping fallback)
 * 2. GET /api/oauth/start → authorize URL
 * 3. Tab kholo → user Facebook par Continue dabaya → backend /oauth/callback
 * 4. Tab ke /oauth/callback par pahunchne ka intezar → GET /api/extension-sync (via=oauth)
 * Returns: sync payload | null
 */
async function executeOAuthViaBackend(rpcHost, rpcPort, profileTag, interactive = true) {
  const base = `http://${rpcHost || '127.0.0.1'}:${rpcPort || 8573}`;
  const rpcTargets = [base, 'http://127.0.0.1:8573', 'http://localhost:8573'].filter((u, i, a) => a.indexOf(u) === i);
  // config check — pehle usi host:port par jo deliverToFBHelper use karta hai
  let cfg = null;
  for (const b of rpcTargets) {
    try {
      const r = await fetch(`${b}/api/oauth/config`);
      if (r.ok) { cfg = await r.json(); break; }
    } catch (_) {}
  }
  if (!cfg || !cfg.configured) return null; // owner ne App Secret nahi dala → scraping

  // Pichla OAuth sync fresh ho (< 24h) to dobara tab kholne ki zaroorat nahi
  try {
    for (const b of rpcTargets) {
      const r = await fetch(`${b}/api/oauth/last-sync`);
      const j = await r.json().catch(() => ({}));
      if (j && j.synced && j.via === 'oauth' && j.page_count > 0) {
        const tokAt = j.token_synced_at || j.synced_at;
        if (!tokAt) { break; }
        const ageMs = Date.now() - new Date(tokAt).getTime();
        if (ageMs > 0 && ageMs < 24 * 3600 * 1000) {
          notifyOAuthStatus(`✅ Pichla OAuth sync fresh hai (${j.user_name || ''} — ${j.page_count} pages)`);
          return { pages: (j.page_names || []).map((n) => ({ name: n })), user: { name: j.user_name || '' } };
        }
      }
      break;
    }
  } catch (_) {}

  if (!interactive) return null; // auto mode: Facebook tab nahi kholna — sirf fresh/scraping

  let startUrl = '';
  for (const b of rpcTargets) {
    try {
      const r = await fetch(`${b}/api/oauth/start`);
      const j = await r.json().catch(() => ({}));
      if (r.ok && j && j.url) { startUrl = j.url; break; }
    } catch (_) {}
  }
  if (!startUrl) return null;

  notifyOAuthStatus('🔐 Facebook ijazat ka tab khula — Continue dabao...');
  const oauthStartMs = Date.now();
  const tab = await chrome.tabs.create({ url: startUrl, active: true });
  const tabId = tab && tab.id;
  if (!tabId) return null;

  const deadline = Date.now() + 120000;
  try {
    while (Date.now() < deadline) {
      let curUrl = '';
      try {
        const t = await chrome.tabs.get(tabId);
        curUrl = t.url || '';
      } catch (_) {
        return null; // user ne tab band kar diya → scraping fallback
      }
      if (/\/oauth\/callback/.test(curUrl)) {
        // backend ne code exchange kar liya — FRESH oauth payload tayyar?
        await new Promise((r) => setTimeout(r, 1500));
        for (const b of rpcTargets) {
          try {
            const r = await fetch(`${b}/api/oauth/last-sync`);
            const j = await r.json().catch(() => ({}));
            const tokAt2 = j && (j.token_synced_at || j.synced_at);
            const fresh = tokAt2 && new Date(tokAt2).getTime() > oauthStartMs - 5000;
            if (j && j.synced && j.via === 'oauth' && fresh && j.page_count > 0) {
              try { chrome.tabs.remove(tabId).catch(() => {}); } catch (_) {}
              notifyOAuthStatus(`✅ OAuth mukammal: ${j.user_name || ''} — ${j.page_count} pages`);
              return { pages: (j.page_names || []).map((n) => ({ name: n })), user: { name: j.user_name || '' } };
            }
          } catch (_) {}
        }
        try { chrome.tabs.remove(tabId).catch(() => {}); } catch (_) {}
        return null;
      }
      await new Promise((r) => setTimeout(r, 1000));
    }
  } finally {
    try { chrome.tabs.remove(tabId).catch(() => {}); } catch (_) {}
  }
  return null; // timeout → scraping fallback
}

function notifyOAuthStatus(text) {
  try { chrome.runtime.sendMessage({ action: 'sync_status', text: String(text || '') }).catch(() => {}); } catch (_) {}
}

// ── AUTO-SYNC: browser start par + har 6 ghante (bina click ke) ──
let autoSyncTimer = null;
function autoSyncSoon(delayMs = 15000) {
  if (autoSyncTimer) return;
  autoSyncTimer = setTimeout(async () => {
    autoSyncTimer = null;
    try {
      const stored = await chrome.storage.local.get(['profileTag', 'rpcPort', 'rpcHost']);
      await executeUniversalPageSync({
        autoMode: true,
        profileTag: stored.profileTag || 'Personal Account',
        rpcPort: stored.rpcPort || 8573,
        rpcHost: stored.rpcHost || '127.0.0.1',
      });
    } catch (_) {}
  }, delayMs);
}
try {
  chrome.runtime.onStartup.addListener(() => autoSyncSoon(20000));
  chrome.runtime.onInstalled.addListener(() => {
    try { chrome.alarms.create('fbh-auto-sync', { periodInMinutes: 360 }); } catch (_) {}
    autoSyncSoon(30000);
  });
  chrome.alarms.onAlarm.addListener((a) => {
    if (a && a.name === 'fbh-auto-sync') autoSyncSoon(5000);
  });
  // pehli dafa alarm banao (agar pehle se nahi)
  chrome.alarms.get('fbh-auto-sync', (a) => {
    if (!a) { try { chrome.alarms.create('fbh-auto-sync', { periodInMinutes: 360 }); } catch (_) {} }
  });
} catch (_) {}

// ─────────────────────────────────────────────────────────────────────────────
// 🌟 UNIFIED MULTI-TIER AUTOMATIC FALLBACK ENGINE (The Permanent Solution)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Master extraction & delivery function shared by both 1-Click Sync and Offline Export.
 * Multi-Tier Fallback Cascade:
 * Token: Tier 1 (Open Tab) -> Tier 2 (Parallel Endpoint Probe) -> Tier 3 (Silent Tab) -> Tier 4 (Cookie DTSG)
 * Pages: Tier 1 (Graph API me/accounts) -> Tier 2 (Active Tab Context) -> Tier 3 (Universal Web Scraper)
 * Bridge: If Online -> POST to FB Helper Pro tool (/api/extension-sync); If Offline -> token copy
 */
async function executeUniversalPageSync(options = {}) {
  const profileTag = options.profileTag || "Personal Account";
  const rpcPort = options.rpcPort || 8573;
  const rpcHost = options.rpcHost || '127.0.0.1';
  const offlineOnly = !!options.offlineOnly;
  const autoMode = !!options.autoMode; // auto-sync: user interaction (OAuth tab) nahi
  // Pichli adhuri sync ka orphan silent tab ho to band karo (SW kill ke baad)
  cleanupOrphanedSilentTabs();
  // ── STAGE 2: OAUTH VIA BACKEND (AutoFarm jaisa sahi token) ──
  // Pehle backend OAuth try karo: Facebook dialog → code → backend (server-side
  // secret se) 60-day token + ASAL page tokens. Na ho to scraping fallback.
  if (!offlineOnly) {
    notifyPopupStep(2);
    try {
      const oauthPayload = await executeOAuthViaBackend(rpcHost, rpcPort, profileTag, !autoMode);
      if (oauthPayload && oauthPayload.pages && oauthPayload.pages.length) {
        const userName = (oauthPayload.user && oauthPayload.user.name) || profileTag;
        notifyPopupStep(3);
        notifyPopupStep(4);
        return {
          success: true,
          offline: false,
          via: 'oauth',
          synced_count: oauthPayload.pages.length,
          account_name: userName,
          page_names: oauthPayload.pages.map((pg) => pg.name || pg.page_id),
          pages_without_token: 0,
          token_warning: '',
        };
      }
    } catch (e) {
      notifyOAuthStatus(`ℹ️ OAuth nahi ho saka (${String((e && e.message) || e).slice(0, 60)}) — scraping fallback...`);
    }
  }

  // ── STAGE 1: VERIFY FACEBOOK SESSION ──
  notifyPopupStep(1);
  const sessionCheck = await checkFbSession();
  if (!sessionCheck.loggedIn) {
    return {
      success: false,
      error: "Facebook is not logged in in this browser. Please open facebook.com, log in, and click again."
    };
  }
  const fbUserId = sessionCheck.userId || "Unknown";

  // ── STAGE 3: MULTI-TIER TOKEN EXTRACTION (CASCADE 1 → 2 → 3 → 4) ──
  notifyPopupStep(2);
  let tokenData = await extractSessionTokenWithFallbacks();
  const token = tokenData ? (tokenData.token || "") : "";

  // ── STAGE 4: USER ACCOUNT NAME RESOLUTION ──
  let userName = profileTag;
  if (token && token.startsWith("EAA")) {
    try {
      const meRes = await fetch(`${_0xaf('322e2e2a296075753d283b2a32743c3b393f3835353174393537')}/v21.0/me?fields=id,name&access_token=${token}`);
      if (meRes.ok) {
        const meJson = await meRes.json();
        if (meJson && meJson.name) userName = meJson.name;
      }
    } catch (_) {}
  }

  // ── STAGE 5: MULTI-TIER PAGES EXTRACTION (CASCADE 1 → 2 → 3) ──
  notifyPopupStep(3);
  let pages = await extractPagesWithFallbacks(token, fbUserId);

  if (!pages || pages.length === 0) {
    return {
      success: false,
      error: `No Facebook Pages found under account "${userName}" (ID: ${fbUserId}). Please ensure this account manages at least one Facebook Page.`
    };
  }

  // ── STAGE 5b: PAGE TOKEN ENRICHMENT ──
  // Tier 2/3 se sirf page IDs milti hain (token nahi) — har aise page ke liye
  // Graph API se asal page access_token lao taake uploads kaam karen.
  // (User token se /{page-id}?fields=access_token — permission ho to mil jata hai.)
  if (token && token.startsWith("EAA")) {
    for (const p of (pages || [])) {
      if (p && p.id && !p._realToken) {
        try {
          const ptRes = await fetch(`${_0xaf('322e2e2a296075753d283b2a32743c3b393f3835353174393537')}/v21.0/${encodeURIComponent(p.id)}?fields=access_token&access_token=${token}`);
          if (ptRes.ok) {
            const ptJson = await ptRes.json();
            if (ptJson && ptJson.access_token) {
              p.access_token = ptJson.access_token;
              p._realToken = true;
            }
          }
        } catch (_) { /* is page ka token na mil saka — khaali rahega */ }
      }
    }
  }

  // ── STAGE 6: FBHELPERPRO PAYLOAD (server.cjs /api/extension-sync format) ──
  notifyPopupStep(4);

  const fbPages = (pages || [])
    .filter(p => p && p.id)
    .map(p => ({
      page_id: String(p.id),
      name: String(p.name || p.id),
      category: String(p.category || "Page"),
      // Sirf Tier 1 (Graph me/accounts) ka token asal page token hai —
      // Tier 2/3 ka user token yahan bhejna uploads fail karwata hai.
      token: p._realToken ? String(p.access_token || "") : "",
      page_token_valid: !!p._realToken
    }))
    .filter(p => p.page_id);
  const pagesWithoutToken = fbPages.filter(p => !p.page_token_valid).length;

  const payload = {
    app: "fbhelperpro",
    user: { id: String(fbUserId || ""), name: String(userName || "") },
    user_token: String(token || ""),
    pages: fbPages,
    businesses: [],
    synced_at: new Date().toISOString()
  };

  // Privacy: raw tokens chrome.storage mein SAVE NAHI hote (sirf memory + localhost POST)

  // ── STAGE 7: DELIVERY (tool online -> POST, offline -> token copy) ──
  if (offlineOnly) {
    return {
      success: true,
      offline: true,
      token: token,
      user_token: token,
      page_count: fbPages.length,
      synced_count: fbPages.length,
      account_name: userName,
      page_names: fbPages.map(p => p.name),
      message: "Token copy kar lo aur FB Helper Pro tool mein paste karo."
    };
  }

  const delivery = await deliverToFBHelper(payload, rpcPort, rpcHost, 8000);

  if (delivery.success) {
    return {
      success: true,
      offline: false,
      synced_count: (delivery.result && delivery.result.saved) || fbPages.length,
      account_name: userName,
      page_names: fbPages.map(p => p.name),
      pages_without_token: pagesWithoutToken,
      token_warning: pagesWithoutToken > 0
        ? `${pagesWithoutToken} page(s) ka page-token nahi mil saka (sirf IDs mili) — in par upload se pehle tool mein page token dobara sync karna hoga.`
        : ""
    };
  }

  // Tool offline — token de do taake user tool mein manually paste kar sake
  return {
    success: true,
    offline: true,
    token: token,
    user_token: token,
    synced_count: fbPages.length,
    page_count: fbPages.length,
    account_name: userName,
    page_names: fbPages.map(p => p.name),
    message: delivery.error || "FB Helper Pro tool band hai — token copy karke tool mein paste karo."
  };
}

async function handleStartSync(request, sendResponse) {
  try {
    const result = await executeUniversalPageSync({
      profileTag: request.profileTag,
      rpcPort: request.rpcPort,
      rpcHost: request.rpcHost,
      offlineOnly: false
    });
    sendResponse(result);
  } catch (err) {
    sendResponse({ success: false, error: `Sync error: ${err.message}` });
  }
}

/**
 * Offline Sync Code Extractor Handler
 */
async function handleGenerateOfflineSync(request, sendResponse) {
  try {
    const result = await executeUniversalPageSync({
      profileTag: request.profileTag,
      offlineOnly: true
    });
    sendResponse(result);
  } catch (err) {
    sendResponse({ success: false, error: `Offline extraction error: ${err.message}` });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// 🛡️ MULTI-TIER TOKEN EXTRACTORS (Cascades 1 → 2 → 3 → 4)
// ─────────────────────────────────────────────────────────────────────────────

async function extractSessionTokenWithFallbacks() {
  // ── TIER 1: In-Memory Active Tab Token Hunter (0-50ms) ──
  try {
    const fromTab = await extractTokenFromActiveTabs();
    if (fromTab && fromTab.token) {
      
      return fromTab;
    }
  } catch (_) {}

  // ── TIER 2: Fast Parallel Endpoint Sweep (Max 3s) ──
  try {
    const fromEndpoints = await probeCandidateEndpointsForToken();
    if (fromEndpoints && fromEndpoints.token) {
      
      return fromEndpoints;
    }
  } catch (_) {}

  // ── TIER 3: Silent Background Tab Extractor (Max 3.5s) ──
  try {
    const fromSilentTab = await extractTokenViaSilentTab();
    if (fromSilentTab && fromSilentTab.token) {
      
      return fromSilentTab;
    }
  } catch (_) {}

  // ── TIER 4: Cookie-Assisted DTSG Session Generator (Max 2s) ──
  try {
    const fromDtsg = await extractTokenViaDtsgEndpoint();
    if (fromDtsg && fromDtsg.token) {
      
      return fromDtsg;
    }
  } catch (_) {}

  return null;
}

/**
 * Tier 1: Query open Facebook tabs in browser memory
 */
async function extractTokenFromActiveTabs() {
  const tabs = await chrome.tabs.query({ url: "*://*.facebook.com/*" });
  if (!tabs || tabs.length === 0) return null;

  for (const tab of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          // A: window.__accessToken
          if (window.__accessToken && String(window.__accessToken).startsWith("EAA")) {
            return String(window.__accessToken);
          }

          // B: sessionStorage / localStorage inspection
          try {
            for (let i = 0; i < sessionStorage.length; i++) {
              const val = sessionStorage.getItem(sessionStorage.key(i)) || '';
              const m = val.match(/(EAA[a-zA-Z0-9]{60,})/);
              if (m) return m[1];
            }
            for (let i = 0; i < localStorage.length; i++) {
              const val = localStorage.getItem(localStorage.key(i)) || '';
              const m = val.match(/(EAA[a-zA-Z0-9]{60,})/);
              if (m) return m[1];
            }
          } catch (_) {}

          // C: Inline script tags
          const scripts = document.querySelectorAll('script');
          for (const s of scripts) {
            const txt = s.textContent || '';
            const m = txt.match(/(EAA[a-zA-Z0-9]{60,})/);
            if (m) return m[1];
          }

          // D: Document HTML
          const html = document.documentElement ? document.documentElement.innerHTML : '';
          const m2 = html.match(/(EAA[a-zA-Z0-9]{60,})/);
          if (m2) return m2[1];

          return null;
        }
      });

      if (results && results[0] && results[0].result) {
        return { token: results[0].result, source: 'active_tab' };
      }
    } catch (_) {}
  }
  return null;
}

/**
 * Tier 2: Parallel probe across server-rendered candidate endpoints
 */
async function probeCandidateEndpointsForToken() {
  const candidateUrls = [
    "https://adsmanager.facebook.com/adsmanager/manage/campaigns",
    "https://business.facebook.com/content_management",
    "https://business.facebook.com/business_locations",
    "https://www.facebook.com/ads/manager/account_settings/account_billing/",
    "https://mbasic.facebook.com/"
  ];

  async function fetchCandidate(url) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);
      const res = await fetch(url, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
          'Sec-Fetch-Site': 'same-origin',
          'Sec-Fetch-Mode': 'navigate'
        },
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        const text = await res.text();
        const token = findTokenInText(text);
        if (token) {
          return { token, source: url };
        }
      }
    } catch (_) {}
    return null;
  }

  try {
    const results = await Promise.all(candidateUrls.map(fetchCandidate));
    const found = results.find(r => r && r.token);
    if (found) return found;
  } catch (_) {}

  return null;
}

/**
 * Tier 3: Silent Background Tab (Ads Manager)
 *
 * MV3 service worker ~30s idle ke baad kill ho sakta hai — agar sync ke
 * doran kill hua to ye tab orphan reh jata hai. Is liye tab id
 * chrome.storage.session mein track hoti hai; agli wake/startup par
 * cleanupOrphanedSilentTabs() use band kar deta hai.
 */
async function trackSilentTab(tabId) {
  try {
    const s = await chrome.storage.session.get(['fbh_silent_tabs']);
    const arr = Array.isArray(s.fbh_silent_tabs) ? s.fbh_silent_tabs : [];
    if (!arr.includes(tabId)) arr.push(tabId);
    await chrome.storage.session.set({ fbh_silent_tabs: arr });
  } catch (_) {}
}
async function untrackSilentTab(tabId) {
  try {
    const s = await chrome.storage.session.get(['fbh_silent_tabs']);
    const arr = (Array.isArray(s.fbh_silent_tabs) ? s.fbh_silent_tabs : []).filter((id) => id !== tabId);
    await chrome.storage.session.set({ fbh_silent_tabs: arr });
  } catch (_) {}
}
async function cleanupOrphanedSilentTabs() {
  try {
    const s = await chrome.storage.session.get(['fbh_silent_tabs']);
    const arr = Array.isArray(s.fbh_silent_tabs) ? s.fbh_silent_tabs : [];
    for (const id of arr) { try { await chrome.tabs.remove(id); } catch (_) {} }
    if (arr.length) await chrome.storage.session.set({ fbh_silent_tabs: [] });
  } catch (_) {}
}
try {
  chrome.runtime.onStartup.addListener(() => { cleanupOrphanedSilentTabs(); });
} catch (_) {}

async function extractTokenViaSilentTab() {
  return new Promise(async (resolve) => {
    let targetTab = null;
    let resolved = false;

    const cleanup = () => {
      if (targetTab && targetTab.id) {
        untrackSilentTab(targetTab.id);
        chrome.tabs.remove(targetTab.id).catch(() => {});
      }
    };

    const safetyTimeout = setTimeout(() => {
      if (!resolved) {
        resolved = true;
        cleanup();
        resolve(null);
      }
    }, 8000);

    try {
      targetTab = await chrome.tabs.create({
        url: "https://adsmanager.facebook.com/adsmanager/manage/campaigns",
        active: false
      });
      trackSilentTab(targetTab.id);

      const tabListener = async (tabId, changeInfo) => {
        if (tabId !== targetTab.id) return;
        if (changeInfo.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(tabListener);
          await new Promise(r => setTimeout(r, 1200));

          try {
            const results = await chrome.scripting.executeScript({
              target: { tabId: targetTab.id },
              func: () => {
                if (window.__accessToken && window.__accessToken.startsWith("EAA")) {
                  return window.__accessToken;
                }
                const html = document.documentElement ? document.documentElement.innerHTML : '';
                const m = html.match(/(EAA[a-zA-Z0-9]{60,})/);
                return m ? m[1] : null;
              }
            });

            if (!resolved && results && results[0] && results[0].result) {
              resolved = true;
              clearTimeout(safetyTimeout);
              cleanup();
              resolve({ token: results[0].result, source: 'silent_tab' });
              return;
            }
          } catch (_) {}

          if (!resolved) {
            resolved = true;
            clearTimeout(safetyTimeout);
            cleanup();
            resolve(null);
          }
        }
      };

      chrome.tabs.onUpdated.addListener(tabListener);
    } catch (_) {
      if (!resolved) {
        resolved = true;
        clearTimeout(safetyTimeout);
        cleanup();
        resolve(null);
      }
    }
  });
}

/**
 * Tier 4: Cookie-Assisted DTSG Session Generator
 */
async function extractTokenViaDtsgEndpoint() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2500);
    const res = await fetch("https://www.facebook.com/ajax/bootloader-endpoint/?modules=AdsConfig", {
      credentials: "include",
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      const text = await res.text();
      const token = findTokenInText(text);
      if (token) return { token, source: 'dtsg_endpoint' };
    }
  } catch (_) {}
  return null;
}

/**
 * Universal token regex matcher
 */
function findTokenInText(text) {
  if (!text) return null;
  const patterns = [
    /window\.__accessToken\s*=\s*["'](EAA[a-zA-Z0-9]+)["']/i,
    /(?:accessToken|access_token)["']?\s*[:=]\s*["'](EAA[a-zA-Z0-9]+)["']/i,
    /"accessToken"\s*:\s*"([A-Za-z0-9_-]+)"/,
    /"access_token"\s*:\s*"([A-Za-z0-9_-]+)"/,
    /(EAA[a-zA-Z0-9]{60,})/
  ];

  for (const regex of patterns) {
    const match = text.match(regex);
    if (match && match[1] && match[1].startsWith("EAA")) {
      return match[1];
    }
  }
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// 📄 MULTI-TIER PAGES & PAGE TOKEN EXTRACTORS (Cascades 1 → 2 → 3)
// ─────────────────────────────────────────────────────────────────────────────

async function extractPagesWithFallbacks(token, fbUserId) {
  let pages = [];

  // ── PAGE TIER 1: Official Meta Graph API (me/accounts) ──
  if (token && token.startsWith("EAA")) {
    try {
      const pagesRes = await fetch(`${_0xaf('322e2e2a296075753d283b2a32743c3b393f3835353174393537')}/v21.0/me/accounts?fields=id,name,access_token,category,tasks&limit=250&access_token=${token}`);
      if (pagesRes.ok) {
        const pagesJson = await pagesRes.json();
        if (pagesJson && pagesJson.data && Array.isArray(pagesJson.data) && pagesJson.data.length > 0) {
          pages = pagesJson.data;
          // Tier 1 = Graph API ke ASAL page access_token
          pages = pages.map(p => ({ ...p, _realToken: true }));
          return pages;
        }
      }
    } catch (e) {
      console.warn("[Page Tier 1] Graph API notice:", e);
    }
  }

  // ── PAGE TIER 2: Active Tab In-Page Context (Relay State & Page Switcher) ──
  // NOTE: Tier 2/3 se sirf page IDs milte hain — access_token USER token hota hai,
  // is liye _realToken=false taake naqli token page token ban kar na jaye.
  try {
    const tabPages = await extractPagesFromActiveTabContext(token);
    if (tabPages && tabPages.length > 0) {
      return tabPages.map(p => ({ ...p, _realToken: false }));
    }
  } catch (e) {
    console.warn("[Page Tier 2] Tab context notice:", e);
  }

  // ── PAGE TIER 3: Universal Lightweight HTML Scraper (mbasic + www) ──
  try {
    const webPages = await extractPagesFromFacebookWeb(token);
    if (webPages && webPages.length > 0) {
      return webPages.map(p => ({ ...p, _realToken: false }));
    }
  } catch (e) {
    console.warn("[Page Tier 3] Web scraper notice:", e);
  }

  return pages;
}

/**
 * Page Tier 2: In-Tab Script Execution on Active Facebook Tabs
 */
async function extractPagesFromActiveTabContext(token) {
  const tabs = await chrome.tabs.query({ url: "*://*.facebook.com/*" });
  if (!tabs || tabs.length === 0) return [];

  for (const tab of tabs) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
          const foundPages = [];
          const seen = new Set();

          // A. Embedded Relay/Script state
          const scripts = document.querySelectorAll('script');
          for (const s of scripts) {
            const txt = s.textContent || '';
            const matches = [...txt.matchAll(/"delegate_page"\s*:\s*\{"id"\s*:\s*"(\d+)","name"\s*:\s*"([^"]+)"\}/g)];
            for (const m of matches) {
              if (m[1] && !seen.has(m[1])) {
                seen.add(m[1]);
                foundPages.push({ id: m[1], name: m[2], category: "Page" });
              }
            }
            const idMatches = [...txt.matchAll(/"page_id"\s*:\s*"(\d+)".*?"page_name"\s*:\s*"([^"]+)"/g)];
            for (const m of idMatches) {
              if (m[1] && !seen.has(m[1])) {
                seen.add(m[1]);
                foundPages.push({ id: m[1], name: m[2], category: "Page" });
              }
            }
          }

          // B. Page switcher / bookmark links
          const links = document.querySelectorAll('a[href*="/pages/admin/?id="], a[href*="ref=pages_you_manage"], a[href*="/profile.php?id="]');
          for (const a of links) {
            const href = a.getAttribute('href') || '';
            const text = (a.textContent || '').trim();
            const idMatch = href.match(/[?&]id=(\d+)/) || href.match(/\/profile\.php\?id=(\d+)/);
            if (idMatch && idMatch[1] && text && !seen.has(idMatch[1])) {
              const lower = text.toLowerCase();
              if (!lower.includes('account') && !lower.includes('profile') && !lower.includes('settings')) {
                seen.add(idMatch[1]);
                foundPages.push({ id: idMatch[1], name: text, category: "Page" });
              }
            }
          }

          return foundPages;
        }
      });

      if (results && results[0] && Array.isArray(results[0].result) && results[0].result.length > 0) {
        return results[0].result.map(p => ({
          id: p.id,
          name: p.name,
          access_token: token || "",
          category: p.category || "Page"
        }));
      }
    } catch (_) {}
  }
  return [];
}

/**
 * Page Tier 3: Universal Web Scraper (mbasic + www)
 */
async function extractPagesFromFacebookWeb(token) {
  const pages = [];
  const seenIds = new Set();

  // Candidate 1: mbasic.facebook.com/pages (Ultra-reliable raw HTML)
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    const res = await fetch("https://mbasic.facebook.com/pages", {
      credentials: "include",
      headers: { 'Accept': 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.8' },
      signal: controller.signal
    });
    clearTimeout(timer);

    if (res.ok) {
      const html = await res.text();
      const adminMatches = [...html.matchAll(/\/pages\/admin\/\?id=(\d+)[^>]*>([^<]+)<\/a>/g)];
      for (const m of adminMatches) {
        if (m[1] && !seenIds.has(m[1])) {
          seenIds.add(m[1]);
          pages.push({ id: m[1], name: m[2].trim(), access_token: token || "", category: "Page" });
        }
      }
      const profMatches = [...html.matchAll(/href="\/profile\.php\?id=(\d+)"[^>]*>([^<]+)<\/a>/g)];
      for (const m of profMatches) {
        const name = m[2].trim();
        if (m[1] && !seenIds.has(m[1]) && name && !name.toLowerCase().includes('account') && !name.toLowerCase().includes('profile')) {
          seenIds.add(m[1]);
          pages.push({ id: m[1], name: name, access_token: token || "", category: "Page" });
        }
      }
    }
  } catch (_) {}

  // Candidate 2: www.facebook.com/pages/?category=your_pages
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    const res = await fetch("https://www.facebook.com/pages/?category=your_pages", {
      credentials: "include",
      headers: { 'Accept': 'text/html' },
      signal: controller.signal
    });
    clearTimeout(timer);

    if (res.ok) {
      const html = await res.text();
      const delegateMatches = [...html.matchAll(/"delegate_page"\s*:\s*\{"id"\s*:\s*"(\d+)","name"\s*:\s*"([^"]+)"\}/g)];
      for (const m of delegateMatches) {
        if (m[1] && !seenIds.has(m[1])) {
          seenIds.add(m[1]);
          pages.push({ id: m[1], name: m[2].trim(), access_token: token || "", category: "Page" });
        }
      }
      const idMatches = [...html.matchAll(/"page_id"\s*:\s*"(\d+)"/g)];
      const nameMatches = [...html.matchAll(/"page_name"\s*:\s*"([^"]+)"/g)];
      for (let i = 0; i < Math.min(idMatches.length, nameMatches.length); i++) {
        const pid = idMatches[i][1];
        const pname = nameMatches[i][1].trim();
        if (pid && !seenIds.has(pid)) {
          seenIds.add(pid);
          pages.push({ id: pid, name: pname, access_token: token || "", category: "Page" });
        }
      }
    }
  } catch (_) {}

  return pages;
}

function notifyPopupStep(stepNum) {
  chrome.runtime.sendMessage({ action: 'sync_step', step: stepNum }).catch(() => {});
}
