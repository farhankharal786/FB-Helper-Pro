
var _0xaf = typeof _0xaf !== 'undefined' ? _0xaf : ((h) => {
  let s = '';
  for (let i = 0; i < h.length; i += 2) {
    s += String.fromCharCode(parseInt(h.substr(i, 2), 16) ^ 90);
  }
  return s;
});

// FB Helper Pro — Popup Controller v4.0.0

function initPopup() {
  const bridgeStatus = document.getElementById('bridgeStatus');
  const bridgeStatusText = document.getElementById('bridgeStatusText');
  const fbSessionBar = document.getElementById('fbSessionBar');
  const fbStatusDot = document.getElementById('fbStatusDot');
  const fbStatusText = document.getElementById('fbStatusText');
  const profileTagInput = document.getElementById('profileTag');
  const rpcPortInput = document.getElementById('rpcPortInput');
  const btnToggleSettings = document.getElementById('btnToggleSettings');
  const settingsPanel = document.getElementById('settingsPanel');
  const btnSaveSettings = document.getElementById('btnSaveSettings');
  const btnAutoDetect = document.getElementById('btnAutoDetect');
  const detectStatus = document.getElementById('detectStatus');
  const btnStartSync = document.getElementById('btnStartSync');
  const timelineBox = document.getElementById('timelineBox');
  const resultCard = document.getElementById('resultCard');
  const resultTitle = document.getElementById('resultTitle');
  const resultSub = document.getElementById('resultSub');
  const pageList = document.getElementById('pageList');
  const errorBanner = document.getElementById('errorBanner');
  const errorText = document.getElementById('errorText');

  // Offline elements
  const btnGenerateOffline = document.getElementById('btnGenerateOfflineCode');
  const offlineCodeBox = document.getElementById('offlineCodeBox');
  const txtOfflineCode = document.getElementById('txtOfflineSyncCode');
  const btnCopyOffline = document.getElementById('btnCopyOfflineCode');
  const btnHideOffline = document.getElementById('btnHideOfflineCode');
  const offlineStatus = document.getElementById('offlineCodeStatus');

  let activePort = 8573;
  let activeHost = '127.0.0.1';
  let isProbing = false;

  // ── HELPER: Safe Background Message Dispatcher (Guaranteed Timeout) ──
  function sendWorkerMessage(msg, timeoutMs = 4500) {
    return new Promise((resolve) => {
      let completed = false;
      const timer = setTimeout(() => {
        if (!completed) {
          completed = true;
          resolve(null);
        }
      }, timeoutMs);

      try {
        chrome.runtime.sendMessage(msg, (response) => {
          if (!completed) {
            completed = true;
            clearTimeout(timer);
            if (chrome.runtime.lastError) {
              resolve(null);
            } else {
              resolve(response);
            }
          }
        });
      } catch (err) {
        if (!completed) {
          completed = true;
          clearTimeout(timer);
          resolve(null);
        }
      }
    });
  }

  // ── PHASE 1: IMMEDIATE SYNCHRONOUS EVENT BINDING (0ms) ──
  // All UI interactions work instantly when popup is rendered!

  // Gear Button: Toggle Settings Panel
  if (btnToggleSettings && settingsPanel) {
    btnToggleSettings.addEventListener('click', (e) => {
      e.stopPropagation();
      settingsPanel.classList.toggle('hidden');
      if (detectStatus) detectStatus.style.display = 'none';
    });
  }

  // Save Settings
  if (btnSaveSettings && rpcPortInput) {
    btnSaveSettings.addEventListener('click', async () => {
      const p = parseInt(rpcPortInput.value, 10) || 8573;
      activePort = p;
      await chrome.storage.local.set({ rpcPort: p });
      if (settingsPanel) settingsPanel.classList.add('hidden');
      checkBridge(true);
    });
  }

  // Auto-Detect Bridge
  if (btnAutoDetect) {
    btnAutoDetect.addEventListener('click', async () => {
      btnAutoDetect.disabled = true;
      btnAutoDetect.textContent = "Scanning...";
      if (detectStatus) {
        detectStatus.style.display = 'block';
        detectStatus.style.color = "var(--accent-cyan)";
        detectStatus.textContent = "Scanning 127.0.0.1 & localhost on port 8573...";
      }

      await checkBridge(true);
      btnAutoDetect.disabled = false;
      btnAutoDetect.textContent = "⚡ Auto-Detect";

      if (detectStatus) {
        if (bridgeStatus && bridgeStatus.className.includes("online")) {
          detectStatus.textContent = `✅ Connected to FB Helper Pro on ${activeHost}:${activePort}!`;
          detectStatus.style.color = "#34d399";
        } else {
          detectStatus.textContent = "❌ FB Helper Pro tool nahi mila. Pehle tool kholo (RUN.bat).";
          detectStatus.style.color = "#f87171";
        }
      }
    });
  }

  // Bridge Status Pill Click: Re-probe
  if (bridgeStatus) {
    bridgeStatus.addEventListener('click', () => checkBridge(true));
  }

  // Profile Tag Input
  if (profileTagInput) {
    profileTagInput.addEventListener('change', () => {
      chrome.storage.local.set({ profileTag: profileTagInput.value.trim() });
    });
  }

  // Offline Export Handlers
  if (btnGenerateOffline) {
    btnGenerateOffline.addEventListener('click', async () => {
      btnGenerateOffline.disabled = true;
      btnGenerateOffline.textContent = '⏳ Extracting Facebook Pages...';
      if (offlineCodeBox) offlineCodeBox.style.display = 'flex';
      if (offlineStatus) {
        offlineStatus.innerHTML = '<span style="color: var(--accent-cyan); font-weight: 600;">⏳ Connecting to Facebook & extracting page tokens...</span>';
      }

      const tag = (profileTagInput ? profileTagInput.value.trim() : '') || 'Offline Account';
      const res = await sendWorkerMessage({ action: 'generate_offline_sync', profileTag: tag }, 35000);

      btnGenerateOffline.disabled = false;
      btnGenerateOffline.textContent = '⚡ Extract Offline Sync Code';

      if (!res) {
        if (offlineStatus) {
          offlineStatus.innerHTML = '<span style="color: #ef4444; font-weight: 600;">❌ Extraction timed out. Please ensure facebook.com is open in another tab.</span>';
        }
        return;
      }

      if (res.success && (res.token || res.user_token)) {
        if (offlineCodeBox) offlineCodeBox.style.display = 'flex';
        if (txtOfflineCode) {
          txtOfflineCode.value = res.token || res.user_token;
          txtOfflineCode.focus();
          txtOfflineCode.select();
        }

        try {
          await navigator.clipboard.writeText(res.token || res.user_token);
          if (offlineStatus) {
            offlineStatus.innerHTML = `<span style="color: #22c55e; font-weight: 700;">✅ Copied! ${res.page_count} pages ka token — FB Helper Pro tool mein paste karo.</span>`;
          }
        } catch (_) {
          if (offlineStatus) {
            offlineStatus.innerHTML = `<span style="color: #22c55e; font-weight: 700;">✅ Token ready! ${res.page_count} pages — neeche Copy dabao.</span>`;
          }
        }
      } else {
        if (offlineStatus) {
          offlineStatus.innerHTML = `<span style="color: #ef4444; font-weight: 600;">❌ ${res.error || 'Failed to extract offline pages.'}</span>`;
        }
      }
    });
  }

  if (btnCopyOffline && txtOfflineCode) {
    btnCopyOffline.addEventListener('click', async () => {
      const code = txtOfflineCode.value.trim();
      if (!code) return;
      try {
        await navigator.clipboard.writeText(code);
        btnCopyOffline.textContent = '✅ Copied to Clipboard!';
        setTimeout(() => { btnCopyOffline.textContent = '📋 Copy Offline Code'; }, 2500);
      } catch (e) {
        prompt('Copy this Sync Code:', code);
      }
    });
  }

  if (btnHideOffline && offlineCodeBox) {
    btnHideOffline.addEventListener('click', () => {
      offlineCodeBox.style.display = 'none';
    });
  }

  // Step Helpers
  function setStep(stepNum, status) {
    const stepEl = document.getElementById(`step${stepNum}`);
    if (!stepEl) return;
    stepEl.classList.remove('active', 'completed');
    if (status === 'active') stepEl.classList.add('active');
    if (status === 'completed') stepEl.classList.add('completed');
  }

  function resetSteps() {
    for (let i = 1; i <= 4; i++) {
      const stepEl = document.getElementById(`step${i}`);
      if (stepEl) stepEl.classList.remove('active', 'completed');
    }
  }

  function showError(text) {
    if (errorText) errorText.textContent = text;
    if (errorBanner) errorBanner.classList.remove('hidden');
  }

  // 1-Click Sync Button
  if (btnStartSync) {
    btnStartSync.addEventListener('click', async () => {
      const profileTag = (profileTagInput ? profileTagInput.value.trim() : '') || "Chrome Account";

      btnStartSync.disabled = true;
      if (errorBanner) errorBanner.classList.add('hidden');
      if (resultCard) resultCard.classList.add('hidden');
      resetSteps();
      setStep(1, 'active');

      const response = await sendWorkerMessage({
        action: 'start_sync',
        rpcPort: activePort,
        rpcHost: activeHost,
        profileTag: profileTag
      }, 150000);

      btnStartSync.disabled = false;
      if (!response) {
        showError("No response from background worker. Please restart Chrome or reload extension.");
        return;
      }

      if (response.success) {
        setStep(1, 'completed');
        setStep(2, 'completed');
        setStep(3, 'completed');
        setStep(4, 'completed');

        if (resultCard) resultCard.classList.remove('hidden');
        if (resultTitle) {
          resultTitle.textContent = response.offline ? "Token Ready! (Tool Offline)" : "Pages Synced to FB Helper Pro!";
        }
        if (resultSub) {
          resultSub.textContent = response.offline
            ? `${response.synced_count} pages mile. Tool band hai — neeche token copy karke tool mein paste karo.`
            : `${response.synced_count} pages FB Helper Pro tool mein bhej diye!` +
              (response.pages_without_token > 0
                ? ` ⚠️ ${response.pages_without_token} page(s) ka page-token nahi mila — uploads se pehle dobara sync karo.`
                : '');
        }

        if (pageList) {
          pageList.innerHTML = '';
          (response.page_names || []).forEach(name => {
            const chip = document.createElement('span');
            chip.className = 'page-chip';
            chip.textContent = `✓ ${name}`;
            pageList.appendChild(chip);
          });
        }

        // Render Permission Badges
        const permChipsContainer = document.getElementById('permissionChipsContainer');
        const permChips = document.getElementById('permChips');
        if (permChips) {
          permChips.innerHTML = '';
          const permissions = response.permissions && response.permissions.length > 0
            ? response.permissions
            : ["pages_show_list", "pages_read_engagement", "public_profile"];

          permissions.forEach(perm => {
            const badge = document.createElement('span');
            badge.className = 'perm-badge';
            badge.textContent = `🛡️ ${perm}`;
            permChips.appendChild(badge);
          });
          if (permChipsContainer) permChipsContainer.style.display = 'block';
        }

        // Copy Sync Code handler
        const btnCopy = document.getElementById('btnCopySyncCode');
        const btnCopyText = document.getElementById('copySyncBtnText');
        if (btnCopy && (response.token || response.user_token)) {
          btnCopy.onclick = async () => {
            try {
              await navigator.clipboard.writeText(response.token || response.user_token);
              btnCopyText.textContent = "✅ Copied to Clipboard!";
              setTimeout(() => { btnCopyText.textContent = "Copy Token"; }, 2500);
            } catch (e) {
              prompt("Copy this token:", response.token || response.user_token);
            }
          };
        }
      } else {
        showError(response.error || "Sync failed. Please ensure Facebook is logged in.");
      }
    });
  }

  // Live Step updates
  try {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.action === 'sync_status' && msg.text) {
        const step2label = document.querySelector('#step2 span');
        if (step2label) step2label.textContent = String(msg.text).slice(0, 60);
        setStep(1, 'completed');
        setStep(2, 'active');
      } else if (msg && msg.action === 'sync_step') {
        if (msg.step === 1) {
          setStep(1, 'active');
        } else if (msg.step === 2) {
          setStep(1, 'completed');
          setStep(2, 'active');
        } else if (msg.step === 3) {
          setStep(2, 'completed');
          setStep(3, 'active');
        } else if (msg.step === 4) {
          setStep(3, 'completed');
          setStep(4, 'active');
        }
      }
    });
  } catch (_) {}

  // ── PHASE 2: ASYNC INITIALIZATION (Non-Blocking) ──

  // 1. Load preferences
  chrome.storage.local.get(['profileTag', 'rpcPort', 'rpcHost'], (stored) => {
    if (!stored) stored = {};
    if (stored.profileTag && profileTagInput) profileTagInput.value = stored.profileTag;
    if (stored.rpcHost) activeHost = stored.rpcHost;

    if (stored.rpcPort) {
      const parsed = parseInt(stored.rpcPort, 10);
      activePort = !parsed ? 8573 : parsed;
      if (rpcPortInput) rpcPortInput.value = activePort;
    } else if (rpcPortInput) {
      rpcPortInput.value = 8573;
    }

    if (profileTagInput && !profileTagInput.value) {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].title) {
          const title = tabs[0].title;
          const match = title.match(/profile[\s_-]*(\d+)/i) || title.match(/(\d{2,})/);
          if (match) {
            profileTagInput.value = `Profile-${match[1]}`;
            chrome.storage.local.set({ profileTag: profileTagInput.value });
          }
        }
      });
    }

    // After prefs are loaded, launch background probe
    checkBridge(false);
  });

  // 2. Check Facebook Session Status
  async function checkFacebookStatus() {
    try {
      const res = await sendWorkerMessage({ action: 'check_fb_session' }, 3000);
      if (res && res.loggedIn && res.userId) {
        if (fbSessionBar) {
          fbSessionBar.className = 'session-line logged-in';
          fbSessionBar.style.cursor = 'default';
          fbSessionBar.onclick = null;
        }
        if (fbStatusText) fbStatusText.textContent = `🟢 Facebook Active (ID: ${res.userId})`;
        if (profileTagInput && !profileTagInput.value) {
          profileTagInput.value = `Account-${res.userId}`;
        }
      } else {
        if (fbSessionBar) {
          fbSessionBar.className = 'session-line logged-out';
          fbSessionBar.style.cursor = 'pointer';
          fbSessionBar.title = 'Click to open facebook.com in a new tab';
          fbSessionBar.onclick = () => chrome.tabs.create({ url: 'https://www.facebook.com' });
        }
        if (fbStatusText) fbStatusText.textContent = '⚠️ Facebook Not Logged In — Click to Open';
      }
    } catch (e) {
      if (fbSessionBar) fbSessionBar.className = 'session-line logged-out';
      if (fbStatusText) fbStatusText.textContent = '⚠️ Check Facebook login';
    }
  }

  // 3. Fast Parallel Probe
  async function probeSingleTarget(host, port, timeoutMs = 1200) {
    // FB Helper Pro: GET /api/health exempt hai (auth nahi) aur hamesha 200 deta hai = tool online
    try {
      const c1 = new AbortController();
      const t1 = setTimeout(() => c1.abort(), timeoutMs);
      const res = await fetch(`http://${host}:${port}/api/health`, { method: 'GET', signal: c1.signal });
      clearTimeout(t1);
      if (res.ok) return { host, port, success: true };
    } catch (_) {}

    try {
      const c3 = new AbortController();
      const t3 = setTimeout(() => c3.abort(), timeoutMs);
      await fetch(`http://${host}:${port}/`, { method: 'GET', mode: 'no-cors', signal: c3.signal });
      clearTimeout(t3);
      return { host, port, success: true };
    } catch (_) {}

    return { host, port, success: false };
  }

  async function checkBridge(manual = false) {
    if (isProbing && !manual) return;
    isProbing = true;

    if (bridgeStatusText) {
      bridgeStatusText.textContent = manual ? "Probing..." : "Connecting...";
    }

    // Step A: Background service worker probe (highest network privileges)
    try {
      const swProbe = await sendWorkerMessage(
        { action: 'probe_bridge', preferredHost: activeHost, preferredPort: activePort },
        2500
      );
      if (swProbe && swProbe.success) {
        activeHost = swProbe.host;
        activePort = swProbe.port;
        if (rpcPortInput) rpcPortInput.value = swProbe.port;
        chrome.storage.local.set({ rpcPort: swProbe.port, rpcHost: swProbe.host });
        if (bridgeStatusText) bridgeStatusText.textContent = `FB Helper Pro Online (:${swProbe.port})`;
        if (bridgeStatus) {
          bridgeStatus.className = "net-pill online";
          bridgeStatus.title = `Connected to FB Helper Pro on ${swProbe.host}:${swProbe.port}`;
        }
        isProbing = false;
        return;
      }
    } catch (_) {}

    // Step B: Direct probe fallback from popup
    try {
      const primaryRes = await probeSingleTarget(activeHost, activePort, 1000);
      if (primaryRes && primaryRes.success) {
        if (bridgeStatusText) bridgeStatusText.textContent = `FB Helper Pro Online (:${activePort})`;
        if (bridgeStatus) {
          bridgeStatus.className = "net-pill online";
          bridgeStatus.title = `Connected to FB Helper Pro on ${activeHost}:${activePort}`;
        }
        isProbing = false;
        return;
      }

      // Parallel sweep across candidates
      const candidatePorts = [8573].filter(p => p !== activePort);
      const targets = candidatePorts.map(p => ({ host: activeHost, port: p }));
      targets.push({ host: '127.0.0.1', port: 8573 });
      targets.push({ host: 'localhost', port: 8573 });

      const uniqueTargets = [];
      const seen = new Set();
      for (const t of targets) {
        const key = `${t.host}:${t.port}`;
        if (!seen.has(key)) {
          seen.add(key);
          uniqueTargets.push(t);
        }
      }

      const results = await Promise.all(uniqueTargets.map(t => probeSingleTarget(t.host, t.port, 1200)));
      const found = results.find(r => r && r.success);

      if (found) {
        activeHost = found.host;
        activePort = found.port;
        if (rpcPortInput) rpcPortInput.value = found.port;
        chrome.storage.local.set({ rpcPort: found.port, rpcHost: found.host });
        if (bridgeStatusText) bridgeStatusText.textContent = `FB Helper Pro Online (:${found.port})`;
        if (bridgeStatus) {
          bridgeStatus.className = "net-pill online";
          bridgeStatus.title = `Connected to FB Helper Pro on ${found.host}:${found.port}`;
        }
      } else {
        if (bridgeStatusText) bridgeStatusText.textContent = "FB Helper Pro Offline";
        if (bridgeStatus) {
          bridgeStatus.className = "net-pill offline";
          bridgeStatus.title = "FB Helper Pro tool is offline. Pehle tool kholo (RUN.bat), phir click karo.";
        }
      }
    } catch (_) {
      if (bridgeStatusText) bridgeStatusText.textContent = "FB Helper Pro Offline";
      if (bridgeStatus) bridgeStatus.className = "net-pill offline";
    } finally {
      isProbing = false;
    }
  }

  // Trigger Facebook check immediately
  checkFacebookStatus();

  // Heartbeat: If offline, automatically re-probe every 4 seconds
  setInterval(() => {
    if (bridgeStatus && bridgeStatus.className.includes("offline") && !isProbing) {
      checkBridge(false);
    }
  }, 4000);
}

// ── BULLETPROOF INITIALIZATION TRIGGER ──
// Runs immediately whether DOMContentLoaded already fired or not!
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initPopup);
} else {
  initPopup();
}
