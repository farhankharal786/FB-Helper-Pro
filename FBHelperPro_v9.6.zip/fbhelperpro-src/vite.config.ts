import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // Real backend (server.cjs, port 8573) — dev mein /api proxy
      // 127.0.0.1 use kiya hai (localhost nahi) kyunke server sirf IPv4 par
      // bind hota hai; Windows par localhost ::1 (IPv6) resolve ho sakta hai
      // jis se SSE/proxy connection reset hoti hai.
      proxy: {
        '/api': 'http://127.0.0.1:8573',
        '/downloads': 'http://127.0.0.1:8573',
      },
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // AHM: data/ aur downloads/ ko KABHI watch mat karo —
      // backend farming ke doran in mein har second likhta hai (DB, ui_state, videos)
      // aur har write par Vite poora page reload kar deta tha (infinite refresh bug).
      watch: process.env.DISABLE_HMR === 'true' ? null : {
        ignored: ['**/data/**', '**/downloads/**', '**/node_modules/**', '**/.git/**'],
      },
    },
  };
});
